# ==========================================
# 弩击杀检测 - 主检测函数
# ==========================================
# 功能: 检测玩家击杀生物时是否持有弩
# 执行: 每tick在主循环中调用
#
# 工作流程:
#   1. 检测玩家的 total_kill_count > 0（发生击杀）
#   2. 如果击杀发生，调用触发函数检查是否持弩
#   3. 重置 total_kill_count 为 0
#
# 计分板依赖:
#   - total_kill_count: 玩家总击杀数（Minecraft内置统计）
# ==========================================

# 检测玩家击杀（total_kill_count > 0）且调用触发函数
execute as @a[scores={total_kill_count=1..}] at @s run function soul_disc:crossbow_kill/trigger

# 重置计分板
scoreboard players set @a[scores={total_kill_count=1..}] total_kill_count 0
