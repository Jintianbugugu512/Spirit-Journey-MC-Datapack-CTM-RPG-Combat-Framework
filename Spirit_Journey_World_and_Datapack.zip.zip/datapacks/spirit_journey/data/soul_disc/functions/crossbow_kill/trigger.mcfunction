# ==========================================
# 弩击杀触发 - 效果触发函数
# ==========================================
# 功能: 检查玩家是否携带"射杀装填"魂盘，并检查主手或副手是否持有弩
# 调用: 由 detect.mcfunction 调用
#
# 工作流程:
#   1. 检查玩家是否携带"射杀装填"魂盘
#   2. 检查主手是否为弩
#   3. 检查副手是否为弩
#   4. 如果持有弩且携带魂盘，输出 "shoot" 并立刻装填弩箭
#
# 效果:
#   - 射杀装填：击杀敌人时立刻为弩装填一支箭
#   - 粒子与音效反馈
# ==========================================

# 检查玩家是否携带"射杀装填"魂盘
execute unless entity @s[nbt={Inventory:[{tag:{sd_id:"射杀装填"}}]}] run return fail

# 检查主手是否持有弩
execute if entity @s[nbt={SelectedItem:{id:"minecraft:crossbow"}}] run function soul_disc:crossbow_kill/reload_mainhand

# 检查副手是否持有弩
execute if entity @s[nbt={Inventory:[{Slot:-106b,id:"minecraft:crossbow"}]}] run function soul_disc:crossbow_kill/reload_offhand
