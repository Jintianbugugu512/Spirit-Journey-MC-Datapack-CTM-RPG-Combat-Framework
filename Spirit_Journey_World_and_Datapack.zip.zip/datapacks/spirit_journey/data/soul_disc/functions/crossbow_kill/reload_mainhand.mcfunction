# ==========================================
# 主手弩装填
# ==========================================
# 功能: 为主手的弩立刻装填一支箭
# 调用: 由 trigger.mcfunction 调用
# ==========================================

# 输出提示信息
say shoot

# 为主手弩装填箭矢
item modify entity @s weapon.mainhand soul_disc:crossbow_reload_modifier

# 音效反馈
playsound item.crossbow.loading_end player @s ~ ~ ~ 1 1.2

# 粒子效果
particle enchant ~ ~1 ~ 0.3 0.5 0.3 0.5 10 force
