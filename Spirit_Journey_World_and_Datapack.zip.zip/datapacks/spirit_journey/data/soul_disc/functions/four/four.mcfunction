# 获取敌人自定义血量系统的当前生命值
scoreboard players operation @s hp_temp = @s current_health
scoreboard players set #temp hp_temp 10
scoreboard players operation @s hp_temp %= #temp hp_temp
# 如果个位数是4，造成44%真实伤害
$execute if score @s hp_temp matches 4 run function combat:deal/damage_deal {"rate":"44","type":"true","player":"$(player)","interval":"cactus"}
