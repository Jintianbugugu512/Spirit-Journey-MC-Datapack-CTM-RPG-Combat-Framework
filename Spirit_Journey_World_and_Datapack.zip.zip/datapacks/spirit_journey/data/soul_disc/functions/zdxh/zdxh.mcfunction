# ==========================================
# 战斗续航魂盘
# 生命值<=50%时，击杀敌人回复4点生命值
# 3.5秒冷却时间
# ==========================================

# 初始化CD（如果没有值）
execute unless score @s zdxh_cd = @s zdxh_cd run scoreboard players set @s zdxh_cd 0

# 检查生命值是否<=50%
execute store result score #zdxh_hp temp run attribute @s generic.max_health get
scoreboard players set #zdxh_half temp 2
scoreboard players operation #zdxh_hp temp /= #zdxh_half temp

# 如果当前生命值<=50%最大生命值，且CD已结束
execute if score @s HP <= #zdxh_hp temp if score @s zdxh_cd matches ..0 run function soul_disc:zdxh/zdxh_check_kill

