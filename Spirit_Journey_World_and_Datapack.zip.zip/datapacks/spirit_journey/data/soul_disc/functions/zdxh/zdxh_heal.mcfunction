# ==========================================
# 战斗续航魂盘 - 回复生命值
# 回复4点生命值并设置冷却时间
# ==========================================

# 设置can_be_effect计分板，允许接受buff（2 tick）
scoreboard players set @s can_be_effect 2

# 使用effect指令实际治疗玩家
effect give @s minecraft:instant_health 1 0 true

# 设置3.5秒冷却（70 tick）
scoreboard players set @s zdxh_cd 70

# 视觉和音效反馈
particle heart ~ ~1 ~ 0.5 0.5 0.5 0.1 5 force
particle happy_villager ~ ~1 ~ 0.3 0.3 0.3 0 10 force
playsound entity.player.levelup player @s ~ ~ ~ 0.5 2
title @s actionbar {"text":"战斗续航 - 回复生命值！","color":"green","bold":true}
