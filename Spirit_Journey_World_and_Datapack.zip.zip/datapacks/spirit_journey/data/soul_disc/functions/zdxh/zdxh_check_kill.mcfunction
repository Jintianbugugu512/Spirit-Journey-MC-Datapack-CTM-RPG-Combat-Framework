# ==========================================
# 战斗续航魂盘 - 检测击杀
# 检测玩家的击杀统计，如果有击杀则触发回复
# ==========================================

# 使用 total_kill_count 统一检测所有击杀
# 如果击杀数 > 0，说明击杀了敌人
execute if score @s total_kill_count matches 1.. run function soul_disc:zdxh/zdxh_heal

