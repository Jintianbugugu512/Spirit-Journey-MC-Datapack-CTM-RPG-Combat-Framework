# ==========================================
# 圣泉恩惠魂盘 - 计算生命值加成
# 最大生命值 +15%
# ==========================================

# 计算15%的生命值加成
# 算法：max_HP_ = max_HP * 1.15 = max_HP + max_HP * 0.15
# 使用整数运算：max_HP_ += (max_HP * 15) / 100

# 临时变量存储15%加成
scoreboard players operation #holy_spring_bonus temp = @s max_HP
scoreboard players set #15 temp 15
scoreboard players set #100 temp 100

# 计算加成：(max_HP * 15) / 100
scoreboard players operation #holy_spring_bonus temp *= #15 temp
scoreboard players operation #holy_spring_bonus temp /= #100 temp

# 应用加成到 max_HP_
scoreboard players operation @s max_HP_ += #holy_spring_bonus temp
