# ==========================================
# 自动充能魂盘 - 充能效果
# 为玩家恢复1点MP，并提供视觉反馈
# ==========================================

# 增加1点MP
scoreboard players add @s MP 1

# 重置计时器
scoreboard players set @s auto_recharge_timer 0

# 粒子效果（魔法充能的感觉）
particle end_rod ~ ~1 ~ 0.2 0.3 0.2 0.05 3 force

# 音效反馈（轻柔的充能音效）
playsound block.enchantment_table.use player @s ~ ~ ~ 0.3 1.5
