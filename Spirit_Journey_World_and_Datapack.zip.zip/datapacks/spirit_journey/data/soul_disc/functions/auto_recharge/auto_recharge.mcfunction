# ==========================================
# 自动充能魂盘
# 每2秒自动为玩家恢复1点MP
# ==========================================

# 初始化计时器（如果没有值）
execute unless score @s auto_recharge_timer = @s auto_recharge_timer run scoreboard players set @s auto_recharge_timer 0

# 计时器每tick +1
scoreboard players add @s auto_recharge_timer 1

# 达到40tick（2秒）时触发充能
execute if score @s auto_recharge_timer matches 40.. run function soul_disc:auto_recharge/recharge
