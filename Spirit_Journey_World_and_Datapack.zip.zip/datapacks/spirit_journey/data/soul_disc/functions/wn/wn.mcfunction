# 计算20%最大生命值
execute store result score #temp temp1 run attribute @s generic.max_health get 0.2

# 如果血量小于20%，给予速度效果和wn_buff计分板标记
execute if score @s HP <= #temp temp1 run effect give @s speed 1 0 true
execute if score @s HP <= #temp temp1 run scoreboard players set @s wn_buff 1

# 如果血量大于等于20%，清除buff标记
execute if score @s HP > #temp temp1 run scoreboard players set @s wn_buff 0
