# ==========================================
# 蜕变挽歌魂盘 - 检测满血
# 如果玩家满血，自动添加1层剑气
# ==========================================

# 获取当前生命值
execute store result score #meta_current_hp temp run data get entity @s Health

# 获取最大生命值
execute store result score #meta_max_hp temp run attribute @s generic.max_health get

# 如果满血，添加1层剑气
execute if score #meta_current_hp temp >= #meta_max_hp temp run scoreboard players add @s sword_light_count 1

# 粒子效果（可选）
execute if score #meta_current_hp temp >= #meta_max_hp temp run particle end_rod ~ ~1 ~ 0.3 0.5 0.3 0.05 5 force
