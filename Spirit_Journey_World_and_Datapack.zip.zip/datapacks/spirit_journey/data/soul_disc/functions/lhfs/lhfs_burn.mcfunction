# ==========================================
# 烈火焚身魂盘 - 燃烧叠加
# 给单个敌人叠加1.5秒燃烧时间
# ==========================================

# 读取当前燃烧时间
execute store result score #lhfs fire run scoreboard players get @s fire

# 叠加30 tick（1.5秒）
scoreboard players add #lhfs fire 30

# 写回燃烧时间
execute store result entity @s Fire short 1 run scoreboard players get #lhfs fire
