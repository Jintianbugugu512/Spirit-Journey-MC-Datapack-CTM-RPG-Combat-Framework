# ==========================================
# 烈火焚身魂盘 - 触发效果
# 给5格内所有敌人叠加1.5秒（30 tick）燃烧
# ==========================================

# 对5格内所有敌人执行燃烧叠加
execute as @e[tag=enemy,distance=..5] at @s run function soul_disc:lhfs/lhfs_burn
