# ==========================================
# 烈火焚身魂盘
# 靠近玩家5格的敌人每秒叠加1.5秒燃烧时间
# ==========================================

# 计时器递增
scoreboard players add @s lhfs_timer 1

# 每20tick（1秒）触发一次
execute if score @s lhfs_timer matches 20.. run function soul_disc:lhfs/lhfs_trigger

# 重置计时器
execute if score @s lhfs_timer matches 20.. run scoreboard players set @s lhfs_timer 0
