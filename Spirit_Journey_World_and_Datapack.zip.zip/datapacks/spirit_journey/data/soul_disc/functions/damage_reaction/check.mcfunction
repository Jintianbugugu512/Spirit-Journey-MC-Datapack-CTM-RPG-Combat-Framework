# ==========================================
# 受伤检测系统
# 检测玩家是否受到伤害
# ==========================================

# 初始化last_damage_taken（如果没有值）
execute unless score @s last_damage_taken = @s last_damage_taken run scoreboard players set @s last_damage_taken 0

# 检测damage_taken是否发生变化（受到了伤害）
$execute unless score @s damage_taken = @s last_damage_taken run tellraw @s [{"text":"[调试] 玩家受到了攻击！player_$(id)","color":"red","bold":true}]

# 受击充能：回复2MP（需要携带"受击充能"魂盘）
execute unless score @s damage_taken = @s last_damage_taken if entity @s[nbt={Inventory:[{tag:{sd_id:"受击充能"}}]}] run scoreboard players add @s MP 2
execute unless score @s damage_taken = @s last_damage_taken if entity @s[nbt={Inventory:[{tag:{sd_id:"受击充能"}}]}] run tellraw @s [{"text":"[调试] 受击充能触发！+2MP","color":"green"}]

# 苦痛荆棘：对周围4格的敌人造成75%真实伤害（需要携带"苦痛荆棘"魂盘）
$execute unless score @s damage_taken = @s last_damage_taken if entity @s[nbt={Inventory:[{tag:{sd_id:"苦痛荆棘"}}]}] at @s as @e[tag=enemy,distance=..4] at @s run function combat:deal/damage_deal {"rate":"75","type":"true","player":"player_$(id)","interval":"cactus"}
execute unless score @s damage_taken = @s last_damage_taken if entity @s[nbt={Inventory:[{tag:{sd_id:"苦痛荆棘"}}]}] run tellraw @s [{"text":"[调试] 苦痛荆棘触发！","color":"red"}]

# 更新上次受伤记录
scoreboard players operation @s last_damage_taken = @s damage_taken


