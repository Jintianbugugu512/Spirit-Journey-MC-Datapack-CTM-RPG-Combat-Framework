# ==========================================
# 反隐侦测魂盘
# 令周围8格内的隐身敌人显形
# ==========================================

# 清除周围8格内所有敌人的隐身效果
effect clear @e[tag=enemy,distance=..8] invisibility

# 可选：添加发光效果，让隐身的敌人更容易被发现（持续3秒）
effect give @e[tag=enemy,distance=..8] glowing 3 0 true
