#execute as @a run 
execute store result score @s soul_disc run clear @s #music_discs 0
execute if score @s soul_disc > @s max_soul_disc run function soul_disc:overload
execute if score @s soul_disc > @s max_soul_disc run return 2
#如果玩家没有超载就移除overload的tag
tag @s remove overload

#实现被动魂盘效果
execute if entity @s[nbt={Inventory:[{tag:{sd_id:"亡者之怒"}}]}] run function soul_disc:wn/wn

execute if entity @s[nbt={Inventory:[{tag:{sd_id:"烈火焚心"}}]}] run function soul_disc:lh/lh

execute if entity @s[nbt={Inventory:[{tag:{sd_id:"烈火焚身"}}]}] run function soul_disc:lhfs/lhfs

execute if entity @s[nbt={Inventory:[{tag:{sd_id:"灵魂共鸣"}}]}] run function soul_disc:lhgy/lhgy

execute if entity @s[nbt={Inventory:[{tag:{sd_id:"战斗续航"}}]}] run function soul_disc:zdxh/zdxh

execute if entity @s[nbt={Inventory:[{tag:{sd_id:"自动充能"}}]}] run function soul_disc:auto_recharge/auto_recharge

execute if entity @s[nbt={Inventory:[{tag:{sd_id:"反隐侦测"}}]}] run function soul_disc:anti_stealth/anti_stealth

$execute if entity @s[nbt={Inventory:[{tag:{sd_id:"厄运数字4"}}]}] run execute as @e[tag=enemy,distance=..4] run function soul_disc:four/four with storage damage:$(player)




