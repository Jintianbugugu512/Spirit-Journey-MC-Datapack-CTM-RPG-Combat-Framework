# ==========================================
# 灵魂共鸣魂盘
# 每5秒为玩家增加10 MP
# ==========================================

# 计时器递增
scoreboard players add @s lhgy_timer 1

# 每100tick（5秒）触发一次
execute if score @s lhgy_timer matches 100.. run scoreboard players add @s MP 100

# 触发时的视觉和音效反馈
execute if score @s lhgy_timer matches 100.. run particle soul ~ ~1 ~ 0.3 0.5 0.3 0.02 10 force
execute if score @s lhgy_timer matches 100.. run particle enchant ~ ~1 ~ 0.5 0.5 0.5 0.1 15 force
execute if score @s lhgy_timer matches 100.. run playsound block.enchantment_table.use player @s ~ ~ ~ 0.5 1.5

# 重置计时器
execute if score @s lhgy_timer matches 100.. run scoreboard players set @s lhgy_timer 0
