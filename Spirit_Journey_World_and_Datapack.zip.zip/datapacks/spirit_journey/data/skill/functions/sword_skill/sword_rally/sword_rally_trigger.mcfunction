$execute unless entity @e[tag=$(player)swa] run summon interaction ~ ~-0.5 ~ {Tags:["$(player)swa"],height:0.3,width:0.3,response:true}


$execute as @s anchored eyes run tp @e[tag=$(player)swa] ^ ^-0.15 ^0.45

$execute if entity @s[scores={sword_rally_buff=299..}] run scoreboard players set @e[tag=$(player)swa] interval_stick 1
$execute if entity @s[scores={sword_rally_buff=..1}] run kill @e[tag=$(player)swa]

$execute as @e[tag=$(player)swa] at @s run function skill:sword_skill/sword_rally/detect with storage damage:$(player)
