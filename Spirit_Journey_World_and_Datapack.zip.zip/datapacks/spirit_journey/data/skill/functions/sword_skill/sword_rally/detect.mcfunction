execute store result score @s[scores={interval_stick=0}] detect_right1 run data get entity @s attack.timestamp

execute if score @s detect_right1 matches 1.. run data remove entity @s attack
$execute if score @s detect_right1 matches 1.. run execute as @e[tag=enemy,sort=nearest,limit=2,distance=..6.5] at @s run function skill:sword_skill/sword_rally/sword_rally_summon with storage damage:$(player)
execute if score @s detect_right1 matches 1.. run scoreboard players set @s interval_stick 3
$execute if score @s detect_right1 matches 1.. run scoreboard players add @a[tag=$(player)] MP 1
execute if score @s detect_right1 matches 1.. run scoreboard players set @s detect_right1 0

