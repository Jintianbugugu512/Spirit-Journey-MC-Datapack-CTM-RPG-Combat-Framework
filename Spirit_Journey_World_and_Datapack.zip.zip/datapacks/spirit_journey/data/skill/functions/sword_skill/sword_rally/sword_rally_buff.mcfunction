scoreboard players operation #blood temp = @s strength
scoreboard players set #blood temp1 10
scoreboard players set #blood temp2 3
scoreboard players operation #blood temp *= #blood temp2
scoreboard players operation #blood temp /= #blood temp1
scoreboard players operation @s strength_ -= #blood temp