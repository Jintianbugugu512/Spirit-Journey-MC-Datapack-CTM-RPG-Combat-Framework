#MP不足则返回
execute if score @s MP matches ..74 run title @s actionbar "『MP不足,使用§l万剑归宗§f需要消耗§l75MP§f.』"
execute if score @s MP matches ..74 run playsound block.bone_block.place ambient @s ~ ~ ~ 1 0.8 0
execute if score @s MP matches ..74 run return 2

#CD没有归0则返回
execute if score @s sword_rally_CD matches 1.. run scoreboard players operation #CD temp = @s sword_rally_CD
execute if score @s sword_rally_CD matches 1.. run scoreboard players set #CD temp1 20
execute if score @s sword_rally_CD matches 1.. run scoreboard players operation #CD temp /= #CD temp1
execute if score @s sword_rally_CD matches 1.. run scoreboard players add #CD temp 1
execute if score @s sword_rally_CD matches 1.. run title @s actionbar [{"text":"§l『万剑归宗』§f技能CD还剩"},{"score": {"name": "#CD","objective": "temp"},"bold": true},{"text":"s","bold": true}]
execute if score @s sword_rally_CD matches 1.. run playsound block.bone_block.break ambient @s ~ ~ ~ 1.0 0.8 0
execute if score @s sword_rally_CD matches 1.. run return 3


#设置技能CD
scoreboard players set @s sword_rally_CD 400
scoreboard players remove @s MP 75

#音效
execute run playsound block.anvil.place ambient @s ~ ~ ~ 0.6 0.6 0
particle dust_color_transition 0.0 0.1 0.9 1.25 1.0 0.0 0.0 ~ ~ ~ 1 1 1 1 75


$function skill:sword_skill/sword_rally/sword_rally_summon with storage damage:$(player)









scoreboard players set @s sword_rally_buff 300