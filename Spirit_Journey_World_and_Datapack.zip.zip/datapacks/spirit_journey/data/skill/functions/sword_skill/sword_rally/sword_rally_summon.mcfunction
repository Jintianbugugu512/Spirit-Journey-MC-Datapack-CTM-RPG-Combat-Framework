
execute store result score #sword_rally temp run random value 1..6
execute store result score #sword_rally temp1 run random value 1..8
execute if score #sword_rally temp1 = #sword_rally temp2 run function skill:sword_skill/sword_rally/sword_rally_summon
execute if score #sword_rally temp1 = #sword_rally temp2 run return 2
scoreboard players operation #sword_rally temp2 = #sword_rally temp1




#随机剑的种类
execute if score #sword_rally temp matches 1 run summon minecraft:item_display ~ ~ ~ {item:{id:"wooden_sword",Count:1b},Tags:["sword_attacker","sword_summon"]}
execute if score #sword_rally temp matches 2 run summon minecraft:item_display ~ ~ ~ {item:{id:"stone_sword",Count:1b},Tags:["sword_attacker","sword_summon"]}
execute if score #sword_rally temp matches 3 run summon minecraft:item_display ~ ~ ~ {item:{id:"iron_sword",Count:1b},Tags:["sword_attacker","sword_summon"]}
execute if score #sword_rally temp matches 4 run summon minecraft:item_display ~ ~ ~ {item:{id:"golden_sword",Count:1b},Tags:["sword_attacker","sword_summon"]}
execute if score #sword_rally temp matches 5 run summon minecraft:item_display ~ ~ ~ {item:{id:"diamond_sword",Count:1b},Tags:["sword_attacker","sword_summon"]}
execute if score #sword_rally temp matches 6 run summon minecraft:item_display ~ ~ ~ {item:{id:"netherite_sword",Count:1b},Tags:["sword_attacker","sword_summon"]}



#随机剑的位置Rotation:[-45f,-90f]
execute if score #sword_rally temp1 matches 1 run tp @e[tag=sword_summon] ~2 ~0.7 ~2
execute if score #sword_rally temp1 matches 1 run data merge entity @e[limit=1,tag=sword_summon] {Rotation:[0f,-90f]}

execute if score #sword_rally temp1 matches 2 run tp @e[tag=sword_summon] ~2 ~0.7 ~
execute if score #sword_rally temp1 matches 2 run data merge entity @e[limit=1,tag=sword_summon] {Rotation:[-45f,-90f]}

execute if score #sword_rally temp1 matches 3 run tp @e[tag=sword_summon] ~ ~0.7 ~2
execute if score #sword_rally temp1 matches 3 run data merge entity @e[limit=1,tag=sword_summon] {Rotation:[45f,-90f]}

execute if score #sword_rally temp1 matches 4 run tp @e[tag=sword_summon] ~-2 ~0.7 ~2
execute if score #sword_rally temp1 matches 4 run data merge entity @e[limit=1,tag=sword_summon] {Rotation:[90f,-90f]}

execute if score #sword_rally temp1 matches 5 run tp @e[tag=sword_summon] ~-2 ~0.7 ~
execute if score #sword_rally temp1 matches 5 run data merge entity @e[limit=1,tag=sword_summon] {Rotation:[135f,-90f]}

execute if score #sword_rally temp1 matches 6 run tp @e[tag=sword_summon] ~2 ~0.7 ~-2
execute if score #sword_rally temp1 matches 6 run data merge entity @e[limit=1,tag=sword_summon] {Rotation:[-90f,-90f]}

execute if score #sword_rally temp1 matches 7 run tp @e[tag=sword_summon] ~ ~0.7 ~-2
execute if score #sword_rally temp1 matches 7 run data merge entity @e[limit=1,tag=sword_summon] {Rotation:[-135f,-90f]}

execute if score #sword_rally temp1 matches 8 run tp @e[tag=sword_summon] ~-2 ~0.7 ~-2
execute if score #sword_rally temp1 matches 8 run data merge entity @e[limit=1,tag=sword_summon] {Rotation:[180f,-90f]}




#造成伤害
$execute if score #sword_rally temp matches 1 run execute as @s run function combat:deal/damage_deal {"rate":"50","type":"physic","player":"$(player)","interval":"cactus"}
$execute if score #sword_rally temp matches 2 run execute as @s run function combat:deal/damage_deal {"rate":"50","type":"physic","player":"$(player)","interval":"cactus"}
$execute if score #sword_rally temp matches 3 run execute as @s run function combat:deal/damage_deal {"rate":"60","type":"physic","player":"$(player)","interval":"cactus"}
$execute if score #sword_rally temp matches 4 run execute as @s run function combat:deal/damage_deal {"rate":"60","type":"physic","player":"$(player)","interval":"cactus"}
$execute if score #sword_rally temp matches 5 run execute as @s run function combat:deal/damage_deal {"rate":"70","type":"physic","player":"$(player)","interval":"cactus"}
$execute if score #sword_rally temp matches 6 run execute as @s run function combat:deal/damage_deal {"rate":"70","type":"physic","player":"$(player)","interval":"cactus"}







execute if score @s detect_right1 matches 1.. run data modify entity @s PortalCooldown set value 4
scoreboard players set @e[tag=sword_summon] countDown 17
tag @e[tag=sword_summon] remove sword_summon
