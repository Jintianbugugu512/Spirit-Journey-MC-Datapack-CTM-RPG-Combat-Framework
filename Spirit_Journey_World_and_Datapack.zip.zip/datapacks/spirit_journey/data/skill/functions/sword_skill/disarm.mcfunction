
#MP不足则返回
$execute as @a[tag=$(player)] at @s if score @s MP matches ..14 run title @s actionbar "『MP不足,使用§l缴械§f需要消耗§l15MP§f.』"
$execute as @a[tag=$(player)] at @s if score @s MP matches ..14 run playsound block.bone_block.place ambient @s ~ ~ ~ 1 0.8 0
$execute as @a[tag=$(player)] at @s if score @s MP matches ..14 run return 2

#CD没有归0则返回
$execute as @a[tag=$(player)] at @s if score @s disarm_CD matches 1.. run scoreboard players operation #CD temp = @s disarm_CD
$execute as @a[tag=$(player)] at @s if score @s disarm_CD matches 1.. run scoreboard players set #CD temp1 20
$execute as @a[tag=$(player)] at @s if score @s disarm_CD matches 1.. run scoreboard players operation #CD temp /= #CD temp1
$execute as @a[tag=$(player)] at @s if score @s disarm_CD matches 1.. run scoreboard players add #CD temp 1
$execute as @a[tag=$(player)] at @s if score @s disarm_CD matches 1.. run title @s actionbar [{"text":"『缴械』技能CD还剩"},{"score": {"name": "#CD","objective": "temp"},"bold": true},{"text":"s","bold": true}]
$execute as @a[tag=$(player)] at @s if score @s disarm_CD matches 1.. run playsound block.bone_block.break ambient @s ~ ~ ~ 1.0 0.6 0
$execute as @a[tag=$(player)] at @s if score @s disarm_CD matches 1.. run return 3

#设置技能CD,减去MP.
$execute as @a[tag=$(player)] run scoreboard players set @s disarm_CD 200
$execute as @a[tag=$(player)] run scoreboard players remove @s MP 15

#标记锁定范围内的实体为lock
$execute as @a[tag=$(player)] at @s run execute positioned ^ ^ ^1 run tag @e[tag=enemy,tag=!BOSS,tag=!disarm,distance=..2.2] add lock
$execute as @a[tag=$(player)] at @s run execute positioned ^ ^ ^2 run tag @e[tag=enemy,tag=!BOSS,tag=!disarm,distance=..2.2] add lock
$execute as @a[tag=$(player)] at @s run execute positioned ^ ^ ^3 run tag @e[tag=enemy,tag=!BOSS,tag=!disarm,distance=..2.2] add lock
$execute as @a[tag=$(player)] at @s run execute positioned ^ ^ ^3 run tag @e[tag=enemy,tag=!BOSS,tag=!disarm,distance=..2.2] add lock


#粒子与音效
$execute as @a[tag=$(player)] at @s run execute as @e[tag=lock] at @s run particle crit ~ ~ ~ 0.8 1 0.8 0.2 70
$execute as @a[tag=$(player)] at @s run playsound block.anvil.place ambient @s ~ ~ ~ 0.5 0.8 0

#锁定范围内没有敌人则提示玩家
$execute as @a[tag=$(player)] at @s run execute unless entity @e[tag=lock] run title @s actionbar "『技能锁定范围内没有满足要求的敌人』"

#造成伤害后移除lock
$execute as @a[tag=$(player)] at @s run execute as @e[tag=lock,limit=1,sort=nearest] run data merge entity @s {HandItems:[]}
$execute as @a[tag=$(player)] at @s run execute as @e[tag=lock,limit=1,sort=nearest] run tag @s add disarm
tag @e[tag=lock] remove lock




