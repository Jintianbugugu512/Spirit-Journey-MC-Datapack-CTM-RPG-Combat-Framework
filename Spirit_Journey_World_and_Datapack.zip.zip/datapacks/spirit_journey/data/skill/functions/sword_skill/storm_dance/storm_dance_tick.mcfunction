# ==========================================
# 风暴剑舞 - Tick管理
# 每tick执行，管理持续时间和伤害判定
# ==========================================

# 持续时间递减
scoreboard players remove @s temp 1

# 间隔计数递增
scoreboard players add @s temp2 1

# 每tick生成风暴剑气粒子效果（10格圆形范围）
particle sweep_attack ~ ~1 ~ 5 0.5 5 0 8 force
particle crit ~ ~1.5 ~ 5 1 5 0.3 20 force
particle enchanted_hit ~ ~0.5 ~ 5 0.2 5 0.1 15 force
particle cloud ~ ~0.2 ~ 5 0 5 0.2 10 force
particle dust 0.5 0.8 1.0 1.5 ~ ~1 ~ 5 0.5 5 0 25 force

# 每5tick造成一次伤害
execute if score @s temp2 matches 5.. run function skill:sword_skill/storm_dance/storm_dance_damage
execute if score @s temp2 matches 5.. run scoreboard players set @s temp2 0

# 每3秒播放一次音效提醒
execute if score @s temp matches 140 run playsound item.trident.riptide_2 player @a ~ ~ ~ 1.5 1
execute if score @s temp matches 80 run playsound item.trident.riptide_2 player @a ~ ~ ~ 1.5 1
execute if score @s temp matches 20 run playsound item.trident.riptide_2 player @a ~ ~ ~ 1.5 1

# 即将结束提示（剩余1秒）
execute if score @s temp matches 20 run playsound entity.player.attack.sweep player @a ~ ~ ~ 2 2
execute if score @s temp matches 20 run particle explosion ~ ~1 ~ 5 1 5 0 20 force

# 持续时间结束，触发爆炸并清除marker
execute if score @s temp matches ..0 run function skill:sword_skill/storm_dance/storm_dance_explode
execute if score @s temp matches ..0 run kill @s
