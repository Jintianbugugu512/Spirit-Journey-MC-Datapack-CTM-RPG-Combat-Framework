# ==========================================
# 风暴剑舞 - 伤害判定
# 对周围10格最多10个敌人造成40%物理伤害
# ==========================================

# 根据marker的玩家标签判断是哪个玩家的风暴
execute if entity @s[tag=storm_dance_player_1] as @e[tag=enemy,distance=..10,limit=10,sort=nearest] run function combat:deal/damage_deal {rate:"40",type:"physic",player:"player_1",interval:"cactus"}
execute if entity @s[tag=storm_dance_player_2] as @e[tag=enemy,distance=..10,limit=10,sort=nearest] run function combat:deal/damage_deal {rate:"40",type:"physic",player:"player_2",interval:"cactus"}
execute if entity @s[tag=storm_dance_player_3] as @e[tag=enemy,distance=..10,limit=10,sort=nearest] run function combat:deal/damage_deal {rate:"40",type:"physic",player:"player_3",interval:"cactus"}

# 伤害触发粒子效果
particle sweep_attack ~ ~1.5 ~ 6 1 6 0 15 force
particle crit ~ ~1 ~ 5 0.5 5 0.5 30 force
particle enchanted_hit ~ ~1.2 ~ 5 0.5 5 0.2 20 force

# 伤害音效
playsound entity.player.attack.sweep player @a ~ ~ ~ 1.5 1.5
playsound entity.player.attack.crit player @a ~ ~ ~ 1 2
