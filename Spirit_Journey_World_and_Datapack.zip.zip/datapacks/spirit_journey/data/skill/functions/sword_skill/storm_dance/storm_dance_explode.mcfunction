# ==========================================
# 风暴剑舞 - 结束爆炸
# 对周围5格敌人造成150%物理伤害
# ==========================================

# 根据marker的玩家标签判断是哪个玩家的风暴
execute if entity @s[tag=storm_dance_player_1] as @e[tag=enemy,distance=..5] run function combat:deal/damage_deal {rate:"150",type:"physic",player:"player_1",interval:"cactus"}
execute if entity @s[tag=storm_dance_player_2] as @e[tag=enemy,distance=..5] run function combat:deal/damage_deal {rate:"150",type:"physic",player:"player_2",interval:"cactus"}
execute if entity @s[tag=storm_dance_player_3] as @e[tag=enemy,distance=..5] run function combat:deal/damage_deal {rate:"150",type:"physic",player:"player_3",interval:"cactus"}

# 爆炸视觉效果
particle explosion_emitter ~ ~1 ~ 0 0 0 0 3
particle explosion ~ ~1 ~ 2 1 2 0.5 20
particle sweep_attack ~ ~1.5 ~ 3 1 3 0 20 force
particle crit ~ ~1 ~ 3 1 3 0.5 50 force
particle flash ~ ~1 ~ 0 0 0 0 3

# 爆炸音效
playsound entity.generic.explode player @a ~ ~ ~ 2 1.5
playsound entity.player.attack.knockback player @a ~ ~ ~ 2 0.5
playsound entity.lightning_bolt.impact player @a ~ ~ ~ 1 2
