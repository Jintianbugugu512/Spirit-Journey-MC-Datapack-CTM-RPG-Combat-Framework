# ==========================================
# 风暴剑舞 - 剑技能
# 在脚下放置一个风暴剑舞marker
# 持续10秒，每5tick对周围10格最多10个敌人造成40%物理伤害
# ==========================================

# MP不足则返回
$execute as @a[tag=$(player)] at @s if score @s MP matches ..24 run title @s actionbar "『MP不足,使用§l风暴剑舞§f需要消耗§l25MP§f.』"
$execute as @a[tag=$(player)] at @s if score @s MP matches ..24 run playsound block.bone_block.place ambient @s ~ ~ ~ 1 0.8 0
$execute as @a[tag=$(player)] at @s if score @s MP matches ..24 run return 2

# CD没有归0则返回
$execute as @a[tag=$(player)] at @s if score @s storm_dance_CD matches 1.. run scoreboard players operation #CD temp = @s storm_dance_CD
$execute as @a[tag=$(player)] at @s if score @s storm_dance_CD matches 1.. run scoreboard players set #CD temp1 20
$execute as @a[tag=$(player)] at @s if score @s storm_dance_CD matches 1.. run scoreboard players operation #CD temp /= #CD temp1
$execute as @a[tag=$(player)] at @s if score @s storm_dance_CD matches 1.. run scoreboard players add #CD temp 1
$execute as @a[tag=$(player)] at @s if score @s storm_dance_CD matches 1.. run title @s actionbar [{"text":"§l『风暴剑舞』§f技能CD还剩"},{"score": {"name": "#CD","objective": "temp"},"bold": true},{"text":"s","bold": true}]
$execute as @a[tag=$(player)] at @s if score @s storm_dance_CD matches 1.. run playsound block.bone_block.break ambient @s ~ ~ ~ 1.0 0.7 0
$execute as @a[tag=$(player)] at @s if score @s storm_dance_CD matches 1.. run return 3

# 设置技能CD，减去MP
$execute as @a[tag=$(player)] run scoreboard players set @s storm_dance_CD 60
$execute as @a[tag=$(player)] run scoreboard players remove @s MP 25

# 在玩家脚下召唤marker实体
$execute as @a[tag=$(player)] at @s run summon marker ~ ~ ~ {Tags:["storm_dance","storm_dance_new"]}

# 添加玩家ID标签用于溯源
$tag @e[tag=storm_dance_new] add storm_dance_$(player)

# 设置持续时间（10秒 = 200 tick）
scoreboard players set @e[tag=storm_dance_new] temp 200

# 设置间隔计数器（每5tick造成伤害）
scoreboard players set @e[tag=storm_dance_new] temp2 0

# 移除临时标签
tag @e[tag=storm_dance_new] remove storm_dance_new

# 音效和提示
$execute as @a[tag=$(player)] at @s run playsound entity.player.attack.sweep player @a ~ ~ ~ 2 0.5
$execute as @a[tag=$(player)] at @s run playsound item.trident.riptide_3 player @a ~ ~ ~ 2 1
$execute as @a[tag=$(player)] at @s run playsound entity.wither.shoot player @a ~ ~ ~ 1 2
$execute as @a[tag=$(player)] run title @s actionbar {"text":"风暴剑舞 - 爆发！","color":"aqua","bold":true}
