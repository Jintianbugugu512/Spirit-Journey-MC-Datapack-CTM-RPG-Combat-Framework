# ==========================================
# 决斗领域 - Tick管理
# 每tick执行，管理范围内单位的buff
# ==========================================

# 持续时间递减
scoreboard players remove @s temp 1

# 每tick生成决斗领域粒子效果（12格圆形范围）
particle dust 1.0 0.0 0.0 2.0 ~ ~0.1 ~ 6 0 6 0 25 force

# 检测12格范围内的玩家，给予决斗领域buff
execute as @a[distance=..12] run scoreboard players set @s duel_domain_buff 1

# 检测12格范围内的敌人，给予力量II效果（2秒）
execute as @e[tag=enemy,distance=..12] run effect give @s strength 2 1 true

# 每20秒播放一次音效提醒
execute if score @s temp matches 1400 run playsound block.enchantment_table.use player @a ~ ~ ~ 1 0.8
execute if score @s temp matches 1000 run playsound block.enchantment_table.use player @a ~ ~ ~ 1 0.8
execute if score @s temp matches 600 run playsound block.enchantment_table.use player @a ~ ~ ~ 1 0.8
execute if score @s temp matches 200 run playsound block.enchantment_table.use player @a ~ ~ ~ 1 0.8

# 即将结束提示（剩余10秒）
execute if score @s temp matches 200 run playsound entity.ender_dragon.growl player @a ~ ~ ~ 1 2
execute if score @s temp matches 200 run particle explosion ~ ~1 ~ 6 1 6 0 30 force

# 持续时间结束，清除marker
execute if score @s temp matches ..0 run particle explosion_emitter ~ ~1 ~ 0 0 0 0 3
execute if score @s temp matches ..0 run playsound entity.wither.death player @a ~ ~ ~ 1 2
execute if score @s temp matches ..0 run kill @s
