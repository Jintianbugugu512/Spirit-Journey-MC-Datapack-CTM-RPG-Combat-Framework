# ==========================================
# 决斗领域 - 剑技能
# 在脚下放置一个决斗领域marker
# 持续90秒，12格范围内玩家攻击力+15，敌人获得力量II
# ==========================================

# MP不足则返回
$execute as @a[tag=$(player)] at @s if score @s MP matches ..39 run title @s actionbar "『MP不足,使用§l决斗领域§f需要消耗§l40MP§f.』"
$execute as @a[tag=$(player)] at @s if score @s MP matches ..39 run playsound block.bone_block.place ambient @s ~ ~ ~ 1 0.8 0
$execute as @a[tag=$(player)] at @s if score @s MP matches ..39 run return 2

# CD没有归0则返回
$execute as @a[tag=$(player)] at @s if score @s duel_domain_CD matches 1.. run scoreboard players operation #CD temp = @s duel_domain_CD
$execute as @a[tag=$(player)] at @s if score @s duel_domain_CD matches 1.. run scoreboard players set #CD temp1 20
$execute as @a[tag=$(player)] at @s if score @s duel_domain_CD matches 1.. run scoreboard players operation #CD temp /= #CD temp1
$execute as @a[tag=$(player)] at @s if score @s duel_domain_CD matches 1.. run scoreboard players add #CD temp 1
$execute as @a[tag=$(player)] at @s if score @s duel_domain_CD matches 1.. run title @s actionbar [{"text":"§l『决斗领域』§f技能CD还剩"},{"score": {"name": "#CD","objective": "temp"},"bold": true},{"text":"s","bold": true}]
$execute as @a[tag=$(player)] at @s if score @s duel_domain_CD matches 1.. run playsound block.bone_block.break ambient @s ~ ~ ~ 1.0 0.7 0
$execute as @a[tag=$(player)] at @s if score @s duel_domain_CD matches 1.. run return 3

# 设置技能CD，减去MP
$execute as @a[tag=$(player)] run scoreboard players set @s duel_domain_CD 60
$execute as @a[tag=$(player)] run scoreboard players remove @s MP 40

# 在玩家脚下召唤marker实体
$execute as @a[tag=$(player)] at @s run summon marker ~ ~ ~ {Tags:["duel_domain","duel_domain_new"]}

# 添加玩家ID标签用于溯源
$tag @e[tag=duel_domain_new] add duel_domain_$(player)

# 设置持续时间（90秒 = 1800 tick）
scoreboard players set @e[tag=duel_domain_new] temp 1800

# 移除临时标签
tag @e[tag=duel_domain_new] remove duel_domain_new

# 音效和提示
$execute as @a[tag=$(player)] at @s run playsound entity.ender_dragon.growl player @a ~ ~ ~ 1 1.5
$execute as @a[tag=$(player)] at @s run playsound block.enchantment_table.use player @a ~ ~ ~ 1.5 0.8
$execute as @a[tag=$(player)] at @s run playsound entity.wither.spawn player @a ~ ~ ~ 0.5 2
$execute as @a[tag=$(player)] run title @s actionbar {"text":"决斗领域 - 已展开！","color":"red","bold":true}
