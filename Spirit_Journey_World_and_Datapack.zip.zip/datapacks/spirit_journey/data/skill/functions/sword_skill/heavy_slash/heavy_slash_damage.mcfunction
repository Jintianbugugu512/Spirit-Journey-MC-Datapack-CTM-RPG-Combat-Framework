# ==========================================
# 重斩 - 造成伤害
# 执行者：被攻击的敌人
# 参数：player - 玩家标签
# ==========================================

# 从玩家的 temp 记分板读取伤害倍率并存储到 storage
$execute store result storage damage:player_$(id) rate int 1 run scoreboard players get @a[tag=$(player),limit=1] temp

# 调用物理伤害API
$function combat:damage_type/physic_damage with storage damage:player_$(id)
