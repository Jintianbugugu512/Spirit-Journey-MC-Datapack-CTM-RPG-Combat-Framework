# ==========================================
# 重斩 - 执行伤害（player_2）
# 3秒延迟后执行，造成400%倍率伤害
# ==========================================

# 检查目标是否还存在
execute unless entity @e[tag=heavy_slash_target_player_2] run title @a[tag=player_2] actionbar {"text":"重斩 - 目标已消失！","color":"gray"}
execute unless entity @e[tag=heavy_slash_target_player_2] run return 0

# 设置伤害倍率为400%
scoreboard players set @a[tag=player_2] temp 400

# 对目标造成伤害
execute as @e[tag=heavy_slash_target_player_2] run function skill:sword_skill/heavy_slash/heavy_slash_damage {player:"player_2",id:"2"}

# 视觉效果
execute at @e[tag=heavy_slash_target_player_2] run particle minecraft:sweep_attack ~ ~1 ~ 0.8 0.8 0.8 0.1 15
execute at @e[tag=heavy_slash_target_player_2] run particle minecraft:explosion ~ ~1 ~ 0.5 0.5 0.5 0.1 5
execute at @e[tag=heavy_slash_target_player_2] run particle dust 1.0 0.0 0.0 2.5 ~ ~1 ~ 1.2 1.2 1.2 0.1 50
execute at @e[tag=heavy_slash_target_player_2] run particle flash ~ ~1 ~ 0 0 0 0 3

# 音效
execute at @e[tag=heavy_slash_target_player_2] run playsound minecraft:entity.player.attack.sweep player @a ~ ~ ~ 1.5 0.6
execute at @e[tag=heavy_slash_target_player_2] run playsound minecraft:entity.generic.explode player @a ~ ~ ~ 1 1
execute at @e[tag=heavy_slash_target_player_2] run playsound minecraft:entity.lightning_bolt.impact player @a ~ ~ ~ 0.5 1.5

# 显示伤害提示
title @a[tag=player_2] actionbar [{"text":"重斩！","color":"dark_red","bold":true},{"text":" 造成 400% 伤害！","color":"red"}]

# 清除目标标记
tag @e[tag=heavy_slash_target_player_2] remove heavy_slash_target_player_2
