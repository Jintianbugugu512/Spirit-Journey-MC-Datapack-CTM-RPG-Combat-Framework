# ==========================================
# 重斩 - 延迟攻击
# 执行者：玩家
# 功能：延迟3秒后对5格内最近的敌人造成400%伤害
# 参数：player - 玩家标签
# ==========================================

# MP不足则返回
$execute as @a[tag=$(player)] at @s if score @s MP matches ..9 run title @s actionbar "『MP不足,使用§l重斩§f需要消耗§l10MP§f.』"
$execute as @a[tag=$(player)] at @s if score @s MP matches ..9 run playsound block.bone_block.place ambient @s ~ ~ ~ 1 0.8 0
$execute as @a[tag=$(player)] at @s if score @s MP matches ..9 run return 2

# CD没有归0则返回
$execute as @a[tag=$(player)] at @s if score @s heavy_slash_CD matches 1.. run scoreboard players operation #CD temp = @s heavy_slash_CD
$execute as @a[tag=$(player)] at @s if score @s heavy_slash_CD matches 1.. run scoreboard players set #CD temp1 20
$execute as @a[tag=$(player)] at @s if score @s heavy_slash_CD matches 1.. run scoreboard players operation #CD temp /= #CD temp1
$execute as @a[tag=$(player)] at @s if score @s heavy_slash_CD matches 1.. run scoreboard players add #CD temp 1
$execute as @a[tag=$(player)] at @s if score @s heavy_slash_CD matches 1.. run title @s actionbar [{"text":"§l『重斩』§f技能CD还剩"},{"score": {"name": "#CD","objective": "temp"},"bold": true},{"text":"s","bold": true}]
$execute as @a[tag=$(player)] at @s if score @s heavy_slash_CD matches 1.. run playsound block.bone_block.break ambient @s ~ ~ ~ 1.0 0.7 0
$execute as @a[tag=$(player)] at @s if score @s heavy_slash_CD matches 1.. run return 3

# 检查附近是否有敌人
$execute as @a[tag=$(player)] at @s unless entity @e[tag=enemy,distance=..5] run title @s actionbar {"text":"重斩 - 附近没有敌人！","color":"red"}
$execute as @a[tag=$(player)] at @s unless entity @e[tag=enemy,distance=..5] run playsound block.bone_block.place ambient @s ~ ~ ~ 1 0.8 0
$execute as @a[tag=$(player)] at @s unless entity @e[tag=enemy,distance=..5] run return 4

# 消耗MP
$execute as @a[tag=$(player)] run scoreboard players remove @s MP 10

# 设置CD（10秒 = 200tick）
$execute as @a[tag=$(player)] run scoreboard players set @s heavy_slash_CD 200

# 提示蓄力开始
$execute as @a[tag=$(player)] run title @s actionbar {"text":"重斩 - 蓄力中...3秒后释放！","color":"red","bold":true}

# 播放音效
$execute as @a[tag=$(player)] at @s run playsound minecraft:block.enchantment_table.use player @a ~ ~ ~ 1 0.8

# 标记最近的敌人
$execute as @a[tag=$(player)] at @s run tag @e[tag=enemy,limit=1,sort=nearest,distance=..5] add heavy_slash_target_$(player)

# 3秒后执行伤害（60tick = 3秒）
$schedule function skill:sword_skill/heavy_slash/heavy_slash_execute_$(player) 60t
