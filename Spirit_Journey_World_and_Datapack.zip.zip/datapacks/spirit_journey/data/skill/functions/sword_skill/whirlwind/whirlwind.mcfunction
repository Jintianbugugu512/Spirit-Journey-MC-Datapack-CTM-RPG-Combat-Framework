# ==========================================
# 旋风斩击 - 剑技能
# 持续10秒，每2秒自动攻击一次
# 6格范围内最多2个敌人，造成125%物理伤害
# ==========================================

# MP不足则返回
$execute as @a[tag=$(player)] at @s if score @s MP matches ..19 run title @s actionbar "『MP不足,使用§l旋风斩击§f需要消耗§l20MP§f.』"
$execute as @a[tag=$(player)] at @s if score @s MP matches ..19 run playsound block.bone_block.place ambient @s ~ ~ ~ 1 0.8 0
$execute as @a[tag=$(player)] at @s if score @s MP matches ..19 run return 2

# CD没有归0则返回
$execute as @a[tag=$(player)] at @s if score @s whirlwind_CD matches 1.. run scoreboard players operation #CD temp = @s whirlwind_CD
$execute as @a[tag=$(player)] at @s if score @s whirlwind_CD matches 1.. run scoreboard players set #CD temp1 20
$execute as @a[tag=$(player)] at @s if score @s whirlwind_CD matches 1.. run scoreboard players operation #CD temp /= #CD temp1
$execute as @a[tag=$(player)] at @s if score @s whirlwind_CD matches 1.. run scoreboard players add #CD temp 1
$execute as @a[tag=$(player)] at @s if score @s whirlwind_CD matches 1.. run title @s actionbar [{"text":"§l『旋风斩击』§f技能CD还剩"},{"score": {"name": "#CD","objective": "temp"},"bold": true},{"text":"s","bold": true}]
$execute as @a[tag=$(player)] at @s if score @s whirlwind_CD matches 1.. run playsound block.bone_block.break ambient @s ~ ~ ~ 1.0 0.7 0
$execute as @a[tag=$(player)] at @s if score @s whirlwind_CD matches 1.. run return 3

# 设置技能CD，减去MP
$execute as @a[tag=$(player)] run scoreboard players set @s whirlwind_CD 400
$execute as @a[tag=$(player)] run scoreboard players remove @s MP 20

# 激活旋风斩击buff
$execute as @a[tag=$(player)] run tag @s add whirlwind_active
$execute as @a[tag=$(player)] run scoreboard players set @s whirlwind_duration 200

# 音效和视觉效果
$execute as @a[tag=$(player)] at @s run playsound entity.player.attack.sweep player @a ~ ~ ~ 1.5 0.8
$execute as @a[tag=$(player)] at @s run playsound entity.wither.shoot player @a ~ ~ ~ 0.8 1.5
$execute as @a[tag=$(player)] at @s run particle sweep_attack ~ ~1 ~ 2 1 2 0.1 30

# 提示信息
$execute as @a[tag=$(player)] run title @s actionbar {"text":"旋风斩击 - 已激活！","color":"gold","bold":true}
