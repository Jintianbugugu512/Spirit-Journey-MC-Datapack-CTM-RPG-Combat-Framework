# ==========================================
# 旋风斩击 - 单次攻击
# 6格范围内最多2个敌人，造成125%物理伤害
# 参数：id - 玩家ID
# ==========================================

# 标记6格范围内最多2个敌人
tag @e[tag=enemy,distance=..6,limit=2,sort=nearest] add whirlwind_target

# 对标记的敌人造成伤害
$execute as @e[tag=whirlwind_target] run function skill:sword_skill/whirlwind/whirlwind_damage {id:"$(id)"}

# 清除目标标签
tag @e[tag=whirlwind_target] remove whirlwind_target
