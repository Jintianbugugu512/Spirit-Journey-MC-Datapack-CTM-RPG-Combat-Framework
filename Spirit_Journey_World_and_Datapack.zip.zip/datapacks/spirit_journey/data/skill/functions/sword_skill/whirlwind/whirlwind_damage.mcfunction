# ==========================================
# 旋风斩击 - 伤害计算
# 造成125%物理伤害
# 参数：id - 玩家ID
# ==========================================

# 设置伤害倍率为125%
$scoreboard players set @a[tag=player_$(id),limit=1] temp 125

# 调用物理伤害API
$function combat:damage_type/physic_damage with storage damage:player_$(id)
