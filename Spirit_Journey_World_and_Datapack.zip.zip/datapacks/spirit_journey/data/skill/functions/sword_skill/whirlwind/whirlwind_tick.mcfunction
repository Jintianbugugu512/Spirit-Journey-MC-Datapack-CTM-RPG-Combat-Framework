# 旋风斩击 - Tick检测
# 每tick递减计时器，duration能被40整除时触发攻击
# 参数：player - 玩家标签, id - 玩家ID

# 检查是否能被40整除（触发攻击、粒子、音效）
# 200, 160, 120, 80, 40 时触发，共5次
scoreboard players operation @s temp2 = @s whirlwind_duration
scoreboard players operation @s temp2 %= #40 const

# 攻击时显示粒子和音效
execute if score @s temp2 matches 0 if score @s whirlwind_duration matches 1.. at @s run particle sweep_attack ~ ~1 ~ 2 1 2 0.1 20 force
execute if score @s temp2 matches 0 if score @s whirlwind_duration matches 1.. at @s run particle crit ~ ~1 ~ 2 1 2 0.2 15 force
execute if score @s temp2 matches 0 if score @s whirlwind_duration matches 1.. at @s run playsound entity.player.attack.sweep player @a ~ ~ ~ 1 1
execute if score @s temp2 matches 0 if score @s whirlwind_duration matches 1.. at @s run playsound entity.player.attack.crit player @a ~ ~ ~ 0.8 1.2

# 触发攻击
$execute if score @s temp2 matches 0 if score @s whirlwind_duration matches 1.. at @s run function skill:sword_skill/whirlwind/whirlwind_attack {id:"$(id)"}

# 持续时间递减
scoreboard players remove @s whirlwind_duration 1

# 持续时间结束，移除buff
execute if score @s whirlwind_duration matches ..0 run tag @s remove whirlwind_active
execute if score @s whirlwind_duration matches ..0 run title @s actionbar {"text":"旋风斩击 - 结束","color":"gray"}
execute if score @s whirlwind_duration matches ..0 run scoreboard players reset @s whirlwind_duration
