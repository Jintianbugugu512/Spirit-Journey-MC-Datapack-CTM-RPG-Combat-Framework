# 剑气弹幕移动逻辑
# @s = light_bullet armor_stand

# 沿着自己的朝向前进 0.4 格
execute at @s run tp @s ^ ^ ^0.8

# 显示粒子效果
execute at @s run particle dust 1 1 1 1 ~ ~ ~ 0.1 0.1 0.1 0 3 force

# 生存时间计数
scoreboard players add @s temp 1

# 存活 50 tick 后自动消失
execute if score @s temp matches 50.. run kill @s

# 碰到方块消失
execute at @s unless block ~ ~ ~ air run kill @s
