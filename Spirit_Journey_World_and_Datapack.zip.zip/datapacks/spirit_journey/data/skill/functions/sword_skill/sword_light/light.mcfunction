# 召唤第一个弹幕（中间）
execute at @s anchored eyes positioned ^ ^ ^ run summon armor_stand ~ ~ ~ {Tags:["summon","bullet_from_player","light_bullet"],Invisible:1b,Marker:1b,NoGravity:1b,Small:1b}
$execute as @e[tag=summon,limit=1,sort=nearest] at @s rotated as @p[tag=$(player)] run tp @s ~ ~ ~ ~ ~
$tag @e[tag=summon,limit=1,sort=nearest] add light_bullet_$(player)
scoreboard players set @e[tag=summon,limit=1,sort=nearest] temp 0
tag @e[tag=summon,limit=1,sort=nearest] remove summon

# 召唤第二个弹幕（左侧）
execute at @s anchored eyes positioned ^-0.8 ^ ^-0.4 run summon armor_stand ~ ~ ~ {Tags:["summon","bullet_from_player","light_bullet"],Invisible:1b,Marker:1b,NoGravity:1b,Small:1b}
$execute as @e[tag=summon,limit=1,sort=nearest] at @s rotated as @p[tag=$(player)] run tp @s ~ ~ ~ ~ ~
$tag @e[tag=summon,limit=1,sort=nearest] add light_bullet_$(player)
scoreboard players set @e[tag=summon,limit=1,sort=nearest] temp 0
tag @e[tag=summon,limit=1,sort=nearest] remove summon

# 召唤第三个弹幕（右侧）
execute at @s anchored eyes positioned ^0.8 ^ ^-0.4 run summon armor_stand ~ ~ ~ {Tags:["summon","bullet_from_player","light_bullet"],Invisible:1b,Marker:1b,NoGravity:1b,Small:1b}
$execute as @e[tag=summon,limit=1,sort=nearest] at @s rotated as @p[tag=$(player)] run tp @s ~ ~ ~ ~ ~
$tag @e[tag=summon,limit=1,sort=nearest] add light_bullet_$(player)
scoreboard players set @e[tag=summon,limit=1,sort=nearest] temp 0
tag @e[tag=summon,limit=1,sort=nearest] remove summon


