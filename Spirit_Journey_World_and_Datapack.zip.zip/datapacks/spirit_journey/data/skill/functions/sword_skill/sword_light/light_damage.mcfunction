# 剑气伤害 - 直接使用 tag 溯源玩家ID
# @s = 带有 light_bullet_player_$(id) 标签的子弹
# 执行位置：子弹位置

# 先锁定最近的一个敌人并打上临时标签
tag @e[tag=enemy,distance=..2,limit=1,sort=nearest] add light_target

# 检测是否命中新敌人（hit_cooldown=0），如果是则剑气计数+1
execute if entity @e[tag=light_target,scores={hit_cooldown=0}] run scoreboard players add @s sword_light_count 1

# 给锁定的敌人设置 hit_cooldown=10（防止重复计数）
execute as @e[tag=light_target] run scoreboard players set @s hit_cooldown 10

# 造成物理伤害
$execute as @e[tag=light_target] run function combat:deal/damage_deal {"rate":"80","type":"physic","player":"$(player)","interval":"cactus"}

# 给锁定的敌人设置8tick无敌帧（防止重复命中）
execute as @e[tag=light_target] run data modify entity @s PortalCooldown set value 5

# 移除临时标签
tag @e[tag=light_target] remove light_target

# 剑气命中3次后消失
execute if score @s sword_light_count matches 1.. run kill @s
