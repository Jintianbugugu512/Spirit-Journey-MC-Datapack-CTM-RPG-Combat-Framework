#MP不足则返回
tellraw @a[tag=player_1] {"text":"=== 剑气技能被触发 ===","color":"yellow"}
tellraw @a[tag=player_1] [{"text":"MP: ","color":"aqua"},{"score":{"name":"@s","objective":"MP"}}]
execute if score @s MP matches ..4 run title @s actionbar "『MP不足,使用§l剑气§f需要消耗§l5MP§f.』"
execute if score @s MP matches ..4 run playsound block.bone_block.place ambient @s ~ ~ ~ 1 0.8 0
execute if score @s MP matches ..4 run return 2

#设置技能CD,减去MP.
tellraw @a[tag=player_1] {"text":">>> 开始执行剑气效果","color":"green"}
scoreboard players remove @s MP 5
tellraw @a[tag=player_1] {"text":">>> MP已扣除","color":"green"}

#粒子与音效
playsound entity.experience_orb.pickup ambient @s ~ ~ ~ 1 0.68 0
tellraw @a[tag=player_1] {"text":">>> 音效已播放","color":"green"}
particle block minecraft:glass ^ ^1 ^ 1 1 1 0.1 500
tellraw @a[tag=player_1] {"text":">>> 粒子已生成","color":"green"}


# 没有聚气成刃魂盘：最大10层
execute unless entity @s[nbt={Inventory:[{tag:{sd_id:"聚气成刃"}}]}] run scoreboard players add @s[scores={sword_light_count=..9}] sword_light_count 1
execute unless entity @s[nbt={Inventory:[{tag:{sd_id:"聚气成刃"}}]}] run title @s[scores={sword_light_count=10..}] actionbar "『§l剑气§f层数已经叠加至上限§l10§f层.』"

# 有聚气成刃魂盘：最大30层
execute if entity @s[nbt={Inventory:[{tag:{sd_id:"聚气成刃"}}]}] run scoreboard players add @s[scores={sword_light_count=..29}] sword_light_count 1
execute if entity @s[nbt={Inventory:[{tag:{sd_id:"聚气成刃"}}]}] run title @s[scores={sword_light_count=30..}] actionbar "『§l剑气§f层数已经叠加至上限§l30§f层.』"
