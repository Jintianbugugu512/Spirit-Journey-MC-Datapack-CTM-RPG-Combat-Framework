# Bounty Blade 剑动画 - 召唤4把剑
# 以锁定的敌人为中心，4个斜45°方向：东南、西南、东北、西北
# 固定4种剑材质：铁剑、金剑、钻石剑、下界合金剑
# 执行者为被锁定的敌人

# 召唤剑1 - 东南方向 (铁剑)
summon minecraft:item_display ~1 ~0.7 ~1 {item:{id:"iron_sword",Count:1b},Tags:["bounty_sword","bounty_sword_1"],Rotation:[0f,-90f]}

# 召唤剑2 - 西南方向 (金剑)
summon minecraft:item_display ~-1 ~0.7 ~1 {item:{id:"golden_sword",Count:1b},Tags:["bounty_sword","bounty_sword_2"],Rotation:[90f,-90f]}

# 召唤剑3 - 东北方向 (钻石剑)
summon minecraft:item_display ~1 ~0.7 ~-1 {item:{id:"diamond_sword",Count:1b},Tags:["bounty_sword","bounty_sword_3"],Rotation:[-90f,-90f]}

# 召唤剑4 - 西北方向 (下界合金剑)
summon minecraft:item_display ~-1 ~0.7 ~-1 {item:{id:"netherite_sword",Count:1b},Tags:["bounty_sword","bounty_sword_4"],Rotation:[180f,-90f]}

# 设置剑的倒计时（用于控制动画时长）
scoreboard players set @e[tag=bounty_sword] countDown 17

# 粒子效果（围绕敌人的4个角）
particle dust 0.8 0.8 0.2 1.5 ~2 ~0.7 ~2 0.2 0.2 0.2 0.1 20
particle dust 0.8 0.8 0.2 1.5 ~-2 ~0.7 ~2 0.2 0.2 0.2 0.1 20
particle dust 0.8 0.8 0.2 1.5 ~2 ~0.7 ~-2 0.2 0.2 0.2 0.1 20
particle dust 0.8 0.8 0.2 1.5 ~-2 ~0.7 ~-2 0.2 0.2 0.2 0.1 20

# 音效
playsound minecraft:item.trident.throw ambient @a[distance=..10] ~ ~ ~ 1 0.8 0
