# Bounty Blade 剑移动逻辑
# 每tick检测带有 bounty_sword 标签的剑
# 根据 countDown 让剑逐渐向中心移动

# 倒计时递减
scoreboard players remove @s countDown 1

# 根据倒计时移动剑（17 tick -> 0 tick，逐渐靠近中心）
# 剑从周围 (~±2, ~0.7, ~±2) 移动到中心 (~0, ~1.5, ~0)

# 剑1 - 从东南移动到中心
execute if entity @s[tag=bounty_sword_1] run tp @s ~-0.12 ~0.047 ~-0.12

# 剑2 - 从西南移动到中心
execute if entity @s[tag=bounty_sword_2] run tp @s ~0.12 ~0.047 ~-0.12

# 剑3 - 从东北移动到中心
execute if entity @s[tag=bounty_sword_3] run tp @s ~-0.12 ~0.047 ~0.12

# 剑4 - 从西北移动到中心
execute if entity @s[tag=bounty_sword_4] run tp @s ~0.12 ~0.047 ~0.12

# 粒子轨迹
particle dust 0.9 0.9 0.3 0.8 ~ ~ ~ 0.1 0.1 0.1 0 2

# 倒计时结束，剑消失
execute if score @s countDown matches ..0 run particle end_rod ~ ~ ~ 0.3 0.3 0.3 0.1 30
execute if score @s countDown matches ..0 run playsound minecraft:entity.arrow.hit ambient @a[distance=..10] ~ ~ ~ 0.8 1.2 0
execute if score @s countDown matches ..0 run kill @s
