
#MP不足则返回
$execute as @a[tag=$(player)] at @s if score @s MP matches ..9 run title @s actionbar "『MP不足,使用§l悬赏之刃§f需要消耗§l10MP§f.』"
$execute as @a[tag=$(player)] at @s if score @s MP matches ..9 run playsound block.bone_block.place ambient @s ~ ~ ~ 1 0.8 0
$execute as @a[tag=$(player)] at @s if score @s MP matches ..9 run return 2

#CD没有归0则返回
$execute as @a[tag=$(player)] at @s if score @s bounty_blade_CD matches 1.. run scoreboard players operation #CD temp = @s bounty_blade_CD
$execute as @a[tag=$(player)] at @s if score @s bounty_blade_CD matches 1.. run scoreboard players set #CD temp1 20
$execute as @a[tag=$(player)] at @s if score @s bounty_blade_CD matches 1.. run scoreboard players operation #CD temp /= #CD temp1
$execute as @a[tag=$(player)] at @s if score @s bounty_blade_CD matches 1.. run scoreboard players add #CD temp 1
$execute as @a[tag=$(player)] at @s if score @s bounty_blade_CD matches 1.. run title @s actionbar [{"text":"『悬赏之刃』技能CD还剩"},{"score": {"name": "#CD","objective": "temp"},"bold": true},{"text":"s","bold": true}]
$execute as @a[tag=$(player)] at @s if score @s bounty_blade_CD matches 1.. run playsound block.bone_block.break ambient @s ~ ~ ~ 1.0 0.7 0
$execute as @a[tag=$(player)] at @s if score @s bounty_blade_CD matches 1.. run return 3

#设置技能CD,减去MP.
$execute as @a[tag=$(player)] run scoreboard players set @s bounty_blade_CD 80
$execute as @a[tag=$(player)] run scoreboard players remove @s MP 10

#标记锁定范围内的实体为lock_
$execute as @a[tag=$(player)] at @s run execute positioned ^ ^ ^1 run tag @e[tag=enemy,distance=..2.2] add lock_$(player)
$execute as @a[tag=$(player)] at @s run execute positioned ^ ^ ^2 run tag @e[tag=enemy,distance=..2.2] add lock_$(player)
$execute as @a[tag=$(player)] at @s run execute positioned ^ ^ ^3 run tag @e[tag=enemy,distance=..2.2] add lock_$(player)
$execute as @a[tag=$(player)] at @s run execute positioned ^ ^ ^3 run tag @e[tag=enemy,distance=..2.2] add lock_$(player)


#粒子与音效
$execute as @a[tag=$(player)] at @s run execute as @e[tag=lock_$(player)] at @s run particle dust_color_transition 0.5 0.8 0.5 1.0 1.0 1.0 0.0 ~ ~0.5 ~ 0.8 1 0.8 0.2 70
$execute as @a[tag=$(player)] at @s run playsound item.shield.block ambient @s ~ ~ ~ 1 0.7 0

#给最近的锁定敌人添加tag，以它为中心召唤4把剑的动画
$execute as @a[tag=$(player)] at @s run tag @e[tag=lock_$(player),limit=1,sort=nearest] add bounty_target
execute as @e[tag=bounty_target] at @s run function skill:sword_skill/bounty_blade/bounty_blade_summon

#锁定范围内没有敌人则提示玩家
$execute as @a[tag=$(player)] at @s run execute unless entity @e[tag=lock_$(player)] run title @s actionbar "『技能锁定范围内没有敌人』"

#造成伤害后移除lock
$execute as @a[tag=$(player)] at @s run execute as @e[tag=lock_$(player),limit=1,sort=nearest] run scoreboard players set @s stun 20

$execute as @a[tag=$(player)] at @s run execute as @e[tag=lock_$(player),limit=1,sort=nearest] at @s if score @s current_health matches ..7 run summon item ~ ~ ~ {Item:{id:"emerald",Count:6b,tag:{from_map:1b}}}
$execute as @a[tag=$(player)] at @s run execute as @e[tag=lock_$(player),limit=1,sort=nearest] at @s if score @s current_health matches ..7 run summon experience_orb ~1 ~ ~
$execute as @a[tag=$(player)] at @s run execute as @e[tag=lock_$(player),limit=1,sort=nearest] at @s if score @s current_health matches ..7 run summon experience_orb ~ ~ ~1
$execute as @a[tag=$(player)] at @s run execute as @e[tag=lock_$(player),limit=1,sort=nearest] at @s if score @s current_health matches ..7 run summon experience_orb ~1 ~ ~1
$execute as @a[tag=$(player)] at @s run execute as @e[tag=lock_$(player),limit=1,sort=nearest] at @s if score @s current_health matches ..7 run summon experience_orb ~-1 ~ ~-1
execute store result score #bounty temp run random value 1..100
$execute if score #bounty temp matches ..15 run execute as @a[tag=$(player)] at @s run execute as @e[tag=lock_$(player),limit=1,sort=nearest] at @s if score @s current_health matches ..7 run summon item ~ ~ ~ {Item:{id:"minecraft:golden_apple",Count:1b,tag:{from_map:1b}}}

$execute as @a[tag=$(player)] at @s run execute as @e[tag=lock_$(player),limit=1,sort=nearest] run function combat:deal/damage_deal {"rate":"40","type":"true","player":"$(player)","interval":"cactus"}

$execute as @e[tag=bounty] at @s run tp @s ^ ^ ^ facing entity @a[tag=$(player),limit=1]
$tag @e[tag=lock_$(player)] remove lock_$(player)
tag @e[tag=bounty_target] remove bounty_target

say 555






