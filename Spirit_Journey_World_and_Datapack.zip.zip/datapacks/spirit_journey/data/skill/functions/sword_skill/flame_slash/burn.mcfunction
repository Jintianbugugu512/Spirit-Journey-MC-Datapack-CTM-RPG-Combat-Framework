execute store result score #flame_slash fire run scoreboard players get @s fire
execute if score @s fire matches ..0 run scoreboard players set #flame_slash temp 240
execute if score @s fire matches 1.. run scoreboard players set #flame_slash temp 120

scoreboard players operation #flame_slash fire += #flame_slash temp
execute store result entity @s Fire short 1 run scoreboard players get #flame_slash fire