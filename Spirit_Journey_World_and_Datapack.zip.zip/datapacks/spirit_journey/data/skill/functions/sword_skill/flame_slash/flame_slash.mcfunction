#MP不足则返回
tellraw @a[tag=player_1] {"text":"=== 烈焰横扫技能被触发 ===","color":"yellow"}
$execute as @a[tag=$(player)] at @s if score @s MP matches ..9 run title @s actionbar "『MP不足,使用§l烈焰横扫§f需要消耗§l10MP§f.』"
$execute as @a[tag=$(player)] at @s if score @s MP matches ..9 run playsound block.bone_block.place ambient @s ~ ~ ~ 1 0.8 0
$execute as @a[tag=$(player)] at @s if score @s MP matches ..9 run return 2

#CD没有归0则返回
$execute as @a[tag=$(player)] at @s if score @s flame_slash_CD matches 1.. run scoreboard players operation #CD temp = @s flame_slash_CD
$execute as @a[tag=$(player)] at @s if score @s flame_slash_CD matches 1.. run scoreboard players set #CD temp1 20
$execute as @a[tag=$(player)] at @s if score @s flame_slash_CD matches 1.. run scoreboard players operation #CD temp /= #CD temp1
$execute as @a[tag=$(player)] at @s if score @s flame_slash_CD matches 1.. run scoreboard players add #CD temp 1
$execute as @a[tag=$(player)] at @s if score @s flame_slash_CD matches 1.. run title @s actionbar [{"text":"§l『烈焰横扫』§f技能CD还剩"},{"score": {"name": "#CD","objective": "temp"},"bold": true},{"text":"s","bold": true}]
$execute as @a[tag=$(player)] at @s if score @s flame_slash_CD matches 1.. run playsound block.bone_block.break ambient @s ~ ~ ~ 1.0 0.7 0
$execute as @a[tag=$(player)] at @s if score @s flame_slash_CD matches 1.. run return 3

#设置技能CD,减去MP.
$execute as @a[tag=$(player)] run scoreboard players set @s flame_slash_CD 60
$execute as @a[tag=$(player)] run scoreboard players remove @s MP 10
#粒子与音效
$execute as @a[tag=$(player)] at @s run playsound entity.blaze.shoot ambient @s ~ ~ ~ 1 0.8 0
particle flame ^ ^1 ^3.2 -2 1 2 0.1 300


#标记锁定范围内的实体为lock
$execute as @a[tag=$(player)] at @s run execute positioned ^ ^ ^2 run tag @e[tag=enemy,distance=..4] add lock
$execute as @a[tag=$(player)] at @s run execute positioned ^-2 ^ ^1 run tag @e[tag=enemy,distance=..3] add lock
$execute as @a[tag=$(player)] at @s run execute positioned ^2 ^ ^1 run tag @e[tag=enemy,distance=..3] add lock


#锁定范围内没有敌人则提示玩家
# $execute as @a[tag=$(player)] at @s run execute unless entity @e[tag=lock] run title @s actionbar "『技能锁定范围内没有敌人』"

#造成伤害后移除lock
$execute as @a[tag=$(player)] at @s run execute as @e[tag=lock,limit=5,sort=nearest] run function combat:deal/damage_deal {"rate":"70","type":"magic","player":"$(player)","interval":"cactus"}
execute as @e[tag=lock,limit=5,sort=nearest] run function skill:sword_skill/flame_slash/burn

fill ^-5 ^-2 ^ ^5 ^3 ^1 air replace glow_lichen
fill ^-4 ^-2 ^2 ^4 ^3 ^3 air replace glow_lichen



tag @e[tag=lock] remove lock



