scoreboard players operation @s temp3 = @s temp
scoreboard players operation @s temp -= @s temp3
scoreboard players operation @s temp -= @s temp3

scoreboard players operation @s temp3 = @s temp1
scoreboard players operation @s temp1 -= @s temp3
scoreboard players operation @s temp1 -= @s temp3

scoreboard players operation @s temp3 = @s temp2
scoreboard players operation @s temp2 -= @s temp3
scoreboard players operation @s temp2 -= @s temp3

execute at @s run particle sweep_attack ~ ~ ~ 0 0 0 0.1 1

summon text_display ^ ^ ^ {text:'"§1§lGOOD!"',Tags:["MP_shower","MP_shower_"],billboard:center,background:1942251,see_through:true}
scoreboard players set @e[tag=MP_shower] countDown 15
tag @e[tag=MP_shower] remove MP_shower

execute on origin run tag @s add shoter

tp @s ~ ~ ~ facing entity @e[limit=1,tag=shoter]

tag @e[tag=shoter] remove shoter