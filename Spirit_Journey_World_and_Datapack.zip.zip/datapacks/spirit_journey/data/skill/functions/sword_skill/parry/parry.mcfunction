


#CD没有归0则返回
$execute as @a[tag=$(player)] at @s if score @s parry_CD matches 1.. run scoreboard players operation #CD temp = @s parry_CD
$execute as @a[tag=$(player)] at @s if score @s parry_CD matches 1.. run scoreboard players set #CD temp1 20
$execute as @a[tag=$(player)] at @s if score @s parry_CD matches 1.. run scoreboard players operation #CD temp /= #CD temp1
$execute as @a[tag=$(player)] at @s if score @s parry_CD matches 1.. run scoreboard players add #CD temp 1
$execute as @a[tag=$(player)] at @s if score @s parry_CD matches 1.. run title @s actionbar [{"text":"『回弹』技能CD还剩"},{"score": {"name": "#CD","objective": "temp"},"bold": true},{"text":"s","bold": true}]
$execute as @a[tag=$(player)] at @s if score @s parry_CD matches 1.. run playsound block.bone_block.break ambient @s ~ ~ ~ 1.0 0.8 0
$execute as @a[tag=$(player)] at @s if score @s parry_CD matches 1.. run return 3

#设置技能CD
$execute as @a[tag=$(player)] run scoreboard players set @s parry_CD 20

#标记锁定范围内的实体为lock
$execute as @a[tag=$(player)] at @s run execute positioned ^ ^ ^1 run tag @e[distance=..3] add lock
$execute as @a[tag=$(player)] at @s run execute positioned ^ ^ ^2 run tag @e[distance=..3] add lock
$execute as @a[tag=$(player)] at @s run execute positioned ^ ^ ^3 run tag @e[distance=..3] add lock
$execute as @a[tag=$(player)] at @s run execute positioned ^ ^ ^4 run tag @e[distance=..2] add lock





#音效
$execute as @a[tag=$(player)] at @s run playsound entity.player.attack.sweep ambient @s ~ ~ ~ 1 0.7 0


tag @e[tag=lock,tag=!bullet_from_player,type=arrow] add parry_object
tag @e[tag=lock,tag=!bullet_from_player,type=fireball] add parry_object
tag @e[tag=lock,tag=!bullet_from_player,type=small_fireball] add parry_object
tag @e[tag=lock,tag=!bullet_from_player,type=shulker_bullet] add parry_object
tag @e[tag=lock,tag=!bullet_from_player,type=firework_rocket] add parry_object
tag @e[tag=lock,tag=!bullet_from_player,type=trident] add parry_object
tag @e[tag=lock,tag=!bullet_from_player,type=potion] add parry_object


tag @e[tag=lock,tag=bullet_from_enemy] add parry_object



execute as @e[tag=parry_object] at @s run execute store result score @s temp run data get entity @s Motion[0] 100
execute as @e[tag=parry_object] at @s run execute store result score @s temp1 run data get entity @s Motion[1] 100
execute as @e[tag=parry_object] at @s run execute store result score @s temp2 run data get entity @s Motion[2] 100

execute as @e[tag=parry_object] at @s run function skill:sword_skill/parry/parry_object

execute as @e[tag=parry_object] at @s run execute store result entity @s Motion[0] double 0.01 run scoreboard players get @s temp
execute as @e[tag=parry_object] at @s run execute store result entity @s Motion[1] double 0.01 run scoreboard players get @s temp1
execute as @e[tag=parry_object] at @s run execute store result entity @s Motion[2] double 0.01 run scoreboard players get @s temp2

execute if entity @e[tag=parry_object] run scoreboard players add @s MP 20

# 反击回复魂盘：弹反成功时回复4HP
execute if entity @e[tag=parry_object] if entity @s[nbt={Inventory:[{tag:{sd_id:"反击回复"}}]},tag=!overload] run scoreboard players set @s can_be_effect 2
execute if entity @e[tag=parry_object] if entity @s[nbt={Inventory:[{tag:{sd_id:"反击回复"}}]},tag=!overload] run effect give @s minecraft:instant_health 1 0 true
execute if entity @e[tag=parry_object] if entity @s[nbt={Inventory:[{tag:{sd_id:"反击回复"}}]},tag=!overload] run particle heart ~ ~1 ~ 0.3 0.3 0.3 0.1 3 force

tag @e[tag=parry_object] remove parry_object
tag @e[tag=lock] remove lock

