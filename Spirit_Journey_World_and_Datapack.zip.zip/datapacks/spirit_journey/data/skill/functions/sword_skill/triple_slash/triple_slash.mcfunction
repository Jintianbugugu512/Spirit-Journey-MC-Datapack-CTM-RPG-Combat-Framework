#=== 三连斩技能触发 ===

#MP不足则返回
$execute as @a[scores={attack_count_triple_slash=0},tag=$(player)] at @s if score @s MP matches ..9 run title @s actionbar "『MP不足,使用§l剑舞§f需要消耗§l10MP§f.』"
$execute as @a[scores={attack_count_triple_slash=0},tag=$(player)] at @s if score @s MP matches ..9 run playsound block.bone_block.place ambient @s ~ ~ ~ 1 0.8 0
$execute as @a[scores={attack_count_triple_slash=0},tag=$(player)] at @s if score @s MP matches ..9 run return 2

#CD没有归0则返回
$execute as @a[scores={attack_count_triple_slash=0},tag=$(player)] at @s if score @s triple_slash_CD matches 1.. run scoreboard players operation #CD temp = @s triple_slash_CD
$execute as @a[scores={attack_count_triple_slash=0},tag=$(player)] at @s if score @s triple_slash_CD matches 1.. run scoreboard players set #CD temp1 20
$execute as @a[scores={attack_count_triple_slash=0},tag=$(player)] at @s if score @s triple_slash_CD matches 1.. run scoreboard players operation #CD temp /= #CD temp1
$execute as @a[scores={attack_count_triple_slash=0},tag=$(player)] at @s if score @s triple_slash_CD matches 1.. run scoreboard players add #CD temp 1
$execute as @a[scores={attack_count_triple_slash=0},tag=$(player)] at @s if score @s triple_slash_CD matches 1.. run title @s actionbar [{"text":"『剑舞』技能CD还剩"},{"score": {"name": "#CD","objective": "temp"},"bold": true},{"text":"s","bold": true}]
$execute as @a[scores={attack_count_triple_slash=0},tag=$(player)] at @s if score @s triple_slash_CD matches 1.. run playsound block.bone_block.break ambient @s ~ ~ ~ 1.0 0.8 0
$execute as @a[scores={attack_count_triple_slash=0},tag=$(player)] at @s if score @s triple_slash_CD matches 1.. run return 3

#设置技能CD,减去MP.
$execute as @a[scores={attack_count_triple_slash=0},tag=$(player)] run scoreboard players set @s triple_slash_CD 40
$execute as @a[scores={attack_count_triple_slash=0},tag=$(player)] run scoreboard players remove @s MP 10

#标记锁定范围内的实体为lock
$execute as @a[tag=$(player)] at @s run execute positioned ^ ^ ^1 run tag @e[tag=enemy,distance=..3] add lock
$execute as @a[tag=$(player)] at @s run execute positioned ^ ^ ^2 run tag @e[tag=enemy,distance=..3] add lock
$execute as @a[tag=$(player)] at @s run execute positioned ^ ^ ^3 run tag @e[tag=enemy,distance=..3] add lock
$execute as @a[tag=$(player)] at @s run execute positioned ^ ^ ^4 run tag @e[tag=enemy,distance=..3] add lock

#粒子与音效
$execute as @a[tag=$(player)] at @s run particle sweep_attack ^ ^1 ^2.2 -2 1 0.8 0.1 30
$execute as @a[tag=$(player)] at @s run playsound entity.player.attack.sweep ambient @s ~ ~ ~ 1 0.8 0

#锁定范围内没有敌人则提示玩家
$execute as @a[scores={attack_count_triple_slash=0},tag=$(player)] at @s run execute unless entity @e[tag=lock] run title @s actionbar "『技能锁定范围内没有敌人』"

#造成伤害后移除lock
$execute as @a[tag=$(player)] at @s run execute as @e[tag=lock,limit=3,sort=nearest] run function combat:deal/damage_deal {"rate":"70","type":"physic","player":"$(player)","interval":"cactus"}
tag @e[tag=lock] remove lock

#次数+1
$execute as @a[tag=$(player)] at @s run scoreboard players add @s attack_count_triple_slash 1

say triple slash