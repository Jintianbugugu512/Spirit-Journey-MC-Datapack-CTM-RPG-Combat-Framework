# 第二击 - CD=36时触发
$execute if score @s triple_slash_CD matches 36 if score @s attack_count_triple_slash matches 1 run function skill:sword_skill/triple_slash/triple_slash with storage damage:$(player)

# 第三击 - CD=32时触发
$execute if score @s triple_slash_CD matches 32 if score @s attack_count_triple_slash matches 2 run function skill:sword_skill/triple_slash/triple_slash with storage damage:$(player)

# 三连斩结束 - CD=31时重置计数器
execute if score @s triple_slash_CD matches 31 run scoreboard players set @s attack_count_triple_slash 0

say triple_slash_trigger
