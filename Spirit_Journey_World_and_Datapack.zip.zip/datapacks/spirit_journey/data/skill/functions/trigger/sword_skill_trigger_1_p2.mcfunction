# 剑系技能触发器 1 - player_2
# 检测末影箱槽位 18

# 槽位 18 - 剑系技能
execute if entity @s[nbt={EnderItems:[{Slot:18b,tag:{skill_id:"三连斩"}}]}] run scoreboard players set @s attack_count_triple_slash 0
execute if entity @s[nbt={EnderItems:[{Slot:18b,tag:{skill_id:"三连斩"}}]}] at @s run function skill:sword_skill/triple_slash/triple_slash with storage damage:player_2
execute if entity @s[nbt={EnderItems:[{Slot:18b,tag:{skill_id:"缴械"}}]}] at @s run function skill:sword_skill/disarm with storage damage:player_2
execute if entity @s[nbt={EnderItems:[{Slot:18b,tag:{skill_id:"悬赏之刃"}}]}] at @s run function skill:sword_skill/bounty_blade/bounty_blade with storage damage:player_2
execute if entity @s[nbt={EnderItems:[{Slot:18b,tag:{skill_id:"弹反"}}]}] at @s run function skill:sword_skill/parry/parry with storage damage:player_2
execute if entity @s[nbt={EnderItems:[{Slot:18b,tag:{skill_id:"烈焰横扫"}}]}] at @s run function skill:sword_skill/flame_slash/flame_slash with storage damage:player_2
execute if entity @s[nbt={EnderItems:[{Slot:18b,tag:{skill_id:"剑气"}}]}] at @s run function skill:sword_skill/sword_light/sword_light with storage damage:player_2
execute if entity @s[nbt={EnderItems:[{Slot:18b,tag:{skill_id:"万剑归宗"}}]}] at @s run function skill:sword_skill/sword_rally/sword_rally with storage damage:player_2
execute if entity @s[nbt={EnderItems:[{Slot:18b,tag:{skill_id:"风暴剑舞"}}]}] at @s run function skill:sword_skill/storm_dance/storm_dance with storage damage:player_2
execute if entity @s[nbt={EnderItems:[{Slot:18b,tag:{skill_id:"重斩"}}]}] at @s run function skill:sword_skill/heavy_slash/heavy_slash_start with storage damage:player_2
execute if entity @s[nbt={EnderItems:[{Slot:18b,tag:{skill_id:"决斗领域"}}]}] at @s run function skill:sword_skill/duel_domain/duel_domain with storage damage:player_2
execute if entity @s[nbt={EnderItems:[{Slot:18b,tag:{skill_id:"旋风斩"}}]}] at @s run function skill:sword_skill/whirlwind/whirlwind with storage damage:player_2

# 槽位 18 - 通用技能
execute if entity @s[nbt={EnderItems:[{Slot:18b,tag:{skill_id:"冲刺"}}]}] at @s run function skill:other_skill/airdash/airdash with storage damage:player_2
execute if entity @s[nbt={EnderItems:[{Slot:18b,tag:{skill_id:"后撤"}}]}] at @s run function skill:other_skill/airdash/drop_step with storage damage:player_2
execute if entity @s[nbt={EnderItems:[{Slot:18b,tag:{skill_id:"圣盾"}}]}] at @s run function skill:other_skill/sacred_shield/sacred_shield with storage damage:player_2
execute if entity @s[nbt={EnderItems:[{Slot:18b,tag:{skill_id:"震荡波"}}]}] at @s run function skill:other_skill/shockwave/shockwave with storage damage:player_2
execute if entity @s[nbt={EnderItems:[{Slot:18b,tag:{skill_id:"御血"}}]}] at @s run function skill:other_skill/blood/blood with storage damage:player_2
execute if entity @s[nbt={EnderItems:[{Slot:18b,tag:{skill_id:"紫晶高亮"}}]}] at @s run function skill:other_skill/amethyst_highlight/amethyst_highlight with storage damage:player_2
