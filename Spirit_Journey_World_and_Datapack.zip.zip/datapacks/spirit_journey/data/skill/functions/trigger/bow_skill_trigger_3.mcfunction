# 弩系技能触发器 3 (右键 + 潜行)
# 检测末影箱槽位 23

# 槽位 23 - 弩系技能
$execute if entity @s[nbt={EnderItems:[{Slot:23b,tag:{skill_id:"狙击"}}]}] at @s run function skill:bow_skill/snipe/snipe with storage damage:$(player)
$execute if entity @s[nbt={EnderItems:[{Slot:23b,tag:{skill_id:"快速装填"}}]}] at @s run function skill:bow_skill/quickly_load/quickly_load with storage damage:$(player)
$execute if entity @s[nbt={EnderItems:[{Slot:23b,tag:{skill_id:"凝滞弹"}}]}] at @s run function skill:bow_skill/stasis_shot/stasis_shot with storage damage:$(player)
$execute if entity @s[nbt={EnderItems:[{Slot:23b,tag:{skill_id:"加农炮"}}]}] at @s run function skill:bow_skill/cannon/cannon with storage damage:$(player)
$execute if entity @s[nbt={EnderItems:[{Slot:23b,tag:{skill_id:"高压弹"}}]}] at @s run function skill:bow_skill/high_pressure_shot/high_pressure_shot with storage damage:$(player)
$execute if entity @s[nbt={EnderItems:[{Slot:23b,tag:{skill_id:"点火"}}]}] at @s run function skill:bow_skill/ignite/ignite with storage damage:$(player)
$execute if entity @s[nbt={EnderItems:[{Slot:23b,tag:{skill_id:"穿甲雷"}}]}] at @s run function skill:bow_skill/armor_piercing_mine/summon with storage damage:$(player)

# 槽位 23 - 通用技能
$execute if entity @s[nbt={EnderItems:[{Slot:23b,tag:{skill_id:"紫晶标记"}}]}] at @s run function skill:other_skill/amethyst_sign/amethyst_sign with storage damage:$(player)
$execute if entity @s[nbt={EnderItems:[{Slot:23b,tag:{skill_id:"炎爆术"}}]}] at @s run function skill:stick_skill/flame_blast/flame_blast with storage damage:$(player)
$execute if entity @s[nbt={EnderItems:[{Slot:23b,tag:{skill_id:"冲刺"}}]}] at @s run function skill:other_skill/airdash/airdash with storage damage:$(player)
$execute if entity @s[nbt={EnderItems:[{Slot:23b,tag:{skill_id:"后撤"}}]}] at @s run function skill:other_skill/airdash/drop_step with storage damage:$(player)
$execute if entity @s[nbt={EnderItems:[{Slot:23b,tag:{skill_id:"圣盾"}}]}] at @s run function skill:other_skill/sacred_shield/sacred_shield with storage damage:$(player)
$execute if entity @s[nbt={EnderItems:[{Slot:23b,tag:{skill_id:"震荡波"}}]}] at @s run function skill:other_skill/shockwave/shockwave with storage damage:$(player)
$execute if entity @s[nbt={EnderItems:[{Slot:23b,tag:{skill_id:"御血"}}]}] at @s run function skill:other_skill/blood/blood with storage damage:$(player)
$execute if entity @s[nbt={EnderItems:[{Slot:23b,tag:{skill_id:"紫晶高亮"}}]}] at @s run function skill:other_skill/amethyst_highlight/amethyst_highlight with storage damage:$(player)
