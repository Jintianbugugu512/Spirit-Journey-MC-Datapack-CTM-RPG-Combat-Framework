# 剑系技能触发器 3 (右键 + 潜行)
# 检测末影箱槽位 20

# 根据玩家标签调用对应的玩家专用触发器
execute if entity @s[tag=player_1] run function skill:trigger/sword_skill_trigger_3_p1
execute if entity @s[tag=player_2] run function skill:trigger/sword_skill_trigger_3_p2
execute if entity @s[tag=player_3] run function skill:trigger/sword_skill_trigger_3_p3
