# 剑系技能触发器 2 (跳跃 + 潜行)
# 检测末影箱槽位 19

# 根据玩家标签调用对应的玩家专用触发器
execute if entity @s[tag=player_1] run function skill:trigger/sword_skill_trigger_2_p1
execute if entity @s[tag=player_2] run function skill:trigger/sword_skill_trigger_2_p2
execute if entity @s[tag=player_3] run function skill:trigger/sword_skill_trigger_2_p3
