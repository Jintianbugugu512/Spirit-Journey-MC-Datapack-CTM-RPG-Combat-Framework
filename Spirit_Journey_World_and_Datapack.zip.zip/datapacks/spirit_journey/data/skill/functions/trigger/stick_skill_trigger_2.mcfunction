# 法杖系技能触发器 2 (跳跃 + 潜行)
# 检测末影箱槽位 25

# 槽位 25 - 法杖系技能
$execute if entity @s[nbt={EnderItems:[{Slot:25b,tag:{skill_id:"弱化弹"}}]}] at @s run function skill:stick_skill/weakness_shot/weakness_shot with storage damage:$(player)
$execute if entity @s[nbt={EnderItems:[{Slot:25b,tag:{skill_id:"暗影领域"}}]}] at @s run function skill:stick_skill/shadow_field/shadow_field with storage damage:$(player)
$execute if entity @s[nbt={EnderItems:[{Slot:25b,tag:{skill_id:"噬魂"}}]}] at @s run function skill:stick_skill/soul_blast/soul_blast with storage damage:$(player)
$execute if entity @s[nbt={EnderItems:[{Slot:25b,tag:{skill_id:"游荡灯笼"}}]}] at @s run function skill:stick_skill/wandering_lantern/wandering_lantern with storage damage:$(player)
$execute if entity @s[nbt={EnderItems:[{Slot:25b,tag:{skill_id:"天降甘露"}}]}] at @s run function skill:stick_skill/nectar/nectar with storage damage:$(player)
$execute if entity @s[nbt={EnderItems:[{Slot:25b,tag:{skill_id:"火焰喷射"}}]}] at @s run function skill:stick_skill/flame_spray/flame_spray with storage damage:$(player)

# 槽位 25 - 通用技能
$execute if entity @s[nbt={EnderItems:[{Slot:25b,tag:{skill_id:"紫晶标记"}}]}] at @s run function skill:other_skill/amethyst_sign/amethyst_sign with storage damage:$(player)
$execute if entity @s[nbt={EnderItems:[{Slot:25b,tag:{skill_id:"炎爆术"}}]}] at @s run function skill:stick_skill/flame_blast/flame_blast with storage damage:$(player)
$execute if entity @s[nbt={EnderItems:[{Slot:25b,tag:{skill_id:"冲刺"}}]}] at @s run function skill:other_skill/airdash/airdash with storage damage:$(player)
$execute if entity @s[nbt={EnderItems:[{Slot:25b,tag:{skill_id:"后撤"}}]}] at @s run function skill:other_skill/airdash/drop_step with storage damage:$(player)
$execute if entity @s[nbt={EnderItems:[{Slot:25b,tag:{skill_id:"圣盾"}}]}] at @s run function skill:other_skill/sacred_shield/sacred_shield with storage damage:$(player)
$execute if entity @s[nbt={EnderItems:[{Slot:25b,tag:{skill_id:"震荡波"}}]}] at @s run function skill:other_skill/shockwave/shockwave with storage damage:$(player)
$execute if entity @s[nbt={EnderItems:[{Slot:25b,tag:{skill_id:"御血"}}]}] at @s run function skill:other_skill/blood/blood with storage damage:$(player)
$execute if entity @s[nbt={EnderItems:[{Slot:25b,tag:{skill_id:"紫晶高亮"}}]}] at @s run function skill:other_skill/amethyst_highlight/amethyst_highlight with storage damage:$(player)
