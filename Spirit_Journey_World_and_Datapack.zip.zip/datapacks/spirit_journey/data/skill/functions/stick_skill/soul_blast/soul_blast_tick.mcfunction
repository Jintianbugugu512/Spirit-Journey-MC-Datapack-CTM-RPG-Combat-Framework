# ==========================================
# 魂灵爆破 - Tick管理
# 前6秒蓄力，然后4次爆炸，第7秒死亡
# ==========================================

# 总生命时间递减
scoreboard players remove @s temp 1

# 延迟计数递减
scoreboard players remove @s temp2 1

# 蓄力阶段粒子效果（前6秒）
execute if score @s temp2 matches 1.. run particle soul_fire_flame ~ ~ ~ 0.3 0.3 0.3 0.05 3 force
execute if score @s temp2 matches 1.. run particle soul ~ ~ ~ 0.5 0.5 0.5 0.02 5 force
execute if score @s temp2 matches 1.. run particle witch ~ ~ ~ 0.4 0.4 0.4 0 2 force
execute if score @s temp2 matches 1.. run particle end_rod ~ ~ ~ 0.2 0.2 0.2 0.05 2 force

# 每秒播放蓄力音效
execute if score @s temp2 matches 100 run playsound block.beacon.ambient player @a ~ ~ ~ 0.5 2
execute if score @s temp2 matches 80 run playsound block.beacon.ambient player @a ~ ~ ~ 0.5 2
execute if score @s temp2 matches 60 run playsound block.beacon.ambient player @a ~ ~ ~ 0.5 2
execute if score @s temp2 matches 40 run playsound block.beacon.ambient player @a ~ ~ ~ 0.5 2
execute if score @s temp2 matches 20 run playsound block.beacon.ambient player @a ~ ~ ~ 0.5 2

# 延迟结束，开始爆炸阶段
execute if score @s temp2 matches 0 run scoreboard players set @s temp3 0

# 爆炸阶段（每5tick爆炸一次，共4次）
execute if score @s temp2 matches ..-1 run scoreboard players add @s temp3 1
execute if score @s temp2 matches ..-1 if score @s temp3 matches 5 run function skill:stick_skill/soul_blast/soul_blast_explode
execute if score @s temp2 matches ..-1 if score @s temp3 matches 5 run scoreboard players set @s temp3 0

# 第7秒死亡
execute if score @s temp matches ..0 run particle explosion ~ ~ ~ 0 0 0 0 1
execute if score @s temp matches ..0 run kill @s
