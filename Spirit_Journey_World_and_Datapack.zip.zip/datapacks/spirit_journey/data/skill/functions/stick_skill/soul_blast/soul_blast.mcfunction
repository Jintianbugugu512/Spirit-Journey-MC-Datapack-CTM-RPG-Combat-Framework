# ==========================================
# 魂灵爆破 - 杖技能
# 在天空放置一个延迟爆破marker
# 延迟6秒后爆炸，每5tick造成一次伤害，共4次
# 范围5格，最多4人，造成175%魔法伤害和2秒眩晕
# ==========================================

# MP不足则返回
$execute as @a[tag=$(player)] at @s if score @s MP matches ..34 run title @s actionbar "『MP不足,使用§l魂灵爆破§f需要消耗§l35MP§f.』"
$execute as @a[tag=$(player)] at @s if score @s MP matches ..34 run playsound block.bone_block.place ambient @s ~ ~ ~ 1 0.8 0
$execute as @a[tag=$(player)] at @s if score @s MP matches ..34 run return 2

# CD没有归0则返回
$execute as @a[tag=$(player)] at @s if score @s soul_blast_CD matches 1.. run scoreboard players operation #CD temp = @s soul_blast_CD
$execute as @a[tag=$(player)] at @s if score @s soul_blast_CD matches 1.. run scoreboard players set #CD temp1 20
$execute as @a[tag=$(player)] at @s if score @s soul_blast_CD matches 1.. run scoreboard players operation #CD temp /= #CD temp1
$execute as @a[tag=$(player)] at @s if score @s soul_blast_CD matches 1.. run scoreboard players add #CD temp 1
$execute as @a[tag=$(player)] at @s if score @s soul_blast_CD matches 1.. run title @s actionbar [{"text":"§l『魂灵爆破』§f技能CD还剩"},{"score": {"name": "#CD","objective": "temp"},"bold": true},{"text":"s","bold": true}]
$execute as @a[tag=$(player)] at @s if score @s soul_blast_CD matches 1.. run playsound block.bone_block.break ambient @s ~ ~ ~ 1.0 0.7 0
$execute as @a[tag=$(player)] at @s if score @s soul_blast_CD matches 1.. run return 3

# 设置技能CD，减去MP
$execute as @a[tag=$(player)] run scoreboard players set @s soul_blast_CD 60
$execute as @a[tag=$(player)] run scoreboard players remove @s MP 35

# 在玩家当前位置召唤marker实体
$execute as @a[tag=$(player)] at @s run summon marker ~ ~ ~ {Tags:["soul_blast","soul_blast_new"]}

# 添加玩家ID标签用于溯源
$tag @e[tag=soul_blast_new] add soul_blast_$(player)

# 设置总生命时间（7秒 = 140 tick）
scoreboard players set @e[tag=soul_blast_new] temp 140

# 设置延迟时间（6秒 = 120 tick）
scoreboard players set @e[tag=soul_blast_new] temp2 120

# 设置爆炸计数器（用于4次爆炸）
scoreboard players set @e[tag=soul_blast_new] temp3 0

# 移除临时标签
tag @e[tag=soul_blast_new] remove soul_blast_new

# 音效和提示
$execute as @a[tag=$(player)] at @s run playsound entity.wither.spawn player @a ~ ~ ~ 1 2
$execute as @a[tag=$(player)] at @s run playsound entity.shulker.shoot player @a ~ ~ ~ 1.5 0.8
$execute as @a[tag=$(player)] run title @s actionbar {"text":"魂灵爆破 - 已放置！","color":"light_purple","bold":true}
