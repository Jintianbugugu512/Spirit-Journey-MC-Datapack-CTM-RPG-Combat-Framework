# ==========================================
# 魂灵爆破 - 爆炸效果
# 对5格范围最多4个敌人造成175%魔法伤害和2秒眩晕
# ==========================================

# 标记范围内最多4个敌人
tag @e[tag=enemy,distance=..5,limit=4,sort=nearest] add soul_blast_target

# 根据marker的玩家标签判断是哪个玩家的魂灵爆破
execute if entity @s[tag=soul_blast_player_1] as @e[tag=soul_blast_target] run function combat:deal/damage_deal {rate:"175",type:"magic",player:"player_1",interval:"cactus"}
execute if entity @s[tag=soul_blast_player_2] as @e[tag=soul_blast_target] run function combat:deal/damage_deal {rate:"175",type:"magic",player:"player_2",interval:"cactus"}
execute if entity @s[tag=soul_blast_player_3] as @e[tag=soul_blast_target] run function combat:deal/damage_deal {rate:"175",type:"magic",player:"player_3",interval:"cactus"}

# 给目标添加眩晕效果（2秒 = 40 tick）
execute as @e[tag=soul_blast_target] run scoreboard players set @s stun 40

# 清除目标标签
tag @e[tag=soul_blast_target] remove soul_blast_target

# 爆炸视觉效果（坚守者咆哮粒子）
particle sonic_boom ~ ~1 ~ 0 0 0 0 1
particle explosion ~ ~ ~ 1 1 1 0.5 10
particle soul_fire_flame ~ ~ ~ 2 2 2 0.2 50
particle soul ~ ~ ~ 2.5 2.5 2.5 0.1 40
particle end_rod ~ ~ ~ 2 2 2 0.3 30

# 爆炸音效
playsound entity.shulker_bullet.hit player @a ~ ~ ~ 2 0.8
playsound entity.generic.explode player @a ~ ~ ~ 1.5 1.5
playsound block.respawn_anchor.deplete player @a ~ ~ ~ 1 1.5
