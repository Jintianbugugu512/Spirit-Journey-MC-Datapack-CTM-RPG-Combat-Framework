# ==========================================
# 弱化弹 - 弩技能
# 向前方射出暗能量弹，碰撞后爆炸
# 4格范围内造成60%魔法伤害，最多5人
# 对命中敌人施加虚弱II效果10秒
# ==========================================

# MP不足则返回
$execute as @a[tag=$(player)] at @s if score @s MP matches ..17 run title @s actionbar "『MP不足,使用§l弱化弹§f需要消耗§l18MP§f.』"
$execute as @a[tag=$(player)] at @s if score @s MP matches ..17 run playsound block.bone_block.place ambient @s ~ ~ ~ 1 0.8 0
$execute as @a[tag=$(player)] at @s if score @s MP matches ..17 run return 2

# CD没有归0则返回
$execute as @a[tag=$(player)] at @s if score @s weakness_shot_CD matches 1.. run scoreboard players operation #CD temp = @s weakness_shot_CD
$execute as @a[tag=$(player)] at @s if score @s weakness_shot_CD matches 1.. run scoreboard players set #CD temp1 20
$execute as @a[tag=$(player)] at @s if score @s weakness_shot_CD matches 1.. run scoreboard players operation #CD temp /= #CD temp1
$execute as @a[tag=$(player)] at @s if score @s weakness_shot_CD matches 1.. run scoreboard players add #CD temp 1
$execute as @a[tag=$(player)] at @s if score @s weakness_shot_CD matches 1.. run title @s actionbar [{"text":"§l『弱化弹』§f技能CD还剩"},{"score": {"name": "#CD","objective": "temp"},"bold": true},{"text":"s","bold": true}]
$execute as @a[tag=$(player)] at @s if score @s weakness_shot_CD matches 1.. run playsound block.bone_block.break ambient @s ~ ~ ~ 1.0 0.7 0
$execute as @a[tag=$(player)] at @s if score @s weakness_shot_CD matches 1.. run return 3

# 设置技能CD，减去MP
$execute as @a[tag=$(player)] run scoreboard players set @s weakness_shot_CD 200
$execute as @a[tag=$(player)] run scoreboard players remove @s MP 18

# 音效
$execute as @a[tag=$(player)] at @s run playsound entity.witch.throw ambient @a ~ ~ ~ 1 0.8 0
$execute as @a[tag=$(player)] at @s run playsound entity.enderman.teleport ambient @a ~ ~ ~ 0.6 1.5 0

# 召唤光灵箭（暗能量弹）
$execute as @a[tag=$(player)] at @s anchored eyes run summon spectral_arrow ^ ^ ^1 {Tags:["summon","bullet_from_player","weakness_shot_bullet"],NoGravity:1b,Glowing:1b,PortalCooldown:100,PierceLevel:10,damage:0,crit:false,Color:5570560}

# 添加玩家ID标签用于溯源
$tag @e[tag=summon] add weakness_shot_bullet_$(player)

# 计算飞行方向（使用临时marker）
execute positioned 0.0 0.0 0.0 run summon marker ^ ^ ^1.2 {Tags:["mmark__"]}
execute as @e[tag=summon] run data modify entity @s Motion set from entity @e[limit=1,tag=mmark__] Pos

# 设置子弹寿命
scoreboard players set @e[tag=summon] temp 100

# 清理临时实体和标签
tag @e[tag=summon] remove summon
kill @e[tag=mmark__,type=marker]
