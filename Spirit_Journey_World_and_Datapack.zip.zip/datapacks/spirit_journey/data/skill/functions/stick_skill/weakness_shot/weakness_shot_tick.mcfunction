# ==========================================
# 弱化弹 - 子弹移动与碰撞检测
# 每tick生成暗能量粒子轨迹
# 检测是否命中敌人
# ==========================================

# 暗能量粒子轨迹（使用暗紫色粒子和灵魂粒子）
particle dust 0.3 0.0 0.5 1.0 ~ ~ ~ 0.1 0.1 0.1 0 5 force
particle soul ~ ~ ~ 0.15 0.15 0.15 0.01 3 force
particle witch ~ ~ ~ 0.1 0.1 0.1 0 2 force

# 子弹寿命递减
scoreboard players remove @s temp 1

# 超时自动清除
execute if score @s temp matches ..0 run kill @s

# 检测是否命中敌人
execute if entity @e[tag=enemy,distance=..1.5] run function skill:stick_skill/weakness_shot/weakness_shot_explosion
