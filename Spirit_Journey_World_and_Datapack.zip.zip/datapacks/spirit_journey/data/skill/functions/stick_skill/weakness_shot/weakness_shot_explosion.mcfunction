# ==========================================
# 弱化弹 - 爆炸效果
# 4格范围内造成伤害和虚弱
# 最多命中5个敌人
# ==========================================

# 标记范围内最多5个敌人
tag @e[tag=enemy,distance=..4,limit=5,sort=nearest] add weakness_shot_target

# 对目标造成伤害 - 根据子弹的玩家ID标签
execute if entity @e[tag=weakness_shot_bullet_player_1,limit=1] as @e[tag=weakness_shot_target] run function combat:deal/damage_deal {rate:"60",type:"magic",player:"player_1",interval:"cactus"}
execute if entity @e[tag=weakness_shot_bullet_player_2,limit=1] as @e[tag=weakness_shot_target] run function combat:deal/damage_deal {rate:"60",type:"magic",player:"player_2",interval:"cactus"}
execute if entity @e[tag=weakness_shot_bullet_player_3,limit=1] as @e[tag=weakness_shot_target] run function combat:deal/damage_deal {rate:"60",type:"magic",player:"player_3",interval:"cactus"}

# 给目标添加虚弱II效果（10秒 = 200tick）
execute as @e[tag=weakness_shot_target] run effect give @s weakness 10 1 false

# 清除目标标签
tag @e[tag=weakness_shot_target] remove weakness_shot_target

# 爆炸视觉效果（暗能量主题）
particle explosion ~ ~ ~ 0.8 0.8 0.8 0.1 8
particle dust 0.3 0.0 0.5 2.0 ~ ~ ~ 1.8 1.8 1.8 0 120
particle soul ~ ~ ~ 2 2 2 0.1 80
particle witch ~ ~ ~ 1.5 1.5 1.5 0.05 60
particle portal ~ ~ ~ 1 1 1 0.3 100

# 音效
playsound entity.generic.explode player @a ~ ~ ~ 1.2 0.8
playsound entity.witch.hurt player @a ~ ~ ~ 1.5 0.8
playsound entity.enderman.scream player @a ~ ~ ~ 0.8 1.5

# 清除子弹
kill @s
