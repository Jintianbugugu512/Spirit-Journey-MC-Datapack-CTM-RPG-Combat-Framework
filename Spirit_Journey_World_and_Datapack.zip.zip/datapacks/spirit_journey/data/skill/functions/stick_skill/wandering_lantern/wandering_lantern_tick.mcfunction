# ==========================================
# 漂泊之灯 - Tick管理
# 每tick执行，管理持续时间和魔法弹发射
# ==========================================

# 持续时间递减
scoreboard players remove @s temp 1

# 发射计时器递增
scoreboard players add @s temp2 1

# 每tick生成蓝色火焰粒子效果（已减少粒子数量）
particle soul_fire_flame ~ ~0.5 ~ 0.1 0.15 0.1 0.01 1 force
particle dust 0.3 0.7 1.0 0.8 ~ ~0.5 ~ 0.2 0.2 0.2 0 1 force

# 每40tick（2秒）发射魔法弹
execute if score @s temp2 matches 40.. run function skill:stick_skill/wandering_lantern/wandering_lantern_shoot
execute if score @s temp2 matches 40.. run scoreboard players set @s temp2 0

# 每30秒播放一次音效提醒
execute if score @s temp matches 1400 run playsound block.beacon.ambient player @a ~ ~ ~ 0.8 1.5
execute if score @s temp matches 1000 run playsound block.beacon.ambient player @a ~ ~ ~ 0.8 1.5
execute if score @s temp matches 600 run playsound block.beacon.ambient player @a ~ ~ ~ 0.8 1.5

# 即将结束提示（剩余10秒）
execute if score @s temp matches 200 run playsound block.beacon.deactivate player @a ~ ~ ~ 1 1.5
execute if score @s temp matches 200 run particle soul ~ ~1 ~ 0.5 0.5 0.5 0.1 50 force

# 持续时间结束，清除display
execute if score @s temp matches ..0 run particle soul_fire_flame ~ ~1 ~ 0.3 0.5 0.3 0.05 30
execute if score @s temp matches ..0 run playsound block.beacon.deactivate player @a ~ ~ ~ 1.5 0.8
execute if score @s temp matches ..0 run kill @s
