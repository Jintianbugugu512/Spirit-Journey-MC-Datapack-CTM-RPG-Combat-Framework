# ==========================================
# 漂泊之灯 - 杖技能
# 在脚下放置一个灵魂灯笼display
# 持续100秒，每2秒锁定12格内随机1个敌人发射魔法弹
# 造成45%魔法伤害
# ==========================================

# MP不足则返回
$execute as @a[tag=$(player)] at @s if score @s MP matches ..39 run title @s actionbar "『MP不足,使用§l漂泊之灯§f需要消耗§l40MP§f.』"
$execute as @a[tag=$(player)] at @s if score @s MP matches ..39 run playsound block.bone_block.place ambient @s ~ ~ ~ 1 0.8 0
$execute as @a[tag=$(player)] at @s if score @s MP matches ..39 run return 2

# CD没有归0则返回
$execute as @a[tag=$(player)] at @s if score @s wandering_lantern_CD matches 1.. run scoreboard players operation #CD temp = @s wandering_lantern_CD
$execute as @a[tag=$(player)] at @s if score @s wandering_lantern_CD matches 1.. run scoreboard players set #CD temp1 20
$execute as @a[tag=$(player)] at @s if score @s wandering_lantern_CD matches 1.. run scoreboard players operation #CD temp /= #CD temp1
$execute as @a[tag=$(player)] at @s if score @s wandering_lantern_CD matches 1.. run scoreboard players add #CD temp 1
$execute as @a[tag=$(player)] at @s if score @s wandering_lantern_CD matches 1.. run title @s actionbar [{"text":"§l『漂泊之灯』§f技能CD还剩"},{"score": {"name": "#CD","objective": "temp"},"bold": true},{"text":"s","bold": true}]
$execute as @a[tag=$(player)] at @s if score @s wandering_lantern_CD matches 1.. run playsound block.bone_block.break ambient @s ~ ~ ~ 1.0 0.7 0
$execute as @a[tag=$(player)] at @s if score @s wandering_lantern_CD matches 1.. run return 3

# 设置技能CD，减去MP
$execute as @a[tag=$(player)] run scoreboard players set @s wandering_lantern_CD 2400
$execute as @a[tag=$(player)] run scoreboard players remove @s MP 40

# 在玩家脚下召唤灵魂灯笼block_display
$execute as @a[tag=$(player)] at @s run summon block_display ~ ~1 ~ {Tags:["wandering_lantern","wandering_lantern_new"],block_state:{Name:"minecraft:soul_lantern"},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]}}

# 添加玩家ID标签用于溯源
$tag @e[tag=wandering_lantern_new] add wandering_lantern_$(player)

# 设置持续时间（100秒 = 2000 tick）
scoreboard players set @e[tag=wandering_lantern_new] temp 2000

# 设置发射计时器（每40tick发射，初始为40立即发射）
scoreboard players set @e[tag=wandering_lantern_new] temp2 40

# 移除临时标签
tag @e[tag=wandering_lantern_new] remove wandering_lantern_new

# 音效和提示
$execute as @a[tag=$(player)] at @s run playsound block.beacon.activate player @a ~ ~ ~ 1.5 1.2
$execute as @a[tag=$(player)] at @s run playsound entity.allay.ambient_with_item player @a ~ ~ ~ 1 0.8
$execute as @a[tag=$(player)] run title @s actionbar {"text":"漂泊之灯 - 已部署！","color":"aqua","bold":true}

# 召唤时的特效
$execute as @a[tag=$(player)] at @s run particle soul_fire_flame ~ ~1 ~ 0.3 0.5 0.3 0.05 30 force
$execute as @a[tag=$(player)] at @s run particle soul ~ ~1 ~ 0.5 0.5 0.5 0.02 20 force
