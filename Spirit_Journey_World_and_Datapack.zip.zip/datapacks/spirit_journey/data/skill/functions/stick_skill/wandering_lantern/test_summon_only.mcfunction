# 直接测试召唤灯笼marker
summon marker ~ ~ ~ {Tags:["wandering_lantern","test_lantern"]}
tellraw @a [{"text":"[测试] ","color":"yellow"},{"text":"已召唤测试灯笼marker！","color":"aqua"}]
particle soul_fire_flame ~ ~1 ~ 0.5 0.5 0.5 0.1 50 force
