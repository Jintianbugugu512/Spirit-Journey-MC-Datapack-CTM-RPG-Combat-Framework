# ==========================================
# 漂泊之灯 - 发射双颗魔法弹
# 随机选择2个不同的敌人分别发射
# ==========================================

# 随机选择12格内2个敌人作为目标
tag @e[tag=enemy,distance=..12,limit=2,sort=random] add lantern_bullet_target_double

# 发射音效
playsound entity.allay.item_thrown ambient @a ~ ~ ~ 1 1.5
playsound block.amethyst_block.chime ambient @a ~ ~ ~ 0.8 1.8

# 对第一个目标发射魔法弹
tag @e[tag=lantern_bullet_target_double,limit=1] add lantern_target_1
execute facing entity @e[tag=lantern_target_1,limit=1] eyes run summon spectral_arrow ~ ~0.5 ~ {Tags:["summon","lantern_bullet"],NoGravity:1b,Glowing:1b,PortalCooldown:100,PierceLevel:10,damage:0,crit:false,Color:5636095}

# 添加玩家ID标签
execute if entity @s[tag=wandering_lantern_player_1] run tag @e[tag=summon] add lantern_bullet_player_1
execute if entity @s[tag=wandering_lantern_player_2] run tag @e[tag=summon] add lantern_bullet_player_2
execute if entity @s[tag=wandering_lantern_player_3] run tag @e[tag=summon] add lantern_bullet_player_3

# 将第一个目标标签转移到子弹上
tag @e[tag=lantern_target_1] add lantern_bullet_target
tag @e[tag=summon] add has_target

# 计算第一颗子弹飞行方向
execute facing entity @e[tag=lantern_target_1,limit=1] eyes positioned 0.0 0.0 0.0 run summon marker ^ ^ ^1.2 {Tags:["mmark__"]}
execute as @e[tag=summon] run data modify entity @s Motion set from entity @e[limit=1,tag=mmark__] Pos
scoreboard players set @e[tag=summon] temp 100
tag @e[tag=summon] remove summon
kill @e[tag=mmark__,type=marker]

# 对第二个目标发射魔法弹
tag @e[tag=lantern_bullet_target_double,tag=!lantern_target_1,limit=1] add lantern_target_2
execute facing entity @e[tag=lantern_target_2,limit=1] eyes run summon spectral_arrow ~ ~0.5 ~ {Tags:["summon","lantern_bullet"],NoGravity:1b,Glowing:1b,PortalCooldown:100,PierceLevel:10,damage:0,crit:false,Color:5636095}

# 添加玩家ID标签
execute if entity @s[tag=wandering_lantern_player_1] run tag @e[tag=summon] add lantern_bullet_player_1
execute if entity @s[tag=wandering_lantern_player_2] run tag @e[tag=summon] add lantern_bullet_player_2
execute if entity @s[tag=wandering_lantern_player_3] run tag @e[tag=summon] add lantern_bullet_player_3

# 将第二个目标标签转移到子弹上
tag @e[tag=lantern_target_2] add lantern_bullet_target
tag @e[tag=summon] add has_target

# 计算第二颗子弹飞行方向
execute facing entity @e[tag=lantern_target_2,limit=1] eyes positioned 0.0 0.0 0.0 run summon marker ^ ^ ^1.2 {Tags:["mmark__"]}
execute as @e[tag=summon] run data modify entity @s Motion set from entity @e[limit=1,tag=mmark__] Pos
scoreboard players set @e[tag=summon] temp 100
tag @e[tag=summon] remove summon
kill @e[tag=mmark__,type=marker]

# 清理目标标签
tag @e[tag=lantern_target_1] remove lantern_target_1
tag @e[tag=lantern_target_2] remove lantern_target_2
tag @e[tag=lantern_bullet_target_double] remove lantern_bullet_target_double

# 发射特效
particle soul_fire_flame ~ ~0.5 ~ 0.3 0.3 0.3 0.08 25 force
particle soul ~ ~0.5 ~ 0.4 0.4 0.4 0.03 15 force
