# ==========================================
# 漂泊之灯 - 魔法弹命中
# 对锁定的目标造成45%魔法伤害
# ==========================================

# 对目标造成伤害 - 根据子弹的玩家ID标签
execute if entity @s[tag=lantern_bullet_player_1] as @e[tag=lantern_bullet_target,distance=..2.5,limit=1] run function combat:deal/damage_deal {rate:"45",type:"magic",player:"player_1",interval:"cactus"}
execute if entity @s[tag=lantern_bullet_player_2] as @e[tag=lantern_bullet_target,distance=..2.5,limit=1] run function combat:deal/damage_deal {rate:"45",type:"magic",player:"player_2",interval:"cactus"}
execute if entity @s[tag=lantern_bullet_player_3] as @e[tag=lantern_bullet_target,distance=..2.5,limit=1] run function combat:deal/damage_deal {rate:"45",type:"magic",player:"player_3",interval:"cactus"}

# 清除目标标签
tag @e[tag=lantern_bullet_target] remove lantern_bullet_target

# 命中视觉效果（蓝色魔法爆炸）
particle soul_fire_flame ~ ~ ~ 0.3 0.3 0.3 0.05 20 force
particle soul ~ ~ ~ 0.5 0.5 0.5 0.02 15 force
particle dust 0.3 0.7 1.0 1.5 ~ ~ ~ 0.5 0.5 0.5 0 30 force
particle end_rod ~ ~ ~ 0.3 0.3 0.3 0.05 10 force

# 命中音效
playsound entity.allay.hurt player @a ~ ~ ~ 1 1.5
playsound block.amethyst_block.break player @a ~ ~ ~ 0.8 1.2

# 清除子弹
kill @s
