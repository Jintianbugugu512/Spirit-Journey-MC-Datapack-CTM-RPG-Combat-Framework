# ==========================================
# 漂泊之灯 - 魔法弹移动与碰撞检测
# 每tick生成蓝色火焰粒子轨迹
# 检测是否命中锁定的目标
# ==========================================

# 蓝色火焰粒子轨迹
particle soul_fire_flame ~ ~ ~ 0.1 0.1 0.1 0.01 3 force
particle soul ~ ~ ~ 0.15 0.15 0.15 0.01 2 force
particle dust 0.3 0.7 1.0 1.0 ~ ~ ~ 0.1 0.1 0.1 0 2 force
particle end_rod ~ ~ ~ 0.05 0.05 0.05 0.01 1 force

# 子弹寿命递减
scoreboard players remove @s temp 1

# 超时自动清除
execute if score @s temp matches ..0 run particle soul ~ ~ ~ 0.2 0.2 0.2 0.02 10
execute if score @s temp matches ..0 run kill @s

# 检测是否命中锁定的目标（2.5格范围）
execute if entity @e[tag=lantern_bullet_target,distance=..2.5] run function skill:stick_skill/wandering_lantern/magic_bullet_hit
