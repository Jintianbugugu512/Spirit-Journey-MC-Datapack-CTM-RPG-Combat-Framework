# ==========================================
# 漂泊之灯 - 发射魔法弹
# 锁定12格内随机敌人发射魔法弹
# 如果有2个或以上敌人，发射2颗；否则发射1颗
# ==========================================

# 检查12格内是否有敌人
execute unless entity @e[tag=enemy,distance=..12] run return 0

# 检测敌人数量
execute store result score #enemy_count temp if entity @e[tag=enemy,distance=..12]

# 如果有2个或以上敌人，发射2颗魔法弹
execute if score #enemy_count temp matches 2.. run function skill:stick_skill/wandering_lantern/shoot_double

# 如果只有1个敌人，发射1颗魔法弹
execute if score #enemy_count temp matches 1 run function skill:stick_skill/wandering_lantern/shoot_single
