# ==========================================
# 测试漂泊之灯
# 在玩家位置部署漂泊之灯
# 使用方法: /function skill:stick_skill/wandering_lantern/test_wandering_lantern
# ==========================================

execute as @a at @s run function skill:stick_skill/wandering_lantern/wandering_lantern with storage damage:player_1 {id:"1"}
tellraw @a [{"text":"[测试] ","color":"yellow"},{"text":"已部署漂泊之灯！","color":"aqua"}]
