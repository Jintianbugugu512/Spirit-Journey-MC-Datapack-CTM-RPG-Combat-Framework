# ==========================================
# 漂泊之灯 - 发射单颗魔法弹
# 随机选择1个敌人发射
# ==========================================

# 随机选择12格内1个敌人作为目标
tag @e[tag=enemy,distance=..12,limit=1,sort=random] add lantern_bullet_target

# 发射音效
playsound entity.allay.item_thrown ambient @a ~ ~ ~ 1 1.5
playsound block.amethyst_block.chime ambient @a ~ ~ ~ 0.8 1.8

# 召唤光灵箭（魔法弹）- 朝向目标身体中心（稍微高一点）
execute facing entity @e[tag=lantern_bullet_target,limit=1] eyes run summon spectral_arrow ~ ~0.5 ~ {Tags:["summon","lantern_bullet"],NoGravity:1b,Glowing:1b,PortalCooldown:100,PierceLevel:10,damage:0,crit:false,Color:5636095}

# 添加玩家ID标签用于溯源（根据灯笼的玩家标签）
execute if entity @s[tag=wandering_lantern_player_1] run tag @e[tag=summon] add lantern_bullet_player_1
execute if entity @s[tag=wandering_lantern_player_2] run tag @e[tag=summon] add lantern_bullet_player_2
execute if entity @s[tag=wandering_lantern_player_3] run tag @e[tag=summon] add lantern_bullet_player_3

# 将目标标签转移到子弹上（用于碰撞检测）
execute as @e[tag=lantern_bullet_target] run tag @s add lantern_bullet_target_temp
tag @e[tag=summon] add has_target
tag @e[tag=lantern_bullet_target] remove lantern_bullet_target
tag @e[tag=lantern_bullet_target_temp] add lantern_bullet_target
tag @e[tag=lantern_bullet_target_temp] remove lantern_bullet_target_temp

# 计算飞行方向（使用临时marker，速度1.2）
execute facing entity @e[tag=lantern_bullet_target,limit=1] eyes positioned 0.0 0.0 0.0 run summon marker ^ ^ ^1.2 {Tags:["mmark__"]}
execute as @e[tag=summon] run data modify entity @s Motion set from entity @e[limit=1,tag=mmark__] Pos

# 设置子弹寿命（100 tick）
scoreboard players set @e[tag=summon] temp 100

# 清理临时实体和标签
tag @e[tag=summon] remove summon
kill @e[tag=mmark__,type=marker]

# 发射特效
particle soul_fire_flame ~ ~0.5 ~ 0.2 0.2 0.2 0.05 15 force
particle soul ~ ~0.5 ~ 0.3 0.3 0.3 0.02 10 force
