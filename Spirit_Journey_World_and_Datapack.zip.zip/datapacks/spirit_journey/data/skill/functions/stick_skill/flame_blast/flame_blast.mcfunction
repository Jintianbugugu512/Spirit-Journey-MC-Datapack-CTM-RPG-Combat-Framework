#MP不足则返回
$execute as @a[tag=$(player)] at @s if score @s MP matches ..49 run title @s actionbar "『MP不足,使用§l炎爆术§f需要消耗§l50MP§f.』"
$execute as @a[tag=$(player)] at @s if score @s MP matches ..49 run playsound block.bone_block.place ambient @s ~ ~ ~ 1 0.8 0
$execute as @a[tag=$(player)] at @s if score @s MP matches ..49 run return 2

#CD没有归0则返回
$execute as @a[tag=$(player)] at @s if score @s flame_blast_CD matches 1.. run scoreboard players operation #CD temp = @s flame_blast_CD
$execute as @a[tag=$(player)] at @s if score @s flame_blast_CD matches 1.. run scoreboard players set #CD temp1 20
$execute as @a[tag=$(player)] at @s if score @s flame_blast_CD matches 1.. run scoreboard players operation #CD temp /= #CD temp1
$execute as @a[tag=$(player)] at @s if score @s flame_blast_CD matches 1.. run scoreboard players add #CD temp 1
$execute as @a[tag=$(player)] at @s if score @s flame_blast_CD matches 1.. run title @s actionbar [{"text":"§l『炎爆术』§f技能CD还剩"},{"score": {"name": "#CD","objective": "temp"},"bold": true},{"text":"s","bold": true}]
$execute as @a[tag=$(player)] at @s if score @s flame_blast_CD matches 1.. run playsound block.bone_block.break ambient @s ~ ~ ~ 1.0 0.7 0
$execute as @a[tag=$(player)] at @s if score @s flame_blast_CD matches 1.. run return 3

#设置技能CD,减去MP.
$execute as @a[tag=$(player)] run scoreboard players set @s flame_blast_CD 1200
$execute as @a[tag=$(player)] run scoreboard players remove @s MP 50
#粒子与音效
$execute as @a[tag=$(player)] at @s run playsound entity.blaze.death ambient @s ~ ~ ~ 1 0.8 0
particle flame ^ ^1 ^3.2 -2 1 2 0.1 300


#标记锁定范围内的实体为lock
tag @e[tag=enemy,distance=..8] add lock



#锁定范围内没有敌人则提示玩家
$execute as @a[tag=$(player)] at @s run execute unless entity @e[tag=lock,scores={fire=1..}] run title @s actionbar "『技能锁定范围内没有满足要求的敌人』"

#造成伤害后移除lock
execute as @e[tag=lock] at @s run function skill:stick_skill/flame_blast/blast_damage
scoreboard players set @e[tag=lock] stun 50

fill ^-8 ^-2 ^-8 ^8 ^3 ^8 air replace glow_lichen

tag @e[tag=lock] remove lock

