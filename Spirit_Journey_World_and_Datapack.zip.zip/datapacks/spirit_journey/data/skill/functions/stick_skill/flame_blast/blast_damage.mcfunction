execute store result storage damage:damage flame_count int 3 run scoreboard players get @s fire
function skill:stick_skill/flame_blast/blast_particle

scoreboard players set #flame_blast temp 20
scoreboard players set #flame_blast temp1 10
scoreboard players operation @s fire /= #flame_blast temp
scoreboard players operation @s fire *= #flame_blast temp1
execute if score @s fire matches 500.. run scoreboard players set @s fire 500
scoreboard players operation @s current_health -= @s fire



data modify entity @s Fire set value 0s