# ==========================================
# 暗影法阵 - 伤害判定
# 对周围5格所有敌人造成50%魔法伤害
# ==========================================

# 根据marker的玩家标签判断是哪个玩家的法阵
execute if entity @s[tag=shadow_field_player_1] as @e[tag=enemy,distance=..5] run function combat:deal/damage_deal {rate:"50",type:"magic",player:"player_1",interval:"cactus"}
execute if entity @s[tag=shadow_field_player_2] as @e[tag=enemy,distance=..5] run function combat:deal/damage_deal {rate:"50",type:"magic",player:"player_2",interval:"cactus"}
execute if entity @s[tag=shadow_field_player_3] as @e[tag=enemy,distance=..5] run function combat:deal/damage_deal {rate:"50",type:"magic",player:"player_3",interval:"cactus"}

# 伤害触发粒子效果
particle dust 0.3 0.0 0.5 2.0 ~ ~1 ~ 3 1 3 0 30 force
particle soul_fire_flame ~ ~1 ~ 2.5 0.5 2.5 0.1 20 force

# 伤害音效
playsound entity.evoker.cast_spell player @a ~ ~ ~ 0.5 2
