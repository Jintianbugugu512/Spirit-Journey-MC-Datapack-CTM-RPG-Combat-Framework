# ==========================================
# 暗影法阵 - Tick管理
# 每tick执行，管理持续时间和伤害判定
# ==========================================

# 持续时间递减
scoreboard players remove @s temp 1

# 间隔计数递增
scoreboard players add @s temp2 1

# 每tick生成暗影粒子效果（法阵范围5格）
particle dust 0.2 0.0 0.4 1.5 ~ ~0.1 ~ 2.5 0 2.5 0 15 force
particle witch ~ ~0.5 ~ 2 0.2 2 0 8 force
particle soul ~ ~1 ~ 2.5 0.5 2.5 0.02 5 force
particle portal ~ ~0.2 ~ 2 0 2 0.5 10 force

# 每20tick造成一次伤害
execute if score @s temp2 matches 20.. run function skill:stick_skill/shadow_field/shadow_field_damage
execute if score @s temp2 matches 20.. run scoreboard players set @s temp2 0

# 每30秒播放一次音效提醒
execute if score @s temp matches 1800 run playsound block.beacon.ambient player @a ~ ~ ~ 1 1.5
execute if score @s temp matches 1200 run playsound block.beacon.ambient player @a ~ ~ ~ 1 1.5
execute if score @s temp matches 600 run playsound block.beacon.ambient player @a ~ ~ ~ 1 1.5

# 即将结束提示（剩余10秒）
execute if score @s temp matches 200 run playsound block.beacon.deactivate player @a ~ ~ ~ 1 1.5
execute if score @s temp matches 200 run particle end_rod ~ ~1 ~ 3 1 3 0.1 50 force

# 持续时间结束，清除marker
execute if score @s temp matches ..0 run particle explosion ~ ~1 ~ 0 0 0 0 1
execute if score @s temp matches ..0 run playsound entity.evoker.cast_spell player @a ~ ~ ~ 1 0.5
execute if score @s temp matches ..0 run kill @s
