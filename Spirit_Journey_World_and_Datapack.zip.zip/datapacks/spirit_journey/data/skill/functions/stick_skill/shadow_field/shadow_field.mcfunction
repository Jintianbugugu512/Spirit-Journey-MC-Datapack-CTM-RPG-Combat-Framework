# ==========================================
# 暗影法阵 - 杖技能
# 在脚下放置一个暗影法阵marker
# 持续2分钟，每0.5秒对周围5格敌人造成50%魔法伤害
# ==========================================

# MP不足则返回
$execute as @a[tag=$(player)] at @s if score @s MP matches ..29 run title @s actionbar "『MP不足,使用§l暗影法阵§f需要消耗§l30MP§f.』"
$execute as @a[tag=$(player)] at @s if score @s MP matches ..29 run playsound block.bone_block.place ambient @s ~ ~ ~ 1 0.8 0
$execute as @a[tag=$(player)] at @s if score @s MP matches ..29 run return 2

# CD没有归0则返回
$execute as @a[tag=$(player)] at @s if score @s shadow_field_CD matches 1.. run scoreboard players operation #CD temp = @s shadow_field_CD
$execute as @a[tag=$(player)] at @s if score @s shadow_field_CD matches 1.. run scoreboard players set #CD temp1 20
$execute as @a[tag=$(player)] at @s if score @s shadow_field_CD matches 1.. run scoreboard players operation #CD temp /= #CD temp1
$execute as @a[tag=$(player)] at @s if score @s shadow_field_CD matches 1.. run scoreboard players add #CD temp 1
$execute as @a[tag=$(player)] at @s if score @s shadow_field_CD matches 1.. run title @s actionbar [{"text":"§l『暗影法阵』§f技能CD还剩"},{"score": {"name": "#CD","objective": "temp"},"bold": true},{"text":"s","bold": true}]
$execute as @a[tag=$(player)] at @s if score @s shadow_field_CD matches 1.. run playsound block.bone_block.break ambient @s ~ ~ ~ 1.0 0.7 0
$execute as @a[tag=$(player)] at @s if score @s shadow_field_CD matches 1.. run return 3

# 设置技能CD，减去MP
$execute as @a[tag=$(player)] run scoreboard players set @s shadow_field_CD 60
$execute as @a[tag=$(player)] run scoreboard players remove @s MP 30

# 在玩家脚下召唤marker实体
$execute as @a[tag=$(player)] at @s run summon marker ~ ~ ~ {Tags:["shadow_field","shadow_field_new"]}

# 添加玩家ID标签用于溯源
$tag @e[tag=shadow_field_new] add shadow_field_$(player)

# 设置持续时间（2分钟 = 2400 tick）
scoreboard players set @e[tag=shadow_field_new] temp 2400

# 设置间隔计数器（每20tick造成伤害）
scoreboard players set @e[tag=shadow_field_new] temp2 0

# 移除临时标签
tag @e[tag=shadow_field_new] remove shadow_field_new

# 音效和提示
$execute as @a[tag=$(player)] at @s run playsound entity.evoker.prepare_summon player @a ~ ~ ~ 1.5 0.8
$execute as @a[tag=$(player)] at @s run playsound block.beacon.activate player @a ~ ~ ~ 1 1.5
$execute as @a[tag=$(player)] run title @s actionbar {"text":"暗影法阵 - 已部署！","color":"dark_purple","bold":true}
