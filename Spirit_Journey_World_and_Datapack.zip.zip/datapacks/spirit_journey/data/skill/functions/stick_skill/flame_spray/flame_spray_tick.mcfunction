# ==========================================
# 火焰喷射 - Tick检测
# 每tick生成火焰粒子，每0.5秒检测并点燃敌人
# ==========================================

# 持续时间递减
scoreboard players remove @s flame_spray_duration 1

# 间隔计数递增（用于0.5秒间隔）
scoreboard players add @s flame_spray_interval 1

# 每tick生成火焰粒子效果（形成喷射轨迹）
execute at @s run particle small_flame ^ ^1.5 ^2 0.3 0.3 0.3 0.02 4 force
execute at @s run particle small_flame ^ ^1.5 ^4 0.5 0.5 0.5 0.02 5 force
execute at @s run particle small_flame ^ ^1.5 ^6 0.6 0.6 0.6 0.02 6 force
execute at @s run particle small_flame ^ ^1.5 ^8 0.7 0.7 0.7 0.02 8 force
execute at @s run particle small_flame ^ ^1.5 ^10 0.8 0.8 0.8 0.02 9 force

# 每10tick（0.5秒）检测并点燃敌人
execute if score @s flame_spray_interval matches 10.. at @s run function skill:stick_skill/flame_spray/flame_spray_damage
execute if score @s flame_spray_interval matches 10.. run scoreboard players set @s flame_spray_interval 0

# 持续期间每2秒播放一次音效
execute if score @s flame_spray_duration matches 200 at @s run playsound block.fire.ambient player @a ~ ~ ~ 1 1
execute if score @s flame_spray_duration matches 160 at @s run playsound block.fire.ambient player @a ~ ~ ~ 1 1
execute if score @s flame_spray_duration matches 120 at @s run playsound block.fire.ambient player @a ~ ~ ~ 1 1
execute if score @s flame_spray_duration matches 80 at @s run playsound block.fire.ambient player @a ~ ~ ~ 1 1
execute if score @s flame_spray_duration matches 40 at @s run playsound block.fire.ambient player @a ~ ~ ~ 1 1

# 持续时间结束，移除buff
execute if score @s flame_spray_duration matches ..0 run tag @s remove flame_spray_active
execute if score @s flame_spray_duration matches ..0 run title @s actionbar {"text":"火焰喷射 - 结束","color":"gray"}
execute if score @s flame_spray_duration matches ..0 run scoreboard players reset @s flame_spray_duration
execute if score @s flame_spray_duration matches ..0 run scoreboard players reset @s flame_spray_interval
