# ==========================================
# 火焰喷射 - 点燃敌人
# 在前方多个位置检测敌人并点燃（累加燃烧时间）
# ==========================================

# 在玩家前方5个位置检测敌人（球体拟合长矩形）
# 每个位置检测1.5格半径内的敌人

# 位置1：前方2格
execute positioned ^ ^1.5 ^2 run tag @e[tag=enemy,distance=..1.5] add flame_target

# 位置2：前方4格
execute positioned ^ ^1.5 ^4 run tag @e[tag=enemy,distance=..1.5] add flame_target

# 位置3：前方6格
execute positioned ^ ^1.5 ^6 run tag @e[tag=enemy,distance=..1.5] add flame_target

# 位置4：前方8格
execute positioned ^ ^1.5 ^8 run tag @e[tag=enemy,distance=..1.5] add flame_target

# 位置5：前方10格
execute positioned ^ ^1.5 ^10 run tag @e[tag=enemy,distance=..1.5] add flame_target

# 给标记的敌人增加2秒燃烧（40tick，会累加）
execute as @e[tag=flame_target] run data modify entity @s Fire set value 40

# 点燃特效
execute as @e[tag=flame_target] at @s run particle flame ~ ~1 ~ 0.3 0.5 0.3 0.05 10 force
execute as @e[tag=flame_target] at @s run playsound entity.generic.burn player @a ~ ~ ~ 0.5 1

# 清除临时标签
tag @e[tag=flame_target] remove flame_target
