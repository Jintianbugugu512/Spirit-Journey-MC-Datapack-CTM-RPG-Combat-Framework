# ==========================================
# 火焰喷射 - 杖技能
# 向前方长矩形范围喷射火焰，每0.5秒叠加2秒燃烧
# 持续12秒
# ==========================================

# MP不足则返回
$execute as @a[tag=$(player)] at @s if score @s MP matches ..19 run title @s actionbar "『MP不足,使用§l火焰喷射§f需要消耗§l20MP§f.』"
$execute as @a[tag=$(player)] at @s if score @s MP matches ..19 run playsound block.bone_block.place ambient @s ~ ~ ~ 1 0.8 0
$execute as @a[tag=$(player)] at @s if score @s MP matches ..19 run return 2

# CD没有归0则返回
$execute as @a[tag=$(player)] at @s if score @s flame_spray_CD matches 1.. run scoreboard players operation #CD temp = @s flame_spray_CD
$execute as @a[tag=$(player)] at @s if score @s flame_spray_CD matches 1.. run scoreboard players set #CD temp1 20
$execute as @a[tag=$(player)] at @s if score @s flame_spray_CD matches 1.. run scoreboard players operation #CD temp /= #CD temp1
$execute as @a[tag=$(player)] at @s if score @s flame_spray_CD matches 1.. run scoreboard players add #CD temp 1
$execute as @a[tag=$(player)] at @s if score @s flame_spray_CD matches 1.. run title @s actionbar [{"text":"§l『火焰喷射』§f技能CD还剩"},{"score": {"name": "#CD","objective": "temp"},"bold": true},{"text":"s","bold": true}]
$execute as @a[tag=$(player)] at @s if score @s flame_spray_CD matches 1.. run playsound block.bone_block.break ambient @s ~ ~ ~ 1.0 0.7 0
$execute as @a[tag=$(player)] at @s if score @s flame_spray_CD matches 1.. run return 3

# 设置技能CD，减去MP
$execute as @a[tag=$(player)] run scoreboard players set @s flame_spray_CD 400
$execute as @a[tag=$(player)] run scoreboard players remove @s MP 20

# 添加施法标签和持续时间
$execute as @a[tag=$(player)] run tag @s add flame_spray_active
$execute as @a[tag=$(player)] run scoreboard players set @s flame_spray_duration 240
$execute as @a[tag=$(player)] run scoreboard players set @s flame_spray_interval 0

# 释放音效
$execute as @a[tag=$(player)] at @s run playsound block.fire.ambient player @a ~ ~ ~ 1.5 1
$execute as @a[tag=$(player)] at @s run playsound entity.blaze.shoot player @a ~ ~ ~ 0.8 0.8

# 提示信息
$execute as @a[tag=$(player)] run title @s actionbar {"text":"火焰喷射 - 开始！","color":"gold","bold":true}
