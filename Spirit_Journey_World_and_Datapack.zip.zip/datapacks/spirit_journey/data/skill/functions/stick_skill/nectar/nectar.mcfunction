# ==========================================
# 天降甘露 - 杖技能
# 给范围内最多2个玩家添加生命回复II buff
# 持续15秒，受到伤害时中断
# ==========================================

# MP不足则返回
$execute as @a[tag=$(player)] at @s if score @s MP matches ..49 run title @s actionbar "『MP不足,使用§l天降甘露§f需要消耗§l50MP§f.』"
$execute as @a[tag=$(player)] at @s if score @s MP matches ..49 run playsound block.bone_block.place ambient @s ~ ~ ~ 1 0.8 0
$execute as @a[tag=$(player)] at @s if score @s MP matches ..49 run return 2

# CD没有归0则返回
$execute as @a[tag=$(player)] at @s if score @s nectar_CD matches 1.. run scoreboard players operation #CD temp = @s nectar_CD
$execute as @a[tag=$(player)] at @s if score @s nectar_CD matches 1.. run scoreboard players set #CD temp1 20
$execute as @a[tag=$(player)] at @s if score @s nectar_CD matches 1.. run scoreboard players operation #CD temp /= #CD temp1
$execute as @a[tag=$(player)] at @s if score @s nectar_CD matches 1.. run scoreboard players add #CD temp 1
$execute as @a[tag=$(player)] at @s if score @s nectar_CD matches 1.. run title @s actionbar [{"text":"§l『天降甘露』§f技能CD还剩"},{"score": {"name": "#CD","objective": "temp"},"bold": true},{"text":"s","bold": true}]
$execute as @a[tag=$(player)] at @s if score @s nectar_CD matches 1.. run playsound block.bone_block.break ambient @s ~ ~ ~ 1.0 0.7 0
$execute as @a[tag=$(player)] at @s if score @s nectar_CD matches 1.. run return 3

# 设置技能CD，减去MP
$execute as @a[tag=$(player)] run scoreboard players set @s nectar_CD 600
$execute as @a[tag=$(player)] run scoreboard players remove @s MP 50

# 标记范围内最多2个玩家（包括自己）
$execute as @a[tag=$(player)] at @s run tag @a[distance=..5,limit=2,sort=nearest] add nectar_target

# 设置can_be_effect，允许接受buff（15秒 = 300 tick）
scoreboard players set @a[tag=nectar_target] can_be_effect 300

# 给予生命回复II buff（15秒）
effect give @a[tag=nectar_target] regeneration 15 1 true

# 添加buff标签（用于后续检测）
tag @a[tag=nectar_target] add nectar_buff

# 倾盆大雨视觉效果
execute as @a[tag=nectar_target] at @s run particle rain ~ ~2.5 ~ 3 0 3 0 150 force
execute as @a[tag=nectar_target] at @s run particle falling_water ~ ~3 ~ 3 0.5 3 0.2 225 force
execute as @a[tag=nectar_target] at @s run particle heart ~ ~2 ~ 1 1 1 0.1 10 force

# 音效
$execute as @a[tag=$(player)] at @s run playsound weather.rain player @a ~ ~ ~ 1.5 1
$execute as @a[tag=$(player)] at @s run playsound block.brewing_stand.brew player @a ~ ~ ~ 1 1.2
$execute as @a[tag=$(player)] at @s run playsound entity.player.levelup player @a ~ ~ ~ 0.8 1.5

# 提示信息
title @a[tag=nectar_target] actionbar {"text":"天降甘露 - 生命回复！","color":"green","bold":true}

# 清除临时标签
tag @a[tag=nectar_target] remove nectar_target
