# ==========================================
# 天降甘露 - Tick检测
# 检测buff玩家是否受到伤害或buff自然到期
# ==========================================

# 检测受伤（HurtTime = 9 表示刚受到伤害）
execute as @a[tag=nectar_buff,nbt={HurtTime:9s}] run function skill:stick_skill/nectar/nectar_remove_hurt

# 检测buff自然到期（没有regeneration效果了）
execute as @a[tag=nectar_buff] unless entity @s[nbt={active_effects:[{id:"minecraft:regeneration"}]}] run tag @s remove nectar_buff
