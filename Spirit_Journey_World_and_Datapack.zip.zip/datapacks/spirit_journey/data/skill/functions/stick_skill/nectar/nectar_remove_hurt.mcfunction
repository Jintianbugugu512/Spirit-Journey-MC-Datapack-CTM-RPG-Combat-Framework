# ==========================================
# 天降甘露 - 受伤中断
# 玩家受到伤害时移除buff和效果
# ==========================================

# 移除buff标签
tag @s remove nectar_buff

# 清除regeneration效果
effect clear @s regeneration

# 中断视觉效果
particle smoke ~ ~1 ~ 1.5 1 1.5 0.15 100 force
particle large_smoke ~ ~1 ~ 1.5 1 1.5 0.1 50 force
playsound entity.generic.extinguish_fire player @a ~ ~ ~ 1.5 0.8

# 提示信息
title @s actionbar {"text":"天降甘露 - 受伤中断！","color":"red"}
