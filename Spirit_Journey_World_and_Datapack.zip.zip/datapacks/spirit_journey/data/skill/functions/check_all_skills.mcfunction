# 统一技能检测函数
# 检测所有技能的延迟触发条件,技能释放的实体等.


# ==================== 剑系技能 ====================

# 三连斩 - CD检测（CD=32以上时可以连击）
$execute if score @s triple_slash_CD matches 30.. run function skill:sword_skill/triple_slash/triple_slash_trigger with storage damage:player_$(id)

# 旋风斩击 - Buff激活检测
$execute if entity @s[tag=whirlwind_active] run function skill:sword_skill/whirlwind/whirlwind_tick {id:"$(id)"}

# 剑舞 - Buff激活检测
$execute if entity @s[scores={sword_rally_buff=1..}] at @s run function skill:sword_skill/sword_rally/sword_rally_trigger with storage damage:player_$(id)

# 决斗领域Buff重置（每tick重置为0，由决斗领域marker重新设置为1）确保只有在决斗领域范围内的玩家才有buff
scoreboard players set @a duel_domain_buff 0
# 决斗领域实体管理
execute as @e[tag=duel_domain] at @s run function skill:sword_skill/duel_domain/duel_domain_tick

# 风暴剑舞实体管理
execute as @e[tag=storm_dance] at @s run function skill:sword_skill/storm_dance/storm_dance_tick

# ==================== 弓系技能 ====================

# 狙击子弹碰撞检测 - 使用玩家ID标签
$execute as @e[tag=snipe_bullet_player_$(id)] at @s if entity @e[tag=enemy,distance=..2.5] run function skill:bow_skill/snipe/snipe_damage with storage damage:player_$(id)

# 点火子弹移动和碰撞检测
$execute as @e[tag=ignite_bullet_player_$(id)] at @s run function skill:bow_skill/ignite/ignite_tick

# 凝滞弹子弹移动和碰撞检测
$execute as @e[tag=stasis_shot_bullet_player_$(id)] at @s run function skill:bow_skill/stasis_shot/stasis_shot_tick

# 弱化弹子弹移动和碰撞检测
$execute as @e[tag=weakness_shot_bullet_player_$(id)] at @s run function skill:stick_skill/weakness_shot/weakness_shot_tick

# 加农炮子弹移动和碰撞检测
$execute as @e[tag=cannon_bullet_player_$(id)] at @s run function skill:bow_skill/cannon/cannon_tick

# 高压弹子弹移动和碰撞检测
$execute as @e[tag=high_pressure_bullet_player_$(id)] at @s run function skill:bow_skill/high_pressure_shot/high_pressure_tick

# 穿甲雷地雷实体管理
execute as @e[tag=ap_mine] at @s run function skill:bow_skill/armor_piercing_mine/mine_tick
execute as @e[tag=ap_mine_tnt] at @s run function skill:bow_skill/armor_piercing_mine/tnt_tick

# ==================== 剑气/光弹 ====================

# 剑气弹幕移动
$execute as @e[tag=light_bullet_player_$(id)] run function skill:sword_skill/sword_light/light_move with storage damage:player_$(id)

# 剑光子弹碰撞检测 - 使用玩家ID标签
$execute as @e[tag=light_bullet_player_$(id)] at @s if entity @e[tag=enemy,distance=..2,scores={hit_cooldown=0}] run function skill:sword_skill/sword_light/light_damage with storage damage:player_$(id)


# ==================== 杖系技能 ====================

# 火焰喷射 - Buff激活检测
execute if entity @s[tag=flame_spray_active] run function skill:stick_skill/flame_spray/flame_spray_tick

# 漂泊之灯魔法弹移动和碰撞检测
$execute as @e[tag=lantern_bullet_player_$(id)] at @s run function skill:stick_skill/wandering_lantern/magic_bullet_tick

# 暗影法阵实体管理
execute as @e[tag=shadow_field] at @s run function skill:stick_skill/shadow_field/shadow_field_tick

# 魂灵爆破实体管理
execute as @e[tag=soul_blast] at @s run function skill:stick_skill/soul_blast/soul_blast_tick

# 漂泊之灯实体管理
execute as @e[tag=wandering_lantern] at @s run function skill:stick_skill/wandering_lantern/wandering_lantern_tick

# ==================== 通用技能 ====================

# 天降甘露 - Buff检测（伤害中断）
execute as @a[tag=nectar_buff] run function skill:stick_skill/nectar/nectar_tick




# 空中冲刺箭矢传送 - 使用玩家ID标签（已在 player_common 中处理）
# $execute as @e[tag=airdash_bullet_player_$(id),type=arrow] at @s as @a[tag=player_$(id)] run tp @s ~ ~ ~

# TODO: 添加更多技能检测
# $execute if score @s xxx_CD matches 32.. run function skill:xxx/xxx_trigger with storage damage:player_$(id)
