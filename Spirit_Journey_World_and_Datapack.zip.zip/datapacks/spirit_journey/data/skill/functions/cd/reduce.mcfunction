# CD递减通用函数
# 使用宏参数减少代码重复
# 用法: function skill:cd/reduce {cd:"triple_slash_CD"}
# 参数:
#   cd - 技能CD计分板名称

$scoreboard players remove @a[scores={$(cd)=1..}] $(cd) 1
