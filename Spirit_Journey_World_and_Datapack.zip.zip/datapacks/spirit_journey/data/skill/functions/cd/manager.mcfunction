# ==========================================
# CD管理器 - 技能冷却时间递减
# 使用宏函数减少代码重复
# 每tick执行，管理所有技能的CD倒计时
# ==========================================

# ==================== 剑系技能CD ====================

function skill:cd/reduce {cd:"triple_slash_CD"}
function skill:cd/reduce {cd:"disarm_CD"}
function skill:cd/reduce {cd:"bounty_blade_CD"}
function skill:cd/reduce {cd:"parry_CD"}
function skill:cd/reduce {cd:"flame_slash_CD"}
function skill:cd/reduce {cd:"flame_blast_CD"}
function skill:cd/reduce {cd:"sword_rally_CD"}
function skill:cd/reduce {cd:"sword_rally_buff"}
function skill:cd/reduce {cd:"heavy_slash_CD"}
function skill:cd/reduce {cd:"duel_domain_CD"}
function skill:cd/reduce {cd:"storm_dance_CD"}

# ==================== 弓系技能CD ====================

function skill:cd/reduce {cd:"snipe_CD"}
function skill:cd/reduce {cd:"quickly_load"}
function skill:cd/reduce {cd:"stasis_shot_CD"}
function skill:cd/reduce {cd:"weakness_shot_CD"}
function skill:cd/reduce {cd:"cannon_CD"}
function skill:cd/reduce {cd:"high_pressure_shot_CD"}

# ==================== 法杖系技能CD ====================

function skill:cd/reduce {cd:"ignite_CD"}
function skill:cd/reduce {cd:"whirlwind_CD"}
function skill:cd/reduce {cd:"nectar_CD"}
function skill:cd/reduce {cd:"flame_spray_CD"}
function skill:cd/reduce {cd:"shadow_field_CD"}
function skill:cd/reduce {cd:"soul_blast_CD"}
function skill:cd/reduce {cd:"wandering_lantern_CD"}

# ==================== 通用技能CD ====================

function skill:cd/reduce {cd:"blood_CD"}
function skill:cd/reduce {cd:"blood_buff"}
function skill:cd/reduce {cd:"sacred_shield_CD"}
function skill:cd/reduce {cd:"shockwave_CD"}
function skill:cd/reduce {cd:"amethyst_highlight_CD"}

# ==================== 特殊CD ====================

function skill:cd/reduce {cd:"zdxh_cd"}
function skill:cd/reduce {cd:"lhfs_timer"}
function skill:cd/reduce {cd:"lhgy_timer"}



#最大MP限制
execute as @a if score @s MP >= @s max_MP run scoreboard players operation @s MP = @s max_MP
