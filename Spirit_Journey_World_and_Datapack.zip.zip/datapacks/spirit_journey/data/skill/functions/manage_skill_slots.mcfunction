# 清除逻辑 - 删除玩家背包中的所有占位符玻璃板
# 这样玩家从末影箱拿出的占位符会被自动删除
clear @a red_stained_glass_pane{skill_placeholder:1b}
clear @a cyan_stained_glass_pane{skill_placeholder:1b}
clear @a purple_stained_glass_pane{skill_placeholder:1b}

# 剑技能槽位占位符管理
# 为空的剑技能槽位放置红色玻璃板占位符

# 槽位 18 - 剑技能1 (左键+潜行)
execute as @a unless data entity @s EnderItems[{Slot:18b}] run item replace entity @s enderchest.18 with minecraft:red_stained_glass_pane{display:{Name:'{"text":"剑-技能槽位","color":"red","italic":false}',Lore:['{"text":"潜行中 左键释放该技能","color":"gray","italic":false}']},skill_placeholder:1b}

# 槽位 19 - 剑技能2 (跳跃+潜行)
execute as @a unless data entity @s EnderItems[{Slot:19b}] run item replace entity @s enderchest.19 with minecraft:red_stained_glass_pane{display:{Name:'{"text":"剑-技能槽位","color":"red","italic":false}',Lore:['{"text":"潜行中 跳跃释放该技能","color":"gray","italic":false}']},skill_placeholder:1b}

# 槽位 20 - 剑技能3 (右键+潜行)
execute as @a unless data entity @s EnderItems[{Slot:20b}] run item replace entity @s enderchest.20 with minecraft:red_stained_glass_pane{display:{Name:'{"text":"剑-技能槽位","color":"red","italic":false}',Lore:['{"text":"潜行中 右键释放该技能","color":"gray","italic":false}']},skill_placeholder:1b}

# 弩技能槽位占位符管理
# 为空的弩技能槽位放置青色玻璃板占位符

# 槽位 21 - 弩技能1 (左键+潜行)
execute as @a unless data entity @s EnderItems[{Slot:21b}] run item replace entity @s enderchest.21 with minecraft:cyan_stained_glass_pane{display:{Name:'{"text":"弩-技能槽位","color":"aqua","italic":false}',Lore:['{"text":"潜行中 左键释放该技能","color":"gray","italic":false}']},skill_placeholder:1b}

# 槽位 22 - 弩技能2 (跳跃+潜行)
execute as @a unless data entity @s EnderItems[{Slot:22b}] run item replace entity @s enderchest.22 with minecraft:cyan_stained_glass_pane{display:{Name:'{"text":"弩-技能槽位","color":"aqua","italic":false}',Lore:['{"text":"潜行中 跳跃释放该技能","color":"gray","italic":false}']},skill_placeholder:1b}

# 槽位 23 - 弩技能3 (右键+潜行)
execute as @a unless data entity @s EnderItems[{Slot:23b}] run item replace entity @s enderchest.23 with minecraft:cyan_stained_glass_pane{display:{Name:'{"text":"弩-技能槽位","color":"aqua","italic":false}',Lore:['{"text":"潜行中 右键释放该技能","color":"gray","italic":false}']},skill_placeholder:1b}

# 杖技能槽位占位符管理
# 为空的杖技能槽位放置紫色玻璃板占位符

# 槽位 24 - 杖技能1 (左键+潜行)
execute as @a unless data entity @s EnderItems[{Slot:24b}] run item replace entity @s enderchest.24 with minecraft:purple_stained_glass_pane{display:{Name:'{"text":"杖-技能槽位","color":"light_purple","italic":false}',Lore:['{"text":"潜行中 左键释放该技能","color":"gray","italic":false}']},skill_placeholder:1b}

# 槽位 25 - 杖技能2 (跳跃+潜行)
execute as @a unless data entity @s EnderItems[{Slot:25b}] run item replace entity @s enderchest.25 with minecraft:purple_stained_glass_pane{display:{Name:'{"text":"杖-技能槽位","color":"light_purple","italic":false}',Lore:['{"text":"潜行中 跳跃释放该技能","color":"gray","italic":false}']},skill_placeholder:1b}

# 槽位 26 - 杖技能3 (右键+潜行)
execute as @a unless data entity @s EnderItems[{Slot:26b}] run item replace entity @s enderchest.26 with minecraft:purple_stained_glass_pane{display:{Name:'{"text":"杖-技能槽位","color":"light_purple","italic":false}',Lore:['{"text":"潜行中 右键释放该技能","color":"gray","italic":false}']},skill_placeholder:1b}
