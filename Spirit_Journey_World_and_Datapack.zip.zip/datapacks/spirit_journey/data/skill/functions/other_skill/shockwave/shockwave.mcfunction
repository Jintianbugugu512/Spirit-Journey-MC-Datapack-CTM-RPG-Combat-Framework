#MP不足则返回
execute if score @s MP matches ..29 run title @s actionbar "『MP不足,使用§l震荡波§f需要消耗§l75MP§f.』"
execute if score @s MP matches ..29 run playsound block.bone_block.place ambient @s ~ ~ ~ 1 0.8 0
execute if score @s MP matches ..29 run return 2

#CD没有归0则返回
execute if score @s shockwave_CD matches 1.. run scoreboard players operation #CD temp = @s shockwave_CD
execute if score @s shockwave_CD matches 1.. run scoreboard players set #CD temp1 20
execute if score @s shockwave_CD matches 1.. run scoreboard players operation #CD temp /= #CD temp1
execute if score @s shockwave_CD matches 1.. run scoreboard players add #CD temp 1
execute if score @s shockwave_CD matches 1.. run title @s actionbar [{"text":"§l『震荡波』§f技能CD还剩"},{"score": {"name": "#CD","objective": "temp"},"bold": true},{"text":"s","bold": true}]
execute if score @s shockwave_CD matches 1.. run playsound block.bone_block.break ambient @s ~ ~ ~ 1.0 0.8 0
execute if score @s shockwave_CD matches 1.. run return 3


#设置技能CD
scoreboard players set @s shockwave_CD 600
scoreboard players remove @s MP 35

#音效
playsound minecraft:entity.warden.attack_impact ambient @s ~ ~ ~ 1 0.6 0
particle shriek 1 ^ ^1 ^2 -2 1 3 0.1 200
particle shriek 1 ^ ^3 ^ 3 1 1 0.1 200

#标记锁定范围内的实体为lock
execute positioned ^ ^ ^1 run tag @e[tag=enemy,distance=..4] add lock
execute positioned ^ ^ ^2 run tag @e[tag=enemy,distance=..4] add lock
execute positioned ^ ^ ^3 run tag @e[tag=enemy,distance=..4] add lock
execute positioned ^ ^ ^4 run tag @e[tag=enemy,distance=..4] add lock
execute positioned ^ ^ ^5 run tag @e[tag=enemy,distance=..4] add lock
execute positioned ^3 ^ ^4 run tag @e[tag=enemy,distance=..5] add lock
execute positioned ^-3 ^ ^4 run tag @e[tag=enemy,distance=..5] add lock


#锁定范围内没有敌人则提示玩家
execute unless entity @e[tag=lock] run title @s actionbar "『技能锁定范围内没有敌人』"

#造成伤害后移除lock
execute as @e[tag=lock,limit=8,sort=nearest] run effect give @s weakness 240 1 true
execute as @e[tag=lock,limit=8,sort=nearest] run effect give @s slowness 240 1 true
execute as @e[tag=lock,limit=8,sort=nearest] run scoreboard players set @s stun 160
tag @e[tag=lock] remove lock