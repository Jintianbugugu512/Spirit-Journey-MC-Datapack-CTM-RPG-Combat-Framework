#MP不足则返回
execute if score @s MP matches ..49 run title @s actionbar "『MP不足,使用§l圣盾§f需要消耗§l75MP§f.』"
execute if score @s MP matches ..49 run playsound block.bone_block.place ambient @s ~ ~ ~ 1 0.8 0
execute if score @s MP matches ..49 run return 2

#CD没有归0则返回
execute if score @s sacred_shield_CD matches 1.. run scoreboard players operation #CD temp = @s sacred_shield_CD
execute if score @s sacred_shield_CD matches 1.. run scoreboard players set #CD temp1 20
execute if score @s sacred_shield_CD matches 1.. run scoreboard players operation #CD temp /= #CD temp1
execute if score @s sacred_shield_CD matches 1.. run scoreboard players add #CD temp 1
execute if score @s sacred_shield_CD matches 1.. run title @s actionbar [{"text":"§l『圣盾』§f技能CD还剩"},{"score": {"name": "#CD","objective": "temp"},"bold": true},{"text":"s","bold": true}]
execute if score @s sacred_shield_CD matches 1.. run playsound block.bone_block.break ambient @s ~ ~ ~ 1.0 0.8 0
execute if score @s sacred_shield_CD matches 1.. run return 3


#设置技能CD
scoreboard players set @s sacred_shield_CD 16
scoreboard players remove @s MP 50

#音效
execute run playsound entity.player.levelup ambient @s ~ ~ ~ 0.6 0.6 0
particle dust_color_transition 0.0 0.1 0.9 1.25 1.0 1.0 0.0 ~ ~ ~ 1 1 1 1 150

scoreboard players set @s can_be_effect 400
effect give @s absorption 20 6
