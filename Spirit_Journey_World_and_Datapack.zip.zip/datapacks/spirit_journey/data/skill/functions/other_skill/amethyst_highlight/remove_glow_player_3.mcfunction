# 移除 player_3 紫晶高亮标记的敌人的 can_glow 和 amethyst_glowing 标签
tag @e[tag=enemy,tag=amethyst_glowing_player_3] remove can_glow
tag @e[tag=enemy,tag=amethyst_glowing_player_3] remove amethyst_glowing_player_3
team leave @e[tag=enemy,tag=amethyst_glowing_player_3]
