# 紫晶高亮 - 高亮周围12格内的敌人5秒
# 冷却：12s，消耗：30MP

# MP不足则返回
$execute as @a[tag=$(player)] at @s if score @s MP matches ..29 run title @s actionbar "『MP不足,使用§l紫晶高亮§f需要消耗§l30MP§f.』"
$execute as @a[tag=$(player)] at @s if score @s MP matches ..29 run playsound block.bone_block.place ambient @s ~ ~ ~ 1 0.8 0
$execute as @a[tag=$(player)] at @s if score @s MP matches ..29 run return 2

# CD没有归0则返回
$execute as @a[tag=$(player)] at @s if score @s amethyst_highlight_CD matches 1.. run scoreboard players operation #CD temp = @s amethyst_highlight_CD
$execute as @a[tag=$(player)] at @s if score @s amethyst_highlight_CD matches 1.. run scoreboard players set #CD temp1 20
$execute as @a[tag=$(player)] at @s if score @s amethyst_highlight_CD matches 1.. run scoreboard players operation #CD temp /= #CD temp1
$execute as @a[tag=$(player)] at @s if score @s amethyst_highlight_CD matches 1.. run scoreboard players add #CD temp 1
$execute as @a[tag=$(player)] at @s if score @s amethyst_highlight_CD matches 1.. run title @s actionbar [{"text":"§l『紫晶高亮』§f技能CD还剩"},{"score": {"name": "#CD","objective": "temp"},"bold": true},{"text":"s","bold": true}]
$execute as @a[tag=$(player)] at @s if score @s amethyst_highlight_CD matches 1.. run playsound block.bone_block.break ambient @s ~ ~ ~ 1.0 0.7 0
$execute as @a[tag=$(player)] at @s if score @s amethyst_highlight_CD matches 1.. run return 3

# 设置技能CD，减去MP
$execute as @a[tag=$(player)] run scoreboard players set @s amethyst_highlight_CD 240
$execute as @a[tag=$(player)] run scoreboard players remove @s MP 30

# 音效和粒子
$execute as @a[tag=$(player)] at @s run playsound block.amethyst_block.chime ambient @a[distance=..16] ~ ~ ~ 1 0.8 0
$execute as @a[tag=$(player)] at @s run playsound block.amethyst_cluster.break ambient @a[distance=..16] ~ ~ ~ 1 1.2 0
$execute as @a[tag=$(player)] at @s run particle dust 0.6 0.2 0.8 1.5 ~ ~1 ~ 3 1 3 0.1 100 force

# 给周围12格内的敌人添加发光效果（5秒 = 100tick）和 can_glow 标签
$execute as @a[tag=$(player)] at @s run tag @e[tag=enemy,distance=..12] add can_glow
$execute as @a[tag=$(player)] at @s run tag @e[tag=enemy,distance=..12] add amethyst_glowing_$(player)
$execute as @a[tag=$(player)] at @s run team join amethyst_glow @e[tag=enemy,distance=..12]
$execute as @a[tag=$(player)] at @s run effect give @e[tag=enemy,distance=..12] glowing 5 0 true

# 视觉反馈：在每个被高亮的敌人位置播放粒子
$execute as @a[tag=$(player)] at @s as @e[tag=enemy,distance=..12] at @s run particle dust 0.8 0.3 1.0 2 ~ ~1 ~ 0.5 0.8 0.5 0.1 30 force
$execute as @a[tag=$(player)] at @s as @e[tag=enemy,distance=..12] at @s run particle flash ~ ~1 ~ 0 0 0 0 1 force

# 5秒后移除标签
$schedule function skill:other_skill/amethyst_highlight/remove_glow_$(player) 100t
