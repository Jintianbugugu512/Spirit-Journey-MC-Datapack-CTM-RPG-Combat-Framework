# 移除 player_2 紫晶高亮标记的敌人的 can_glow 和 amethyst_glowing 标签
tag @e[tag=enemy,tag=amethyst_glowing_player_2] remove can_glow
tag @e[tag=enemy,tag=amethyst_glowing_player_2] remove amethyst_glowing_player_2
team leave @e[tag=enemy,tag=amethyst_glowing_player_2]
