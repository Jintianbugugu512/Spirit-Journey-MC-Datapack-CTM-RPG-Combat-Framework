#MP不足则返回
$execute as @a[tag=$(player)] at @s if score @s MP matches ..9 run title @s actionbar "『MP不足,使用§l冲刺§f需要消耗§l10MP§f.』"
$execute as @a[tag=$(player)] at @s if score @s MP matches ..9 run playsound block.bone_block.place ambient @s ~ ~ ~ 1 0.8 0
$execute as @a[tag=$(player)] at @s if score @s MP matches ..9 run return 2

#设置技能CD
$execute as @a[tag=$(player)] run scoreboard players remove @s MP 10

#音效
$execute as @a[tag=$(player)] at @s run playsound item.book.page_turn ambient @s ~ ~ ~ 0.6 0.6 0

# 计算冲刺方向
$execute as @a[tag=$(player)] at @s positioned 0.0 0.0 0.0 run summon armor_stand ^ ^ ^3 {Tags:["mmark_"],NoGravity:1b}
execute store result storage sj:other motion_x double 0.0000001 run data get entity @e[limit=1,tag=mmark_] Pos[0] 10000000
execute store result storage sj:other motion_z double 0.0000001 run data get entity @e[limit=1,tag=mmark_] Pos[2] 10000000
$execute as @a[tag=$(player)] at @s run function skill:other_skill/airdash/shot with storage sj:other

# 添加玩家ID标签用于溯源
$tag @e[tag=summon] add airdash_bullet_$(player)
$tag @e[tag=summon] add airdash_bullet

scoreboard players set @e[tag=summon] countDown 4
tag @e[tag=summon] remove summon
kill @e[tag=mmark_,type=armor_stand]
