#MP不足则返回
execute if score @s MP matches ..9 run title @s actionbar "『MP不足,使用§l后撤§f需要消耗§l10MP§f.』"
execute if score @s MP matches ..9 run playsound block.bone_block.place ambient @s ~ ~ ~ 1 0.8 0
execute if score @s MP matches ..9 run return 2

#设置技能CD
scoreboard players remove @s MP 10

#音效
execute run playsound item.book.page_turn ambient @s ~ ~ ~ 0.6 0.6 0






execute positioned 0.0 0.0 0.0 run summon armor_stand ^ ^ ^-3 {Tags:["mmark_"],NoGravity:1b}
execute store result storage sj:other motion_x double 0.0000001 run data get entity @e[limit=1,tag=mmark_] Pos[0] 10000000
execute store result storage sj:other motion_z double 0.0000001 run data get entity @e[limit=1,tag=mmark_] Pos[2] 10000000
function skill:other_skill/airdash/shot_ with storage sj:other

$tag @e[tag=summon] add airdash_bullet_$(player)
# execute as @e[tag=summon] run data modify entity @s Motion set from entity @e[limit=1,tag=mmark__] Pos
effect give @e[tag=enemy,distance=..6] slowness 2 1 true
particle dust_color_transition 0.0 1.0 0.9 1.6 0.0 1.0 0.0 ~ ~1 ~ 2 1 2 1 75


scoreboard players set @e[tag=summon] countDown 4
tag @e[tag=summon] remove summon
kill @e[tag=mmark_,type=armor_stand]