#CD没有归0则返回
$execute as @a[tag=$(player)] at @s if score @s blood_CD matches 1.. run scoreboard players operation #CD temp = @s blood_CD
$execute as @a[tag=$(player)] at @s if score @s blood_CD matches 1.. run scoreboard players set #CD temp1 20
$execute as @a[tag=$(player)] at @s if score @s blood_CD matches 1.. run scoreboard players operation #CD temp /= #CD temp1
$execute as @a[tag=$(player)] at @s if score @s blood_CD matches 1.. run scoreboard players add #CD temp 1
$execute as @a[tag=$(player)] at @s if score @s blood_CD matches 1.. run title @s actionbar [{"text":"『御血』技能CD还剩"},{"score": {"name": "#CD","objective": "temp"},"bold": true},{"text":"s","bold": true}]
$execute as @a[tag=$(player)] at @s if score @s blood_CD matches 1.. run playsound block.bone_block.break ambient @s ~ ~ ~ 1.0 0.8 0
$execute as @a[tag=$(player)] at @s if score @s blood_CD matches 1.. run return 3

#设置技能CD
$execute as @a[tag=$(player)] run scoreboard players set @s blood_CD 400

#音效
$execute as @a[tag=$(player)] at @s run playsound entity.blaze.death ambient @s ~ ~ ~ 1 0.7 0



attribute @s generic.armor base set 0

execute store result score #HP_D temp run attribute @s generic.max_health base get 1
scoreboard players set #HP_D temp1 4
scoreboard players operation #HP_D temp /= #HP_D temp1
execute store result storage damage:damage blood_hp_delete int 1 run scoreboard players get #HP_D temp1

execute as @s run function skill:other_skill/blood/blood_damage with storage damage:damage









scoreboard players set @s blood_buff 240