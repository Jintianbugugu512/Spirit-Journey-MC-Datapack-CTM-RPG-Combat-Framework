scoreboard players operation #blood temp = @s strength
scoreboard players set #blood temp1 2
scoreboard players operation #blood temp /= #blood temp1
scoreboard players operation @s strength_ += #blood temp

# tellraw @p [{"text":""},{"score": {"name": "@p","objective": "MP"},"bold": true,"color": "blue"}]