

$damage @s $(blood_hp_delete)