#MP不足则返回
$execute as @a[tag=$(player)] at @s if score @s MP matches ..1 run title @s actionbar "『MP不足,使用§l紫晶标记§f需要消耗§l2MP§f.』"
$execute as @a[tag=$(player)] at @s if score @s MP matches ..1 run playsound block.bone_block.place ambient @s ~ ~ ~ 1 0.8 0
$execute as @a[tag=$(player)] at @s if score @s MP matches ..1 run return 2

$execute as @a[tag=$(player)] run scoreboard players remove @s MP 2


$execute unless entity @e[tag=ame_sign_$(player),distance=..50] run scoreboard players set #ame temp 0

#50格内存在标记则传送至标记
$execute if entity @e[tag=ame_sign_$(player),distance=..50] run execute at @e[tag=ame_sign_$(player),distance=..50,limit=1,sort=nearest] run execute if entity @e[tag=enemy,distance=..10] run tp @a[tag=$(player)] ~ ~ ~ facing entity @e[tag=enemy,limit=1,sort=nearest,distance=..10]
$execute if entity @e[tag=ame_sign_$(player),distance=..50] run execute at @e[tag=ame_sign_$(player),distance=..50,limit=1,sort=nearest] run execute unless entity @e[tag=enemy,distance=..10] run tp @a[tag=$(player)] ~ ~ ~

$execute if entity @e[tag=ame_sign_$(player),distance=..50] run execute if entity @e[tag=ame_sign_$(player),distance=10..] run execute at @e[tag=ame_sign_$(player),distance=..50,limit=1,sort=nearest] run scoreboard players set @e[tag=enemy,distance=..5] stun 30
$execute if entity @e[tag=ame_sign_$(player),distance=..50] run execute at @e[tag=ame_sign_$(player),distance=..50,limit=1,sort=nearest] run particle dust_color_transition 1.0 0.5 0.5 1.0 0.0 0.0 1.0 ~ ~1 ~ 1 1 1 1 200
$execute if entity @e[tag=ame_sign_$(player),distance=..50] run execute at @e[tag=ame_sign_$(player),distance=..50,limit=1,sort=nearest] run playsound entity.enderman.teleport ambient @s ~ ~ ~ 1 0.9 0
$execute if entity @e[tag=ame_sign_$(player),distance=..50] run scoreboard players set #ame temp 1
$execute if entity @e[tag=ame_sign_$(player),distance=..50] run kill @e[tag=ame_sign_$(player)]
execute if score #ame temp matches 1 run return 3

#50格内没有标记则放置标记
$execute unless entity @e[tag=ame_sign_$(player),distance=..50] run execute at @a[tag=$(player)] run particle dust_color_transition 1.0 0.5 0.5 1.0 0.0 0.0 1.0 ~ ~1 ~ 1 1 1 1 200
$execute unless entity @e[tag=ame_sign_$(player),distance=..50] run execute at @a[tag=$(player)] run playsound block.amethyst_cluster.place ambient @s ~ ~ ~ 1 0.8 0
$execute unless entity @e[tag=ame_sign_$(player),distance=..50] run summon block_display ~ ~ ~ {block_state:{Name:"amethyst_cluster"},Tags:["ame_sign_$(player)"]}


