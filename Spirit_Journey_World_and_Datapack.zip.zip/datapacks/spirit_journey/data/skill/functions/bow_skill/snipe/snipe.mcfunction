#召唤箭矢
#MP不足则返回
$execute as @a[tag=$(player)] at @s if score @s MP matches ..14 run title @s actionbar "『MP不足,使用§l狙击§f需要消耗§l15MP§f.』"
$execute as @a[tag=$(player)] at @s if score @s MP matches ..14 run playsound block.bone_block.place ambient @s ~ ~ ~ 1 0.8 0
$execute as @a[tag=$(player)] at @s if score @s MP matches ..14 run return 2

#CD没有归0则返回
$execute as @a[tag=$(player)] at @s if score @s snipe_CD matches 1.. run scoreboard players operation #CD temp = @s snipe_CD
$execute as @a[tag=$(player)] at @s if score @s snipe_CD matches 1.. run scoreboard players set #CD temp1 20
$execute as @a[tag=$(player)] at @s if score @s snipe_CD matches 1.. run scoreboard players operation #CD temp /= #CD temp1
$execute as @a[tag=$(player)] at @s if score @s snipe_CD matches 1.. run scoreboard players add #CD temp 1
$execute as @a[tag=$(player)] at @s if score @s snipe_CD matches 1.. run title @s actionbar [{"text":"『狙击』技能CD还剩"},{"score": {"name": "#CD","objective": "temp"},"bold": true},{"text":"s","bold": true}]
$execute as @a[tag=$(player)] at @s if score @s snipe_CD matches 1.. run playsound block.bone_block.break ambient @s ~ ~ ~ 1.0 0.7 0
$execute as @a[tag=$(player)] at @s if score @s snipe_CD matches 1.. run return 3

#设置技能CD,减去MP.
$execute as @a[tag=$(player)] run scoreboard players set @s snipe_CD 60
$execute as @a[tag=$(player)] run scoreboard players remove @s MP 15


$execute as @a[tag=$(player)] at @s run playsound entity.arrow.shoot ambient @s ~ ~ ~ 1 0.7 0


$execute as @a[tag=$(player)] at @s anchored eyes run summon arrow ^ ^ ^1 {Tags:["summon","bullet_from_player","snipe_bullet"],NoGravity:1b,Glowing:1b,PortalCooldown:25,PierceLevel:2,damage:-15,crit:false}

# 添加玩家ID标签用于溯源（直接使用 player 标签）
$tag @e[tag=summon] add snipe_bullet_$(player)

execute positioned 0.0 0.0 0.0 run summon armor_stand ^ ^ ^1.7 {Tags:["mmark__"],NoGravity:1b}
execute as @e[tag=summon] run data modify entity @s Motion set from entity @e[limit=1,tag=mmark__] Pos












scoreboard players set @e[tag=summon] countDown 100
tag @e[tag=summon] remove summon
kill @e[tag=mmark__,type=armor_stand]
