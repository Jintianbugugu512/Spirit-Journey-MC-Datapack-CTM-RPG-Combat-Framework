# 使用 on origin 追溯发射者，此函数在玩家（发射者）身份下执行
# @s = 发射者玩家

# 将玩家标签存储到 storage 中
execute if entity @s[tag=player_1] run data merge storage snipe:temp {player:"player_1"}
execute if entity @s[tag=player_2] run data merge storage snipe:temp {player:"player_2"}
execute if entity @s[tag=player_3] run data merge storage snipe:temp {player:"player_3"}

# 返回到子弹位置执行伤害
execute as @e[tag=snipe_bullet,limit=1,sort=nearest] at @s run function skill:bow_skill/snipe/snipe_damage_origin_at_bullet with storage snipe:temp

