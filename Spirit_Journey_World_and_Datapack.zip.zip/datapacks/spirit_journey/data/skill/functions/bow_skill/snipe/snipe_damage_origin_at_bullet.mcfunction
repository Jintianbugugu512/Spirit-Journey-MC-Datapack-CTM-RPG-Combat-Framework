# 在子弹位置执行伤害逻辑
# @s = 子弹实体
# 参数：player - 玩家标签（"player_1", "player_2", "player_3"）

# 计算蓄力时间（通过 PortalCooldown 倒计时）
scoreboard players set @s temp 25
execute store result score @s temp1 run data get entity @s PortalCooldown
scoreboard players operation @s temp -= @s temp1

# 粒子效果
particle block minecraft:glass ~ ~ ~ 1 1 1 0.1 250

# 根据蓄力时间造成不同伤害
$execute if score @s temp matches 1 as @e[tag=enemy,distance=..2.8,limit=1,sort=nearest] run function combat:deal/damage_deal {"rate":"200","type":"physic","player":"$(player)","interval":"cactus"}
$execute if score @s temp matches 2 as @e[tag=enemy,distance=..2.8,limit=1,sort=nearest] run function combat:deal/damage_deal {"rate":"400","type":"physic","player":"$(player)","interval":"cactus"}
$execute if score @s temp matches 3 as @e[tag=enemy,distance=..2.8,limit=1,sort=nearest] run function combat:deal/damage_deal {"rate":"60","type":"physic","player":"$(player)","interval":"cactus"}
$execute if score @s temp matches 4 as @e[tag=enemy,distance=..2.8,limit=1,sort=nearest] run function combat:deal/damage_deal {"rate":"80","type":"physic","player":"$(player)","interval":"cactus"}
$execute if score @s temp matches 5 as @e[tag=enemy,distance=..2.8,limit=1,sort=nearest] run function combat:deal/damage_deal {"rate":"100","type":"physic","player":"$(player)","interval":"cactus"}
$execute if score @s temp matches 6 as @e[tag=enemy,distance=..2.8,limit=1,sort=nearest] run function combat:deal/damage_deal {"rate":"120","type":"physic","player":"$(player)","interval":"cactus"}
$execute if score @s temp matches 7 as @e[tag=enemy,distance=..2.8,limit=1,sort=nearest] run function combat:deal/damage_deal {"rate":"140","type":"physic","player":"$(player)","interval":"cactus"}
$execute if score @s temp matches 8 as @e[tag=enemy,distance=..2.8,limit=1,sort=nearest] run function combat:deal/damage_deal {"rate":"160","type":"physic","player":"$(player)","interval":"cactus"}
$execute if score @s temp matches 9 as @e[tag=enemy,distance=..2.8,limit=1,sort=nearest] run function combat:deal/damage_deal {"rate":"180","type":"physic","player":"$(player)","interval":"cactus"}
$execute if score @s temp matches 10 as @e[tag=enemy,distance=..2.8,limit=1,sort=nearest] run function combat:deal/damage_deal {"rate":"200","type":"physic","player":"$(player)","interval":"cactus"}
$execute if score @s temp matches 11 as @e[tag=enemy,distance=..2.8,limit=1,sort=nearest] run function combat:deal/damage_deal {"rate":"220","type":"physic","player":"$(player)","interval":"cactus"}
$execute if score @s temp matches 12 as @e[tag=enemy,distance=..2.8,limit=1,sort=nearest] run function combat:deal/damage_deal {"rate":"240","type":"physic","player":"$(player)","interval":"cactus"}
$execute if score @s temp matches 13 as @e[tag=enemy,distance=..2.8,limit=1,sort=nearest] run function combat:deal/damage_deal {"rate":"260","type":"physic","player":"$(player)","interval":"cactus"}
$execute if score @s temp matches 14 as @e[tag=enemy,distance=..2.8,limit=1,sort=nearest] run function combat:deal/damage_deal {"rate":"280","type":"physic","player":"$(player)","interval":"cactus"}
$execute if score @s temp matches 15 as @e[tag=enemy,distance=..2.8,limit=1,sort=nearest] run function combat:deal/damage_deal {"rate":"300","type":"physic","player":"$(player)","interval":"cactus"}
$execute if score @s temp matches 16 as @e[tag=enemy,distance=..2.8,limit=1,sort=nearest] run function combat:deal/damage_deal {"rate":"320","type":"physic","player":"$(player)","interval":"cactus"}
$execute if score @s temp matches 17 as @e[tag=enemy,distance=..2.8,limit=1,sort=nearest] run function combat:deal/damage_deal {"rate":"340","type":"physic","player":"$(player)","interval":"cactus"}
$execute if score @s temp matches 18 as @e[tag=enemy,distance=..2.8,limit=1,sort=nearest] run function combat:deal/damage_deal {"rate":"360","type":"physic","player":"$(player)","interval":"cactus"}
$execute if score @s temp matches 19 as @e[tag=enemy,distance=..2.8,limit=1,sort=nearest] run function combat:deal/damage_deal {"rate":"380","type":"physic","player":"$(player)","interval":"cactus"}
$execute if score @s temp matches 20 as @e[tag=enemy,distance=..2.8,limit=1,sort=nearest] run function combat:deal/damage_deal {"rate":"400","type":"physic","player":"$(player)","interval":"cactus"}
$execute if score @s temp matches 21 as @e[tag=enemy,distance=..2.8,limit=1,sort=nearest] run function combat:deal/damage_deal {"rate":"420","type":"physic","player":"$(player)","interval":"cactus"}
$execute if score @s temp matches 22 as @e[tag=enemy,distance=..2.8,limit=1,sort=nearest] run function combat:deal/damage_deal {"rate":"440","type":"physic","player":"$(player)","interval":"cactus"}
$execute if score @s temp matches 23 as @e[tag=enemy,distance=..2.8,limit=1,sort=nearest] run function combat:deal/damage_deal {"rate":"460","type":"physic","player":"$(player)","interval":"cactus"}
$execute if score @s temp matches 24 as @e[tag=enemy,distance=..2.8,limit=1,sort=nearest] run function combat:deal/damage_deal {"rate":"480","type":"physic","player":"$(player)","interval":"cactus"}
$execute if score @s temp matches 25 as @e[tag=enemy,distance=..2.8,limit=1,sort=nearest] run function combat:deal/damage_deal {"rate":"500","type":"physic","player":"$(player)","interval":"cactus"}

# 应用伤害间隔（防止重复伤害）
execute as @e[tag=enemy,distance=..2.8,limit=1,sort=nearest] run data modify entity @s PortalCooldown set value 3
$execute as @e[tag=enemy,distance=..2.8,limit=1,sort=nearest] run damage @s 0 minecraft:cactus by @a[tag=$(player),limit=1]

# 清除子弹
kill @s
