scoreboard players set @s temp 25
execute store result score @s temp1 run data get entity @s PortalCooldown
scoreboard players operation @s temp -= @s temp1

particle block minecraft:glass ~ ~ ~ 1 1 1 0.1 250
$execute if score @s temp matches 1 run execute as @e[tag=enemy,distance=..2.8,limit=1,sort=nearest] run function combat:deal/damage_deal {"rate":"20","type":"physic","player":"$(player)","interval":"cactus"}
$execute if score @s temp matches 2 run execute as @e[tag=enemy,distance=..2.8,limit=1,sort=nearest] run function combat:deal/damage_deal {"rate":"40","type":"physic","player":"$(player)","interval":"cactus"}
$execute if score @s temp matches 3 run execute as @e[tag=enemy,distance=..2.8,limit=1,sort=nearest] run function combat:deal/damage_deal {"rate":"60","type":"physic","player":"$(player)","interval":"cactus"}
$execute if score @s temp matches 4 run execute as @e[tag=enemy,distance=..2.8,limit=1,sort=nearest] run function combat:deal/damage_deal {"rate":"80","type":"physic","player":"$(player)","interval":"cactus"}
$execute if score @s temp matches 5 run execute as @e[tag=enemy,distance=..2.8,limit=1,sort=nearest] run function combat:deal/damage_deal {"rate":"10","type":"physic","player":"$(player)","interval":"cactus"}
$execute if score @s temp matches 6 run execute as @e[tag=enemy,distance=..2.8,limit=1,sort=nearest] run function combat:deal/damage_deal {"rate":"12","type":"physic","player":"$(player)","interval":"cactus"}
$execute if score @s temp matches 7 run execute as @e[tag=enemy,distance=..2.8,limit=1,sort=nearest] run function combat:deal/damage_deal {"rate":"14","type":"physic","player":"$(player)","interval":"cactus"}
$execute if score @s temp matches 8 run execute as @e[tag=enemy,distance=..2.8,limit=1,sort=nearest] run function combat:deal/damage_deal {"rate":"16","type":"physic","player":"$(player)","interval":"cactus"}
$execute if score @s temp matches 9 run execute as @e[tag=enemy,distance=..2.8,limit=1,sort=nearest] run function combat:deal/damage_deal {"rate":"18","type":"physic","player":"$(player)","interval":"cactus"}
$execute if score @s temp matches 10 run execute as @e[tag=enemy,distance=..2.8,limit=1,sort=nearest] run function combat:deal/damage_deal {"rate":"20","type":"physic","player":"$(player)","interval":"cactus"}
$execute if score @s temp matches 11 run execute as @e[tag=enemy,distance=..2.8,limit=1,sort=nearest] run function combat:deal/damage_deal {"rate":"22","type":"physic","player":"$(player)","interval":"cactus"}
$execute if score @s temp matches 12 run execute as @e[tag=enemy,distance=..2.8,limit=1,sort=nearest] run function combat:deal/damage_deal {"rate":"24","type":"physic","player":"$(player)","interval":"cactus"}
$execute if score @s temp matches 13 run execute as @e[tag=enemy,distance=..2.8,limit=1,sort=nearest] run function combat:deal/damage_deal {"rate":"26","type":"physic","player":"$(player)","interval":"cactus"}
$execute if score @s temp matches 14 run execute as @e[tag=enemy,distance=..2.8,limit=1,sort=nearest] run function combat:deal/damage_deal {"rate":"28","type":"physic","player":"$(player)","interval":"cactus"}
$execute if score @s temp matches 15 run execute as @e[tag=enemy,distance=..2.8,limit=1,sort=nearest] run function combat:deal/damage_deal {"rate":"30","type":"physic","player":"$(player)","interval":"cactus"}
$execute if score @s temp matches 16 run execute as @e[tag=enemy,distance=..2.8,limit=1,sort=nearest] run function combat:deal/damage_deal {"rate":"32","type":"physic","player":"$(player)","interval":"cactus"}
$execute if score @s temp matches 17 run execute as @e[tag=enemy,distance=..2.8,limit=1,sort=nearest] run function combat:deal/damage_deal {"rate":"34","type":"physic","player":"$(player)","interval":"cactus"}
$execute if score @s temp matches 18 run execute as @e[tag=enemy,distance=..2.8,limit=1,sort=nearest] run function combat:deal/damage_deal {"rate":"36","type":"physic","player":"$(player)","interval":"cactus"}
$execute if score @s temp matches 19 run execute as @e[tag=enemy,distance=..2.8,limit=1,sort=nearest] run function combat:deal/damage_deal {"rate":"38","type":"physic","player":"$(player)","interval":"cactus"}
$execute if score @s temp matches 20 run execute as @e[tag=enemy,distance=..2.8,limit=1,sort=nearest] run function combat:deal/damage_deal {"rate":"40","type":"physic","player":"$(player)","interval":"cactus"}
$execute if score @s temp matches 21 run execute as @e[tag=enemy,distance=..2.8,limit=1,sort=nearest] run function combat:deal/damage_deal {"rate":"42","type":"physic","player":"$(player)","interval":"cactus"}
$execute if score @s temp matches 22 run execute as @e[tag=enemy,distance=..2.8,limit=1,sort=nearest] run function combat:deal/damage_deal {"rate":"44","type":"physic","player":"$(player)","interval":"cactus"}
$execute if score @s temp matches 23 run execute as @e[tag=enemy,distance=..2.8,limit=1,sort=nearest] run function combat:deal/damage_deal {"rate":"46","type":"physic","player":"$(player)","interval":"cactus"}
$execute if score @s temp matches 24 run execute as @e[tag=enemy,distance=..2.8,limit=1,sort=nearest] run function combat:deal/damage_deal {"rate":"48","type":"physic","player":"$(player)","interval":"cactus"}
$execute if score @s temp matches 25 run execute as @e[tag=enemy,distance=..2.8,limit=1,sort=nearest] run function combat:deal/damage_deal {"rate":"50","type":"physic","player":"$(player)","interval":"cactus"}





$execute as @e[tag=enemy,distance=..2.8,limit=1,sort=nearest] run damage @s 0 minecraft:cactus by @a[limit=1,tag=$(player)]

kill @s
