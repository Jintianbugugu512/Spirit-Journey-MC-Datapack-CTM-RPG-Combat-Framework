
#MP不足则返回
$execute as @a[tag=$(player)] at @s if score @s MP matches ..9 run title @s actionbar "『MP不足,使用§l快速装填§f需要消耗§l10MP§f.』"
$execute as @a[tag=$(player)] at @s if score @s MP matches ..9 run playsound block.bone_block.place ambient @s ~ ~ ~ 1 0.8 0
$execute as @a[tag=$(player)] at @s if score @s MP matches ..9 run return 2

#CD没有归0则返回
$execute as @a[tag=$(player)] at @s if score @s quickly_load matches 1.. run scoreboard players operation #CD temp = @s quickly_load
$execute as @a[tag=$(player)] at @s if score @s quickly_load matches 1.. run scoreboard players set #CD temp1 20
$execute as @a[tag=$(player)] at @s if score @s quickly_load matches 1.. run scoreboard players operation #CD temp /= #CD temp1
$execute as @a[tag=$(player)] at @s if score @s quickly_load matches 1.. run scoreboard players add #CD temp 1
$execute as @a[tag=$(player)] at @s if score @s quickly_load matches 1.. run title @s actionbar [{"text":"§l『快速装填』§f技能CD还剩"},{"score": {"name": "#CD","objective": "temp"},"bold": true},{"text":"s","bold": true}]
$execute as @a[tag=$(player)] at @s if score @s quickly_load matches 1.. run playsound block.bone_block.break ambient @s ~ ~ ~ 1.0 0.7 0
$execute as @a[tag=$(player)] at @s if score @s quickly_load matches 1.. run return 3

#设置技能CD,减去MP.
$execute as @a[tag=$(player)] run scoreboard players set @s quickly_load 100
$execute as @a[tag=$(player)] run scoreboard players remove @s MP 10
#粒子与音效
$execute as @a[tag=$(player)] at @s run playsound item.crossbow.shoot ambient @s ~ ~ ~ 1 0.5 0

# 只修改装填状态，保留其他NBT
$execute as @a[tag=$(player)] run item modify entity @s weapon.mainhand skill:quickly_load_modifier



