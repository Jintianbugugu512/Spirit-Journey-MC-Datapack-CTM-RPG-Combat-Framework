# ==========================================
# 凝滞弹 - 爆炸效果
# 3格范围内造成伤害和减速
# 最多命中3个敌人
# ==========================================

# 标记范围内最多3个敌人
tag @e[tag=enemy,distance=..3,limit=3,sort=nearest] add stasis_shot_target

# 对目标造成伤害 - 根据子弹的玩家ID标签
execute if entity @e[tag=stasis_shot_bullet_player_1,limit=1] as @e[tag=stasis_shot_target] run function combat:deal/damage_deal {rate:"75",type:"physic",player:"player_1",interval:"cactus"}
execute if entity @e[tag=stasis_shot_bullet_player_2,limit=1] as @e[tag=stasis_shot_target] run function combat:deal/damage_deal {rate:"75",type:"physic",player:"player_2",interval:"cactus"}
execute if entity @e[tag=stasis_shot_bullet_player_3,limit=1] as @e[tag=stasis_shot_target] run function combat:deal/damage_deal {rate:"75",type:"physic",player:"player_3",interval:"cactus"}

# 给目标添加减速II效果（10秒 = 200tick）
execute as @e[tag=stasis_shot_target] run effect give @s slowness 10 1 false

# 清除目标标签
tag @e[tag=stasis_shot_target] remove stasis_shot_target

# 爆炸视觉效果（冰冻主题）
particle explosion ~ ~ ~ 0.8 0.8 0.8 0.1 8
particle dust 0.5 0.8 1.0 2.0 ~ ~ ~ 1.5 1.5 1.5 0 100
particle snowflake ~ ~ ~ 2 2 2 0.1 80
particle falling_water ~ ~ ~ 1.5 1.5 1.5 0.05 60
particle block minecraft:ice ~ ~ ~ 1 1 1 0 40

# 音效
playsound entity.generic.explode player @a ~ ~ ~ 1.2 1.5
playsound block.glass.break player @a ~ ~ ~ 1.5 1
playsound block.snow.break player @a ~ ~ ~ 2 0.8

# 清除子弹
kill @s

