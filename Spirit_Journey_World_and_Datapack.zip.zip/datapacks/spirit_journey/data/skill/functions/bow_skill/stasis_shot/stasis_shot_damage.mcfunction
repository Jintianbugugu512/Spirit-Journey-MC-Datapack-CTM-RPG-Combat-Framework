# ==========================================
# 凝滞弹 - 伤害计算
# 对单个敌人造成75%物理伤害
# ==========================================

# 根据子弹标签判断是哪个玩家
execute if entity @s[tag=stasis_shot_target] if entity @e[tag=stasis_shot_bullet_player_1,limit=1] run function skill:bow_skill/stasis_shot/stasis_shot_damage_player with storage damage:player_1 {id:"1"}
execute if entity @s[tag=stasis_shot_target] if entity @e[tag=stasis_shot_bullet_player_2,limit=1] run function skill:bow_skill/stasis_shot/stasis_shot_damage_player with storage damage:player_2 {id:"2"}
execute if entity @s[tag=stasis_shot_target] if entity @e[tag=stasis_shot_bullet_player_3,limit=1] run function skill:bow_skill/stasis_shot/stasis_shot_damage_player with storage damage:player_3 {id:"3"}
