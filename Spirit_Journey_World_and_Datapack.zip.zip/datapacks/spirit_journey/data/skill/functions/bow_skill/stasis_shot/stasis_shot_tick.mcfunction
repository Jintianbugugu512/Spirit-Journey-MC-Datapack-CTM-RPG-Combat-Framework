# ==========================================
# 凝滞弹 - 子弹移动与碰撞检测
# 每tick生成寒冰粒子轨迹
# 检测是否命中敌人
# ==========================================

# 寒冰粒子轨迹（使用冰蓝色dust粒子和雪花粒子）
particle dust 0.5 0.8 1.0 1.0 ~ ~ ~ 0.1 0.1 0.1 0 5 force
particle snowflake ~ ~ ~ 0.15 0.15 0.15 0.01 3 force
particle falling_water ~ ~ ~ 0.1 0.1 0.1 0 2 force

# 子弹寿命递减
scoreboard players remove @s temp 1

# 超时自动清除
execute if score @s temp matches ..0 run kill @s

# 检测是否命中敌人
execute if entity @e[tag=enemy,distance=..1.5] run function skill:bow_skill/stasis_shot/stasis_shot_explosion
