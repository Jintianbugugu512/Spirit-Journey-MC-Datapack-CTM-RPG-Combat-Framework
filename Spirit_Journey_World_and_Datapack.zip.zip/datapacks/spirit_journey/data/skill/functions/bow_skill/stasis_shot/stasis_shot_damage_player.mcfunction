# ==========================================
# 凝滞弹 - 玩家伤害应用
# 设置75%伤害倍率并调用伤害API
# ==========================================

# 设置伤害倍率为75%
$scoreboard players set @a[tag=player_$(id)] temp 75

# 调用物理伤害API
$function combat:damage_type/physic_damage with storage damage:player_$(id)
