# ==========================================
# 高压弹 - 爆炸效果
# 精准单体攻击，强化敌人
# ==========================================

# 标记最近的1个敌人（2.5格范围）
tag @e[tag=enemy,distance=..2.5,limit=1,sort=nearest] add high_pressure_target

# 对目标造成伤害 - 根据子弹的玩家ID标签
execute if entity @e[tag=high_pressure_bullet_player_1,limit=1] as @e[tag=high_pressure_target] run function combat:deal/damage_deal {rate:"325",type:"physic",player:"player_1",interval:"cactus"}
execute if entity @e[tag=high_pressure_bullet_player_2,limit=1] as @e[tag=high_pressure_target] run function combat:deal/damage_deal {rate:"325",type:"physic",player:"player_2",interval:"cactus"}
execute if entity @e[tag=high_pressure_bullet_player_3,limit=1] as @e[tag=high_pressure_target] run function combat:deal/damage_deal {rate:"325",type:"physic",player:"player_3",interval:"cactus"}

# 给目标添加速度III和力量III效果（10秒 = 200tick）
execute as @e[tag=high_pressure_target] run effect give @s speed 10 2 false
execute as @e[tag=high_pressure_target] run effect give @s strength 10 2 false

# 清除目标标签
tag @e[tag=high_pressure_target] remove high_pressure_target

# 精准穿透视觉效果（高速、锐利）
particle crit ~ ~ ~ 0.2 0.2 0.2 0.5 30
particle sweep_attack ~ ~ ~ 0 0 0 0 3
particle end_rod ~ ~ ~ 0.3 0.3 0.3 0.2 20
particle electric_spark ~ ~ ~ 0.2 0.2 0.2 0.1 15
particle flash ~ ~ ~ 0 0 0 0 2

# 音效
playsound entity.arrow.hit_player player @a ~ ~ ~ 1.5 2
playsound entity.player.attack.crit player @a ~ ~ ~ 1.5 1.5
playsound block.anvil.land player @a ~ ~ ~ 0.8 2

# 清除子弹
kill @s
