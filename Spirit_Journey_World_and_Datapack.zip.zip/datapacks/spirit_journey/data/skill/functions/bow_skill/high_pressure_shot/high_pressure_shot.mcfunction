# ==========================================
# 高压弹 - 弩技能
# 向前方发射高速精准弹，单体高伤
# 造成325%物理伤害，但会给敌人速度III和力量III各10秒
# ==========================================

# MP不足则返回
$execute as @a[tag=$(player)] at @s if score @s MP matches ..24 run title @s actionbar "『MP不足,使用§l高压弹§f需要消耗§l25MP§f.』"
$execute as @a[tag=$(player)] at @s if score @s MP matches ..24 run playsound block.bone_block.place ambient @s ~ ~ ~ 1 0.8 0
$execute as @a[tag=$(player)] at @s if score @s MP matches ..24 run return 2

# CD没有归0则返回
$execute as @a[tag=$(player)] at @s if score @s high_pressure_shot_CD matches 1.. run scoreboard players operation #CD temp = @s high_pressure_shot_CD
$execute as @a[tag=$(player)] at @s if score @s high_pressure_shot_CD matches 1.. run scoreboard players set #CD temp1 20
$execute as @a[tag=$(player)] at @s if score @s high_pressure_shot_CD matches 1.. run scoreboard players operation #CD temp /= #CD temp1
$execute as @a[tag=$(player)] at @s if score @s high_pressure_shot_CD matches 1.. run scoreboard players add #CD temp 1
$execute as @a[tag=$(player)] at @s if score @s high_pressure_shot_CD matches 1.. run title @s actionbar [{"text":"§l『高压弹』§f技能CD还剩"},{"score": {"name": "#CD","objective": "temp"},"bold": true},{"text":"s","bold": true}]
$execute as @a[tag=$(player)] at @s if score @s high_pressure_shot_CD matches 1.. run playsound block.bone_block.break ambient @s ~ ~ ~ 1.0 0.7 0
$execute as @a[tag=$(player)] at @s if score @s high_pressure_shot_CD matches 1.. run return 3

# 设置技能CD，减去MP
$execute as @a[tag=$(player)] run scoreboard players set @s high_pressure_shot_CD 240
$execute as @a[tag=$(player)] run scoreboard players remove @s MP 25

# 音效（高速破空）
$execute as @a[tag=$(player)] at @s run playsound entity.arrow.shoot ambient @a ~ ~ ~ 1.5 2 0
$execute as @a[tag=$(player)] at @s run playsound entity.player.attack.sweep ambient @a ~ ~ ~ 1 2 0

# 召唤光灵箭（高压弹）
$execute as @a[tag=$(player)] at @s anchored eyes run summon spectral_arrow ^ ^ ^1 {Tags:["summon","bullet_from_player","high_pressure_bullet"],NoGravity:1b,Glowing:1b,PortalCooldown:100,PierceLevel:10,damage:0,crit:false,Color:16777215}

# 添加玩家ID标签用于溯源
$tag @e[tag=summon] add high_pressure_bullet_$(player)

# 计算飞行方向（使用临时marker，高速2.5）
execute positioned 0.0 0.0 0.0 run summon marker ^ ^ ^2.5 {Tags:["mmark__"]}
execute as @e[tag=summon] run data modify entity @s Motion set from entity @e[limit=1,tag=mmark__] Pos

# 设置子弹寿命（60 tick，快速到达）
scoreboard players set @e[tag=summon] temp 60

# 清理临时实体和标签
tag @e[tag=summon] remove summon
kill @e[tag=mmark__,type=marker]
