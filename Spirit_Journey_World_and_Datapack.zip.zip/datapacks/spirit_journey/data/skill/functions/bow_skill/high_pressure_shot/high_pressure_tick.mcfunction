# ==========================================
# 高压弹 - 子弹移动与碰撞检测
# 每tick生成高速锐利粒子轨迹
# 检测是否命中敌人
# ==========================================

# 高速穿透粒子轨迹（锐利、快速、精准）
particle crit ~ ~ ~ 0.05 0.05 0.05 0.1 3 force
particle end_rod ~ ~ ~ 0.02 0.02 0.02 0.01 2 force
particle electric_spark ~ ~ ~ 0.03 0.03 0.03 0 1 force
particle white_smoke ~ ~ ~ 0.02 0.02 0.02 0 1 force

# 子弹寿命递减
scoreboard players remove @s temp 1

# 超时自动清除
execute if score @s temp matches ..0 run kill @s

# 检测是否命中敌人（精准范围2.5格）
execute if entity @e[tag=enemy,distance=..2.5] run function skill:bow_skill/high_pressure_shot/high_pressure_explosion
