# ==========================================
# 穿甲雷 - 召唤地雷（MVP版本）
# 在玩家脚下召唤marker地雷
# 部署阶段：8秒泥土粒子
# 完成后：转换为TNT display，等待触发
# ==========================================

# 在玩家脚下召唤部署中的地雷marker
summon marker ~ ~ ~ {Tags:["ap_mine","mine_deploying"]}

# 设置部署倒计时（8秒 = 160 tick）
scoreboard players set @e[tag=ap_mine,tag=mine_deploying,limit=1,sort=nearest] countDown 160

# 移除临时标签
tag @e[tag=mine_deploying] remove mine_deploying

# 提示音效
playsound block.metal.place ambient @a ~ ~ ~ 1 0.8 0

# 调试信息
tellraw @a [{"text":"[穿甲雷] ","color":"gold"},{"text":"已召唤地雷，部署中...","color":"white"}]
