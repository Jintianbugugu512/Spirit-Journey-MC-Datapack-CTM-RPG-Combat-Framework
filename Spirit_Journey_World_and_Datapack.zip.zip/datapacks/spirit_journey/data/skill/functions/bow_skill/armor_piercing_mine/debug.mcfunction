# ==========================================
# 穿甲雷 - 调试命令
# 检查地雷状态
# ==========================================

# 显示所有地雷marker
execute as @e[tag=ap_mine] run tellraw @a [{"text":"[调试] 找到地雷marker，countDown=","color":"gold"},{"score":{"name":"@s","objective":"countDown"},"color":"yellow"}]

# 显示所有TNT
execute as @e[tag=ap_mine_tnt] run tellraw @a [{"text":"[调试] 找到TNT display","color":"gold"}]

# 如果没有找到任何实体
execute unless entity @e[tag=ap_mine] unless entity @e[tag=ap_mine_tnt] run tellraw @a [{"text":"[调试] 没有找到任何穿甲雷实体","color":"red"}]
