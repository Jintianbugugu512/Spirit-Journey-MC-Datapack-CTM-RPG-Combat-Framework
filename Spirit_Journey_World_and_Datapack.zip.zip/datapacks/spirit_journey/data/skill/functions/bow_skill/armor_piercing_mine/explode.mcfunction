# ==========================================
# 穿甲雷 - 爆炸效果
# 显示爆破粒子，播放音效，清除TNT
# ==========================================

# 爆炸粒子效果
particle explosion ~ ~0.5 ~ 0.5 0.5 0.5 0.1 10 force
particle lava ~ ~0.5 ~ 0.8 0.8 0.8 0.1 15 force
particle flame ~ ~0.5 ~ 0.8 0.8 0.8 0.15 30 force

# 爆炸音效
playsound entity.generic.explode ambient @a[distance=..8] ~ ~ ~ 1.5 1 0
playsound entity.lightning_bolt.thunder ambient @a[distance=..8] ~ ~ ~ 0.8 1.2 0

# 对范围内敌人施加减防效果（15秒 = 300 tick）
execute as @e[tag=enemy,distance=..3] run scoreboard players set @s defense_reduce_duration 300

# 对范围内敌人施加眩晕效果（0.5秒 = 20 tick）
execute as @e[tag=enemy,distance=..3] run scoreboard players set @s stun 40

# 对范围内敌人造成20点真实伤害
execute as @e[tag=enemy,distance=..3] run damage @s 20

# 删除TNT display
kill @s
