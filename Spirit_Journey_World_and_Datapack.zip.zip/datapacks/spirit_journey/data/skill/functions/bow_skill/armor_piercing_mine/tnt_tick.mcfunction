# ==========================================
# 穿甲雷 - TNT每tick逻辑
# 检测附近敌人，触发爆炸
# ==========================================

# 检测2格范围内是否有敌人
execute if entity @e[tag=enemy,distance=..1.2] run function skill:bow_skill/armor_piercing_mine/explode
