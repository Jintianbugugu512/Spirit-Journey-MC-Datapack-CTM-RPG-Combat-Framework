# ==========================================
# 穿甲雷 - 地雷每tick逻辑
# 部署阶段：显示泥土粒子，倒计时
# 完成后：转换为TNT display
# ==========================================

# 部署阶段粒子效果（countDown > 1）
execute if score @s countDown matches 2.. run particle block minecraft:dirt ~ ~0.2 ~ 0.1 0.3 0.1 0 3 force


# 部署完成（countDown = 1，在被kill_manager清除前转换）
execute if score @s countDown matches 1 run function skill:bow_skill/armor_piercing_mine/deploy_complete
