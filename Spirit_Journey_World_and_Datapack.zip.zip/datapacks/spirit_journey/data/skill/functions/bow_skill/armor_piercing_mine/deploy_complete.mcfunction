# ==========================================
# 穿甲雷 - 部署完成
# marker死亡，召唤TNT display
# ==========================================

# 召唤TNT block_display
summon block_display ~ ~ ~ {Tags:["ap_mine_tnt"],transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,-0.5f,0f],scale:[0.6f,0.6f,0.6f]},block_state:{Name:"minecraft:tnt"}}

# 完成音效
playsound block.anvil.land ambient @a ~ ~ ~ 0.8 1.5 0

# 删除部署marker
kill @s
