# ==========================================
# 点火 - 弩技能
# 向前方射出火珠，碰撞后爆炸
# 5格范围内造成150%物理伤害和10s燃烧，最多5人
# 命中苦力怕立即引爆
# ==========================================

# MP不足则返回
$execute as @a[tag=$(player)] at @s if score @s MP matches ..19 run title @s actionbar "『MP不足,使用§l点火§f需要消耗§l20MP§f.』"
$execute as @a[tag=$(player)] at @s if score @s MP matches ..19 run playsound block.bone_block.place ambient @s ~ ~ ~ 1 0.8 0
$execute as @a[tag=$(player)] at @s if score @s MP matches ..19 run return 2

# CD没有归0则返回
$execute as @a[tag=$(player)] at @s if score @s ignite_CD matches 1.. run scoreboard players operation #CD temp = @s ignite_CD
$execute as @a[tag=$(player)] at @s if score @s ignite_CD matches 1.. run scoreboard players set #CD temp1 20
$execute as @a[tag=$(player)] at @s if score @s ignite_CD matches 1.. run scoreboard players operation #CD temp /= #CD temp1
$execute as @a[tag=$(player)] at @s if score @s ignite_CD matches 1.. run scoreboard players add #CD temp 1
$execute as @a[tag=$(player)] at @s if score @s ignite_CD matches 1.. run title @s actionbar [{"text":"§l『点火』§f技能CD还剩"},{"score": {"name": "#CD","objective": "temp"},"bold": true},{"text":"s","bold": true}]
$execute as @a[tag=$(player)] at @s if score @s ignite_CD matches 1.. run playsound block.bone_block.break ambient @s ~ ~ ~ 1.0 0.7 0
$execute as @a[tag=$(player)] at @s if score @s ignite_CD matches 1.. run return 3

# 设置技能CD，减去MP
$execute as @a[tag=$(player)] run scoreboard players set @s ignite_CD 200
$execute as @a[tag=$(player)] run scoreboard players remove @s MP 20

# 音效
$execute as @a[tag=$(player)] at @s run playsound entity.blaze.shoot ambient @a ~ ~ ~ 1 1.2 0
$execute as @a[tag=$(player)] at @s run playsound entity.ghast.shoot ambient @a ~ ~ ~ 0.5 1.5 0

# 召唤光灵箭（火珠）
$execute as @a[tag=$(player)] at @s anchored eyes run summon spectral_arrow ^ ^ ^1 {Tags:["summon","bullet_from_player","ignite_bullet"],NoGravity:1b,Glowing:1b,PortalCooldown:100,PierceLevel:10,damage:0,crit:false,Color:-1}

# 添加玩家ID标签用于溯源
$tag @e[tag=summon] add ignite_bullet_$(player)

# 计算飞行方向（使用临时marker）
execute positioned 0.0 0.0 0.0 run summon marker ^ ^ ^1.2 {Tags:["mmark__"]}
execute as @e[tag=summon] run data modify entity @s Motion set from entity @e[limit=1,tag=mmark__] Pos

# 设置子弹寿命
scoreboard players set @e[tag=summon] temp 100

# 清理临时实体和标签
tag @e[tag=summon] remove summon
kill @e[tag=mmark__,type=marker]
