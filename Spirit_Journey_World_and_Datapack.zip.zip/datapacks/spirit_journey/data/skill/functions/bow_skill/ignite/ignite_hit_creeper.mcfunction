# ==========================================
# 点火 - 苦力怕引爆
# 10tick后引爆附近的苦力怕
# ==========================================

# 引爆苦力怕（10tick后爆炸）
execute as @e[type=creeper,distance=..1.5] run data modify entity @s Fuse set value 10
execute as @e[type=creeper,distance=..1.5] run data modify entity @s ignited set value 1b

# 视觉效果
particle explosion ~ ~ ~ 0.5 0.5 0.5 0.1 5
particle flame ~ ~ ~ 1 1 1 0.1 30
particle lava ~ ~ ~ 0.5 0.5 0.5 0 10

# 音效
playsound entity.generic.explode player @a ~ ~ ~ 1 0.8
playsound entity.creeper.primed player @a ~ ~ ~ 1 2

# 清除子弹
kill @s
