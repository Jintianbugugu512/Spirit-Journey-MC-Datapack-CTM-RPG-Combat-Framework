# ==========================================
# 点火 - 玩家伤害应用
# 设置150%伤害倍率并调用伤害API
# ==========================================

# 设置伤害倍率为150%
$scoreboard players set @a[tag=player_$(id)] temp 150

# 调用物理伤害API
$function combat:damage_type/physic_damage with storage damage:player_$(id)
