# ==========================================
# 点火 - 子弹移动与碰撞检测
# 每tick生成火焰粒子轨迹
# 检测是否命中敌人或苦力怕
# ==========================================

# 火焰粒子轨迹
particle flame ~ ~ ~ 0.1 0.1 0.1 0.02 5 force
particle lava ~ ~ ~ 0.1 0.1 0.1 0 1 force
particle smoke ~ ~ ~ 0.1 0.1 0.1 0.01 3 force

# 子弹寿命递减
scoreboard players remove @s temp 1

# 超时自动清除
execute if score @s temp matches ..0 run kill @s

# 检测是否命中苦力怕（优先级最高）
execute if entity @e[type=creeper,distance=..1.5] run function skill:bow_skill/ignite/ignite_hit_creeper

# 检测是否命中敌人
execute if entity @e[tag=enemy,distance=..1.5] run function skill:bow_skill/ignite/ignite_explosion
