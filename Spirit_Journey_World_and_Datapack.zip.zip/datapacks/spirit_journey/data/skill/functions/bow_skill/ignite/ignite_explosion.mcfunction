# ==========================================
# 点火 - 爆炸效果
# 5格范围内给敌人添加20s燃烧
# 最多命中5个敌人
# ==========================================

# 标记范围内最多5个敌人
tag @e[tag=enemy,distance=..5,limit=5,sort=nearest] add ignite_target

# 给目标添加燃烧效果（20秒 = 400tick）
execute as @e[tag=ignite_target] run data modify entity @s Fire set value 400s

# 爆炸视觉效果
particle explosion ~ ~ ~ 1 1 1 0.1 10
particle flame ~ ~ ~ 2 2 2 0.1 100
particle lava ~ ~ ~ 1.5 1.5 1.5 0 30
particle large_smoke ~ ~ ~ 1.5 1.5 1.5 0.05 50

# 音效
playsound entity.generic.explode player @a ~ ~ ~ 1.5 1
playsound entity.blaze.death player @a ~ ~ ~ 1 0.8
playsound block.fire.ambient player @a ~ ~ ~ 1 1

# 清除目标标签
tag @e[tag=ignite_target] remove ignite_target

# 清除子弹
kill @s
