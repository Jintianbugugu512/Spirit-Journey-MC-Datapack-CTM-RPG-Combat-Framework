# ==========================================
# 加农炮 - 弩技能
# 向前方发射超慢速炮弹，碰撞后产生巨大爆炸
# 10格范围内造成1500%物理伤害，最多6人
# 对命中敌人增加15秒燃烧时间
# ⚠️ 危险：会对范围内玩家造成100点友军伤害
# ==========================================

# MP不足则返回
$execute as @a[tag=$(player)] at @s if score @s MP matches ..49 run title @s actionbar "『MP不足,使用§l加农炮§f需要消耗§l50MP§f.』"
$execute as @a[tag=$(player)] at @s if score @s MP matches ..49 run playsound block.bone_block.place ambient @s ~ ~ ~ 1 0.8 0
$execute as @a[tag=$(player)] at @s if score @s MP matches ..49 run return 2

# CD没有归0则返回
$execute as @a[tag=$(player)] at @s if score @s cannon_CD matches 1.. run scoreboard players operation #CD temp = @s cannon_CD
$execute as @a[tag=$(player)] at @s if score @s cannon_CD matches 1.. run scoreboard players set #CD temp1 20
$execute as @a[tag=$(player)] at @s if score @s cannon_CD matches 1.. run scoreboard players operation #CD temp /= #CD temp1
$execute as @a[tag=$(player)] at @s if score @s cannon_CD matches 1.. run scoreboard players add #CD temp 1
$execute as @a[tag=$(player)] at @s if score @s cannon_CD matches 1.. run title @s actionbar [{"text":"§l『加农炮』§f技能CD还剩"},{"score": {"name": "#CD","objective": "temp"},"bold": true},{"text":"s","bold": true}]
$execute as @a[tag=$(player)] at @s if score @s cannon_CD matches 1.. run playsound block.bone_block.break ambient @s ~ ~ ~ 1.0 0.7 0
$execute as @a[tag=$(player)] at @s if score @s cannon_CD matches 1.. run return 3

# 设置技能CD，减去MP
$execute as @a[tag=$(player)] run scoreboard players set @s cannon_CD 600
$execute as @a[tag=$(player)] run scoreboard players remove @s MP 50

# 音效
$execute as @a[tag=$(player)] at @s run playsound entity.wither.shoot ambient @a ~ ~ ~ 2 0.5 0
$execute as @a[tag=$(player)] at @s run playsound entity.generic.explode ambient @a ~ ~ ~ 1 1.5 0

# 召唤光灵箭（炮弹）
$execute as @a[tag=$(player)] at @s anchored eyes run summon spectral_arrow ^ ^ ^1 {Tags:["summon","bullet_from_player","cannon_bullet"],NoGravity:1b,Glowing:1b,PortalCooldown:100,PierceLevel:10,damage:0,crit:false,Color:16744448}

# 添加玩家ID标签用于溯源
$tag @e[tag=summon] add cannon_bullet_$(player)

# 计算飞行方向（使用临时marker，速度非常慢0.4）
execute positioned 0.0 0.0 0.0 run summon marker ^ ^ ^0.4 {Tags:["mmark__"]}
execute as @e[tag=summon] run data modify entity @s Motion set from entity @e[limit=1,tag=mmark__] Pos

# 设置子弹寿命（200 tick）
scoreboard players set @e[tag=summon] temp 200

# 清理临时实体和标签
tag @e[tag=summon] remove summon
kill @e[tag=mmark__,type=marker]
