# ==========================================
# 加农炮 - 爆炸效果
# 10格超大范围内造成伤害和燃烧
# 最多命中6个敌人
# ⚠️ 会对范围内玩家造成100点友军伤害
# ==========================================

# 标记范围内最多6个敌人
tag @e[tag=enemy,distance=..10,limit=6,sort=nearest] add cannon_target

# 对目标造成伤害 - 根据子弹的玩家ID标签
execute if entity @e[tag=cannon_bullet_player_1,limit=1] as @e[tag=cannon_target] run function combat:deal/damage_deal {rate:"1500",type:"physic",player:"player_1",interval:"cactus"}
execute if entity @e[tag=cannon_bullet_player_2,limit=1] as @e[tag=cannon_target] run function combat:deal/damage_deal {rate:"1500",type:"physic",player:"player_2",interval:"cactus"}
execute if entity @e[tag=cannon_bullet_player_3,limit=1] as @e[tag=cannon_target] run function combat:deal/damage_deal {rate:"1500",type:"physic",player:"player_3",interval:"cactus"}

# 给目标添加燃烧效果（增加15秒）
execute as @e[tag=cannon_target] run function skill:bow_skill/cannon/cannon_burn

# 清除目标标签
tag @e[tag=cannon_target] remove cannon_target

# ⚠️ 友军伤害 - 对范围内所有玩家造成100点伤害
execute as @a[distance=..10] run damage @s 100 minecraft:explosion

# 超大爆炸视觉效果
particle explosion_emitter ~ ~ ~ 0 0 0 0 3
particle explosion ~ ~ ~ 3 3 3 0.5 30
particle flame ~ ~ ~ 5 5 5 0.3 500
particle lava ~ ~ ~ 4 4 4 0 200
particle large_smoke ~ ~ ~ 5 5 5 0.2 300
particle campfire_cosy_smoke ~ ~ ~ 3 3 3 0.1 100

# 音效
playsound entity.generic.explode player @a ~ ~ ~ 3.0 0.5
playsound entity.lightning_bolt.thunder player @a ~ ~ ~ 2.0 0.8
playsound entity.wither.break_block player @a ~ ~ ~ 2.0 0.5

# 清除子弹
kill @s
