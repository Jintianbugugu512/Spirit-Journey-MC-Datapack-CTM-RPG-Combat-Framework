# ==========================================
# 加农炮 - 燃烧时间增加
# 增加15秒（300 tick）燃烧时间
# ==========================================

# 获取当前燃烧时间
execute store result score #cannon fire run scoreboard players get @s fire

# 如果没有燃烧，添加15秒燃烧
execute if score @s fire matches ..0 run scoreboard players set #cannon temp 300

# 如果已经燃烧，额外增加15秒
execute if score @s fire matches 1.. run scoreboard players set #cannon temp 300

# 增加燃烧时间
scoreboard players operation #cannon fire += #cannon temp

# 应用到实体
execute store result entity @s Fire short 1 run scoreboard players get #cannon fire
