# ==========================================
# 加农炮 - 子弹移动与碰撞检测
# 每tick生成炮弹轨迹粒子
# 检测是否命中敌人
# ==========================================

# 炮弹轨迹粒子（火焰和烟雾）
particle flame ~ ~ ~ 0.3 0.3 0.3 0.05 10 force
particle large_smoke ~ ~ ~ 0.2 0.2 0.2 0.02 5 force
particle lava ~ ~ ~ 0.1 0.1 0.1 0 2 force
particle campfire_cosy_smoke ~ ~ ~ 0.3 0.3 0.3 0.01 3 force

# 子弹寿命递减
scoreboard players remove @s temp 1

# 超时自动清除
execute if score @s temp matches ..0 run kill @s

# 检测是否命中敌人
execute if entity @e[tag=enemy,distance=..2] run function skill:bow_skill/cannon/cannon_explosion
