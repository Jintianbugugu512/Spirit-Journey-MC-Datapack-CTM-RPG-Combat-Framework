#$(player).x2为上一刻的坐标,$(player).x1为当前坐标.
$execute as @s store result score @s $(player).x1 run data get entity @s Pos[0] 1
$execute as @s store result score @s $(player).y1 run data get entity @s Pos[1] 1
$execute as @s store result score @s $(player).z1 run data get entity @s Pos[2] 1

$scoreboard players operation @s $(player).x2 -= @s $(player).x1
$scoreboard players operation @s $(player).y2 -= @s $(player).y1
$scoreboard players operation @s $(player).z2 -= @s $(player).z1


$execute if score @s $(player).x2 matches 3.. run function anti_cheat:other_function/anti_tp_output with storage pos_$(player):pos
$execute if score @s $(player).y2 matches 3.. run function anti_cheat:other_function/anti_tp_output with storage pos_$(player):pos
$execute if score @s $(player).z2 matches 3.. run function anti_cheat:other_function/anti_tp_output with storage pos_$(player):pos
$execute if score @s $(player).x2 matches ..-3 run function anti_cheat:other_function/anti_tp_output with storage pos_$(player):pos
$execute if score @s $(player).y2 matches ..-3 run function anti_cheat:other_function/anti_tp_output with storage pos_$(player):pos
$execute if score @s $(player).z2 matches ..-3 run function anti_cheat:other_function/anti_tp_output with storage pos_$(player):pos

# $execute if score @s $(player).y2 matches 3.. run say 1
# $execute if score @s $(player).y2 matches ..-3 run say 2





$scoreboard players operation @s $(player).x2 = @s $(player).x1
$scoreboard players operation @s $(player).y2 = @s $(player).y1
$scoreboard players operation @s $(player).z2 = @s $(player).z1

# execute as @s[scores={interval_pos_record=9}] run tp @e[tag=box_1] ~ ~-10 ~
$execute as @s[scores={interval_pos_record=9}] run execute store result score @s $(player).x3 run data get entity @s Pos[0] 1
$execute as @s[scores={interval_pos_record=9}] run execute store result score @s $(player).y3 run data get entity @s Pos[1] 1
$execute as @s[scores={interval_pos_record=9}] run execute store result score @s $(player).z3 run data get entity @s Pos[2] 1

$execute as @s[scores={interval_pos_record=9}] run scoreboard players add @s $(player).y3 1
$execute as @s[scores={interval_pos_record=9}] run execute store result storage pos_$(player):pos x int 1 run scoreboard players get @s $(player).x3
$execute as @s[scores={interval_pos_record=9}] run execute store result storage pos_$(player):pos y int 1 run scoreboard players get @s $(player).y3
$execute as @s[scores={interval_pos_record=9}] run execute store result storage pos_$(player):pos z int 1 run scoreboard players get @s $(player).z3

#已知bug
#1.可以在半径3





