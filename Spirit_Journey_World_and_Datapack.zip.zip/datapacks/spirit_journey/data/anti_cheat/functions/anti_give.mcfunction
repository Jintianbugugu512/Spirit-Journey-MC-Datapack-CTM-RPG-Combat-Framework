
#给予的所有物品都必须give @a emerald{from_map:1b} 1 否则会被系统判断为作弊清除!
execute as @a[nbt=!{SelectedItem:{tag:{from_map:1b}}},tag=!Mana] run item replace entity @s weapon.mainhand with air
execute as @a[nbt=!{Inventory:[{Slot:-106b,tag:{from_map:1b}}]},tag=!Mana] run item replace entity @s weapon.offhand with air
execute as @a[nbt=!{Inventory:[{Slot:103b,tag:{from_map:1b}}]},tag=!Mana] run item replace entity @s armor.head with air
execute as @a[nbt=!{Inventory:[{Slot:102b,tag:{from_map:1b}}]},tag=!Mana] run item replace entity @s armor.chest with air
execute as @a[nbt=!{Inventory:[{Slot:101b,tag:{from_map:1b}}]},tag=!Mana] run item replace entity @s armor.legs with air
execute as @a[nbt=!{Inventory:[{Slot:100b,tag:{from_map:1b}}]},tag=!Mana] run item replace entity @s armor.feet with air

execute as @e[type=item] if entity @s[nbt=!{Item:{tag:{from_map:1b}}}] run data modify entity @s Item set value {tag:{from_map:1b},id:"emerald",Count:1b}