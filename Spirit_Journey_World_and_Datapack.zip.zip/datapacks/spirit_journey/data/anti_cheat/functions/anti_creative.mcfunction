tellraw @a[tag=!Mana,gamemode=!adventure] "请不要作弊呦,管理员模式需要添加Mana这个tag,之后才可以开启创造模式"
gamemode adventure @a[tag=!Mana,gamemode=!adventure]