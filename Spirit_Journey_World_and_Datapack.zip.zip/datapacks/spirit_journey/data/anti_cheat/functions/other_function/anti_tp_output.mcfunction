$tp @s $(x) $(y) $(z)
tellraw @s[scores={interval_output=0}] "『多人游戏需要玩家间互相传送请使用系统手册.』"
tellraw @s[scores={interval_output=0}] "『请不要作弊呦』q(≧▽≦q)"
scoreboard players set @s interval_output 20

