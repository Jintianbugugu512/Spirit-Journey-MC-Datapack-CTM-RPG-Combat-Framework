#清除玩家身上的buff
effect clear @a[scores={can_be_effect=..0}] instant_health
effect clear @a strength
effect clear @a[scores={can_be_effect=..0}] absorption
effect clear @a fire_resistance
effect clear @a health_boost
effect clear @a levitation
effect clear @a[scores={can_be_effect=..0}] regeneration
effect clear @a saturation
effect clear @a resistance
#先清除再给予,防止高等级跳跃buff,且保证地图给予的buff生效
effect clear @a[scores={can_be_effect=..0}] jump_boost
effect give @a minecraft:jump_boost infinite 0 true

#清除怪物身上的buff
effect clear @e[tag=enemy] instant_health
effect clear @e[tag=enemy] instant_damage
#effect clear @e[tag=enemy] levitation
#effect clear @e[tag=enemy,scores={can_be_effect=..1}] weakness
#effect clear @e[tag=enemy,scores={can_be_effect=..1}] slowness















