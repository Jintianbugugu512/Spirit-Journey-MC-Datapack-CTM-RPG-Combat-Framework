#execute if score @s blue_Flower <= @s max_Flower if entity @a[tag=right_click,scores={blue_Flower=1..}] run
scoreboard players add @s MP 50
playsound block.wet_grass.place block @s
clear @s pitcher_plant 1

execute anchored eyes run summon text_display ^-0.5 ^-0.2 ^1 {text:'"§9§l+50"',Tags:["MP_shower","MP_shower_"],billboard:center,background:1942251,see_through:true}
scoreboard players set @e[tag=MP_shower] countDown 15
tag @e[tag=MP_shower] remove MP_shower
