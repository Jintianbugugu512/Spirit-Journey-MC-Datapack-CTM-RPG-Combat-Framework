#摘到瓶子草的玩家执行
scoreboard players add @s MP 50
playsound block.wet_grass.place block @s
setblock ~ ~ ~ air

execute anchored eyes run summon text_display ^-0.5 ^-0.2 ^1 {text:'"§9§l+50"',Tags:["MP_shower","MP_shower_"],billboard:center,background:1942251,see_through:true2}
scoreboard players set @e[tag=MP_shower] countDown 15
tag @e[tag=MP_shower] remove MP_shower