#execute if score @s red_Flower <= @s max_Flower if entity @a[tag=right_click,scores={red_Flower=1..}] run
scoreboard players set @s can_be_effect 2
effect give @s[tag=!enhance_prop] instant_health 1 1
effect give @s[tag=enhance_prop] instant_health 1 2
playsound block.wet_grass.place block @s
clear @s torchflower 1