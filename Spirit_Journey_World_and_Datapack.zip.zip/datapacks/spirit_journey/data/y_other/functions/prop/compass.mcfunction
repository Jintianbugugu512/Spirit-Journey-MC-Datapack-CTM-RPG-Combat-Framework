#execute if entity @a[nbt={SelectedItem:{id:"minecraft:compass",Count:1b}}] run execute as @s at @s run
execute unless entity @e[tag=item_on_world,distance=..30] run title @s actionbar "§3『30格内未发现存在任何物品』"
execute if entity @e[tag=item_on_world,distance=..30] run title @s actionbar "§3『罗盘探测到了§l30§3格内存在物品,跟随指针寻找吧!』"
execute if entity @e[tag=item_on_world,distance=..20] run title @s actionbar "§9『罗盘探测到了§l20§9格内存在物品,跟随指针寻找吧!』"
execute if entity @e[tag=item_on_world,distance=..10] run title @s actionbar "§4『罗盘探测到了§l10§4格内存在物品,跟随指针寻找吧!』"

execute store result score @s compass_x run data get entity @e[tag=item_on_world,limit=1,sort=nearest] Pos[0]
execute store result score @s compass_z run data get entity @e[tag=item_on_world,limit=1,sort=nearest] Pos[2]
execute store result storage damage:player_1 compass_x int 1 run scoreboard players get @s compass_x
execute store result storage damage:player_1 compass_z int 1 run scoreboard players get @s compass_z

function y_other:prop/compass_ with storage damage:player_1









