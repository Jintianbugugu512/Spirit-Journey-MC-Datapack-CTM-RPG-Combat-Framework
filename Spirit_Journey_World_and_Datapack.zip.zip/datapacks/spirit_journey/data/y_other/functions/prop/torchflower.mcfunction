#摘到火把花的玩家执行
scoreboard players set @s can_be_effect 2
effect give @s[tag=!enhance_prop] instant_health 1 1
effect give @s[tag=enhance_prop] instant_health 1 2
playsound block.wet_grass.place block @s
setblock ~ ~ ~ air