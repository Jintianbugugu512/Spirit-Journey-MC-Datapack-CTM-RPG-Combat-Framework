#在玩家到齐后会执行该函数以开始游戏.
scoreboard players set @a max_Flower 3
scoreboard players set @a max_soul_disc 1
scoreboard players set @a max_MP 100
scoreboard players set @a max_HP 20
scoreboard players set @a strength 50
scoreboard players set @a armor 0

scoreboard players set @a sword_light_count 0
scoreboard players set @a max_soul_disc 5

data merge storage damage:player_1 {player:"player_1"}
data merge storage damage:player_1 {damage:1}
data merge storage damage:player_1 {rate:1}
data merge storage damage:player_1 {sword_skill_y:283}
data merge storage damage:player_1 {crossbow_skill_y:284}
data merge storage damage:player_1 {stick_skill_y:285}


data merge storage damage:player_2 {player:"player_2"}
data merge storage damage:player_3 {player:"player_3"}

advancement grant @a from y_other:explore/start


scoreboard objectives add MP dummy "『MP』"
scoreboard objectives setdisplay sidebar MP
scoreboard players set @a MP 0

scoreboard objectives add HP health "『HP』"
scoreboard objectives setdisplay below_name HP





