say §d『生灵之旅』数据包已经准备就绪ヾ(≧▽≦*)o
gamerule doMobSpawning false
gamerule doFireTick false
gamerule sendCommandFeedback true
gamerule mobGriefing false
gamerule playersSleepingPercentage 0
gamerule doEntityDrops false
gamerule doImmediateRespawn false
gamerule randomTickSpeed 0
#defaultgamemode adventure
