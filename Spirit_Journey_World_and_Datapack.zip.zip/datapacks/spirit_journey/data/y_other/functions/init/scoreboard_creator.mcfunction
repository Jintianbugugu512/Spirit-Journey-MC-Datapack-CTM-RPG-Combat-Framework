#计分板创建
# 玩家ID系统
scoreboard objectives add player_id dummy

#创建玩家1的三个坐标储存
scoreboard objectives add player_1.x1 dummy
scoreboard objectives add player_1.y1 dummy
scoreboard objectives add player_1.z1 dummy

scoreboard objectives add player_1.x2 dummy
scoreboard objectives add player_1.y2 dummy
scoreboard objectives add player_1.z2 dummy

scoreboard objectives add player_1.x3 dummy
scoreboard objectives add player_1.y3 dummy
scoreboard objectives add player_1.z3 dummy
#---
scoreboard objectives add player_2.x1 dummy
scoreboard objectives add player_2.y1 dummy
scoreboard objectives add player_2.z1 dummy

scoreboard objectives add player_2.x2 dummy
scoreboard objectives add player_2.y2 dummy
scoreboard objectives add player_2.z2 dummy

scoreboard objectives add player_2.x3 dummy
scoreboard objectives add player_2.y3 dummy
scoreboard objectives add player_2.z3 dummy
#---
scoreboard objectives add player_3.x1 dummy
scoreboard objectives add player_3.y1 dummy
scoreboard objectives add player_3.z1 dummy

scoreboard objectives add player_3.x2 dummy
scoreboard objectives add player_3.y2 dummy
scoreboard objectives add player_3.z2 dummy

scoreboard objectives add player_3.x3 dummy
scoreboard objectives add player_3.y3 dummy
scoreboard objectives add player_3.z3 dummy




#间隔计分板
scoreboard objectives add interval_pos_record dummy
scoreboard players set @a interval_pos_record 0
scoreboard objectives add interval_output dummy
scoreboard players set @a interval_output 0
scoreboard objectives add interval_can_tp dummy
scoreboard players set @a interval_can_tp 0
scoreboard objectives add interval_pick_up dummy
scoreboard players set @a interval_pick_up 0
scoreboard objectives add interval_stick dummy
scoreboard players set @a interval_stick 0
scoreboard objectives add countDown dummy


#暂存计分板
scoreboard objectives add temp dummy
scoreboard objectives add temp1 dummy
scoreboard objectives add temp2 dummy
scoreboard objectives add temp3 dummy

scoreboard objectives add maxhealth_temp dummy
scoreboard objectives add hp_temp dummy



#怪物属性
#生命值
scoreboard objectives add current_health dummy
scoreboard objectives add max_health dummy
scoreboard objectives add last_health dummy
#击退抗性
scoreboard objectives add knock_resistance dummy
#防御力
scoreboard objectives add physical_armor dummy
#法抗
scoreboard objectives add magic_resist dummy
#防御类型标识 (1=高物防, 2=均衡, 3=高魔抗)
scoreboard objectives add armor_type dummy
#闪避
#scoreboard objectives add dodge dummy

#火焰时间
scoreboard objectives add fire dummy
#眩晕
scoreboard objectives add stun dummy
#受击冷却
scoreboard objectives add hit_cooldown dummy

#伤害显示的相关变量
scoreboard objectives add h1 dummy
scoreboard objectives add h2 dummy
scoreboard objectives add h3 dummy
scoreboard objectives add h4 dummy
scoreboard objectives add dis dummy
scoreboard objectives add damage_will_deal dummy


#答题系统相关变量
scoreboard objectives add quiz_answer dummy
scoreboard objectives add quiz_answered dummy
scoreboard objectives add knowledge_power dummy

#刷怪笼相关变量
scoreboard objectives add player_Numbers dummy
scoreboard objectives add spawn_Interval dummy
scoreboard objectives add spawn_Interval_Max dummy
scoreboard objectives add spawn_Random_Number dummy
scoreboard objectives add spawn_offset_x dummy
scoreboard objectives add spawn_offset_y dummy
scoreboard objectives add spawn_offset_z dummy
scoreboard objectives add spawn_progress dummy
scoreboard objectives add spawn_retry_count dummy


#玩家属性
scoreboard objectives add strength dummy
scoreboard objectives add strength_ dummy
scoreboard objectives add armor dummy
scoreboard objectives add armor_ dummy
scoreboard objectives add defense_reduce_duration dummy
scoreboard objectives add defense_reduced_value dummy
scoreboard objectives add attack_damage dummy
scoreboard objectives add soul_disc dummy
scoreboard objectives add charge dummy

# 攻击预警系统记分板
scoreboard objectives add radius dummy
scoreboard objectives add damage dummy

# 动量子弹速度记分板
scoreboard objectives add bullet_vx dummy
scoreboard objectives add bullet_vy dummy
scoreboard objectives add bullet_vz dummy



scoreboard objectives add detect_left1 dummy
scoreboard objectives add detect_right1 dummy
scoreboard objectives add detect_left2 dummy
scoreboard objectives add detect_right2 dummy

scoreboard objectives add put_shift minecraft.custom:minecraft.sneak_time
scoreboard objectives add put_shift minecraft.custom:minecraft.jump
scoreboard objectives add kill_zombie minecraft.killed:zombie
scoreboard objectives add damage_taken minecraft.custom:minecraft.damage_taken
scoreboard objectives add last_damage_taken dummy

scoreboard objectives add MP dummy
scoreboard objectives add MP_last dummy
scoreboard objectives add max_MP dummy
scoreboard objectives add max_HP dummy
scoreboard objectives add max_HP_ dummy
scoreboard objectives add max_Flower dummy
scoreboard objectives add max_soul_disc dummy
scoreboard objectives add red_Flower dummy
scoreboard objectives add blue_Flower dummy
scoreboard objectives add attack_count_triple_slash dummy


#使用物品类计分板
scoreboard objectives add use_IronSword used:iron_sword
scoreboard objectives add use_NetheriteSword used:netherite_sword
scoreboard objectives add use_Crossbow used:crossbow
scoreboard objectives add use_Stick used:carrot_on_a_stick
scoreboard objectives add use_Stick_ used:warped_fungus_on_a_stick

scoreboard objectives add put_shift minecraft.custom:minecraft.sneak_time
scoreboard objectives add jump minecraft.custom:minecraft.jump

# 武器连击系统
scoreboard objectives add rapier_combo dummy

# 凝杖蓄力系统
scoreboard objectives add charge_of_stick dummy

#技能CD
scoreboard objectives add triple_slash_CD dummy
scoreboard objectives add disarm_CD dummy
scoreboard objectives add bounty_blade_CD dummy
scoreboard objectives add snipe_CD dummy
scoreboard objectives add parry_CD dummy
scoreboard objectives add blood_CD dummy
scoreboard objectives add blood_buff dummy
scoreboard objectives add wn_buff dummy
scoreboard objectives add quickly_load dummy
scoreboard objectives add flame_slash_CD dummy
scoreboard objectives add flame_blast_CD dummy
scoreboard objectives add sword_light_count dummy
scoreboard objectives add sword_rally_CD dummy
scoreboard objectives add sword_rally_buff dummy
scoreboard objectives add airdash_CD dummy
scoreboard objectives add sacred_shield_CD dummy
scoreboard objectives add shockwave_CD dummy
scoreboard objectives add amethyst_highlight_CD dummy
scoreboard objectives add heavy_slash_CD dummy
scoreboard objectives add ignite_CD dummy
scoreboard objectives add whirlwind_CD dummy
scoreboard objectives add whirlwind_duration dummy
scoreboard objectives add whirlwind_interval dummy
scoreboard objectives add nectar_CD dummy
scoreboard objectives add flame_spray_CD dummy
scoreboard objectives add flame_spray_duration dummy
scoreboard objectives add flame_spray_interval dummy
scoreboard objectives add stasis_shot_CD dummy
scoreboard objectives add weakness_shot_CD dummy
scoreboard objectives add cannon_CD dummy
scoreboard objectives add high_pressure_shot_CD dummy
scoreboard objectives add shadow_field_CD dummy
scoreboard objectives add duel_domain_CD dummy
scoreboard objectives add duel_domain_buff dummy
scoreboard objectives add storm_dance_CD dummy
scoreboard objectives add soul_blast_CD dummy
scoreboard objectives add wandering_lantern_CD dummy
scoreboard objectives add lhfs_timer dummy
scoreboard objectives add lhgy_timer dummy
scoreboard objectives add zdxh_cd dummy
scoreboard objectives add zdxh_last_kill dummy
scoreboard objectives add auto_recharge_timer dummy
scoreboard objectives add total_kill_count totalKillCount
scoreboard objectives add kill_zombie minecraft.killed:zombie
scoreboard objectives add kill_skeleton minecraft.killed:skeleton
scoreboard objectives add kill_creeper minecraft.killed:creeper
scoreboard objectives add kill_spider minecraft.killed:spider
scoreboard objectives add kill_enderman minecraft.killed:enderman











#其他
scoreboard objectives add can_be_effect dummy
scoreboard objectives add rotate dummy
scoreboard objectives add compass_x dummy
scoreboard objectives add compass_z dummy




scoreboard objectives add isloop dummy

# BOSS系统记分板
scoreboard objectives add phase dummy
scoreboard objectives add skill dummy
scoreboard objectives add timer dummy
scoreboard objectives add dash_timer dummy
scoreboard objectives add cleanup_timer dummy

# 棋盘阵列记分板
scoreboard objectives add col dummy
scoreboard objectives add row dummy

# 常量记分板（用于计算）
scoreboard objectives add const dummy
scoreboard players set #2 const 2
scoreboard players set #7 const 7
scoreboard players set #10 const 10
scoreboard players set #40 const 40
scoreboard players set #75 const 75

# 队伍系统 - 紫晶高亮用紫色发光
team add amethyst_glow "紫晶高亮"
team modify amethyst_glow color dark_purple
