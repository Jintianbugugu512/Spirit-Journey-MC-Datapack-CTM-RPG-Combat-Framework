#此函数为存储地图中所有物品的数据库
#数据库用法是,把get函数中需要获取的物品的give指令复制到get_temporary函数,在游戏中调用get_temporary来获取物品

give @s minecraft:iron_helmet{from_map:1b} 1

#6件武器
 give @p minecraft:iron_sword{from_map:1b,can_right_click:1b,Unbreakable:1b,display:{Name:"[\"§1§l『剑』\"]",Lore:["[\"§9近战武器,攻击造成§l自身攻击力*100%§9的物理伤害.\"]","[\"§9每次击中敌人回复§l4MP§9.\"]","[\"\"]","[\"§2物理伤害计算公式:\"]","[\"§c造成伤害=攻击伤害-防御力.\"]"]},HideFlags:63b,Enchantments:[{id:"minecraft:unbreaking",lvl:20s}],AttributeModifiers:[{AttributeName:"generic.attack_damage",Name:"noName",Amount:0d,Operation:0,UUID:[I;8614,4168,6668,9334],Slot:mainhand},{AttributeName:"generic.attack_speed",Name:"noName",Amount:0d,Operation:0,UUID:[I;4863,1569,2993,8155],Slot:mainhand}]} 1

 give @p minecraft:crossbow{hunting_crossbow:1b,from_map:1b,can_right_click:1b,Unbreakable:1b,display:{Name:"[\"§1§l『猎弩』\"]",Lore:["[\"§9远程武器,攻击造成§l自身攻击力*150%§9的物理伤害,破甲线较高.\"]","[\"§9(有§l20%§9的概率暴击,造成§l250%§9的物理伤害.)\"]","[\"§9每次射击命中敌人后回复§l8MP.\"]","[\"\"]"]},HideFlags:63b,Enchantments:[{id:"minecraft:unbreaking",lvl:20s},{id:"minecraft:quick_charge",lvl:0s}],AttributeModifiers:[{AttributeName:"generic.attack_damage",Name:"noName",Amount:0d,Operation:0,UUID:[I;8614,4168,6668,9334],Slot:mainhand},{AttributeName:"generic.attack_speed",Name:"noName",Amount:0d,Operation:0,UUID:[I;4863,1569,2993,8155],Slot:mainhand}]} 1

give @p minecraft:carrot_on_a_stick{from_map:1b,can_right_click:1b,Unbreakable:1b,display:{Name:"[\"§1§l『散杖』\"]",Lore:["[\"§9短射程武器,攻击造成§l自身攻击力*80%§9的AOE法术伤害,且附带穿透效果.\"]","[\"§9每命中一名敌人,回复2MP.每命中一名BOSS单位,回复4MP..\"]","[\"\"]"]},HideFlags:63b,Enchantments:[{id:"minecraft:unbreaking",lvl:20s},{id:"minecraft:quick_charge",lvl:1s}],AttributeModifiers:[{AttributeName:"generic.attack_damage",Name:"noName",Amount:0d,Operation:0,UUID:[I;8614,4168,6668,9334],Slot:mainhand},{AttributeName:"generic.attack_speed",Name:"noName",Amount:0d,Operation:0,UUID:[I;4863,1569,2993,8155],Slot:mainhand}]} 1

give @p minecraft:warped_fungus_on_a_stick{focusing_staff:1b,from_map:1b,can_right_click:1b,Unbreakable:1b,display:{Name:"[\"§1§l『凝杖』\"]",Lore:["[\"§9蓄力型远程武器,手持法杖时可在前方聚集能量球.\"]","[\"§9右键射出能量球,造成超远距离大额单体魔法伤害.\"]","[\"§9聚集时间越长,伤害倍率越高(§l50%～350%§9),飞行距离越远.\"]","[\"§9每命中一名敌人,回复4MP.每命中一名BOSS单位,回复8MP.\"]"]},HideFlags:63b,Enchantments:[{id:"minecraft:unbreaking",lvl:20s},{id:"minecraft:quick_charge",lvl:2s}],AttributeModifiers:[{AttributeName:"generic.attack_damage",Name:"noName",Amount:0d,Operation:0,UUID:[I;8614,4168,6668,9334],Slot:mainhand},{AttributeName:"generic.attack_speed",Name:"noName",Amount:0d,Operation:0,UUID:[I;4863,1569,2993,8155],Slot:mainhand}]} 1

give @p minecraft:compass{Count:1b,id:"minecraft:compass",from_map:1b,LodestoneDimension:"overworld",LodestonePos:{X:0,Y:0,Z:0},LodestoneTracked:0b,display:{Name:'["§6『探索者罗盘』"]',Lore:["[\"§2名字貌似来自某个神秘的游戏?.\"]","[\"§9功能:30格半径内存在隐藏物品时(如技能书,金萝卜等等...).\"]","[\"§9罗盘会提示玩家,并且指针会指向该隐藏物品.\"]"]}} 1

#给予连弩
give @p minecraft:crossbow{repeating_crossbow:1b,from_map:1b,can_right_click:1b,Unbreakable:1b,display:{Name:"[\"§1§l『连弩』\"]",Lore:["[\"§9装填速度极快的弩炮，缺点是比较费箭.\"]","[\"§9远距离射击，命中后造成范围爆炸（最大锁定3名敌人），随机造成§l30%～50%§9的物理伤害.\"]","[\"§9每次射击命中敌人后回复§l2MP.\"]","[\"\"]"]},HideFlags:63b,Enchantments:[{id:"minecraft:unbreaking",lvl:20s},{id:"minecraft:quick_charge",lvl:5s}],AttributeModifiers:[{AttributeName:"generic.attack_damage",Name:"noName",Amount:0d,Operation:0,UUID:[I;8614,4168,6668,9334],Slot:mainhand},{AttributeName:"generic.attack_speed",Name:"noName",Amount:0d,Operation:0,UUID:[I;4863,1569,2993,8155],Slot:mainhand}]} 1

#给予刺剑（下界合金剑）
give @p minecraft:netherite_sword{can_right_click:1b,from_map:1b,Unbreakable:1b,display:{Name:"[\"§1§l『刺剑』\"]",Lore:["[\"§9近战武器,对命中敌人造成§l70%§9的物理伤害,然后对周围5格内随机敌人造成§l60%×3§9的物理伤害.\"]","[\"§9每次击中敌人回复§l4MP§9.\"]","[\"\"]","[\"§2物理伤害计算公式:\"]","[\"§c造成伤害=攻击伤害-防御力.\"]"]},HideFlags:63b,Enchantments:[{id:"minecraft:unbreaking",lvl:20s}],AttributeModifiers:[{AttributeName:"generic.attack_damage",Name:"noName",Amount:0d,Operation:0,UUID:[I;8614,4168,6668,9334],Slot:mainhand},{AttributeName:"generic.attack_speed",Name:"noName",Amount:0d,Operation:0,UUID:[I;4863,1569,2993,8155],Slot:mainhand}]} 1


# ======================================== 技能 ========================================
#剑系技能书
#三连斩 triple_slash
give @p minecraft:music_disc_chirp{from_map:1b,skill_id:"三连斩",display:{Name:"[\"§4§l『剑系』§6三连斩\"]",Lore:["[\"§9向前方快速挥出三连斩,每一斩造成§l70%§9的物理伤害.\"]","[\"§9锁定范围:\"]","[\"§3§l■■■■■\"]","[\"§3§l■■■■■\"]","[\"§3§l■■■■■\"]","[\"§3§l■■■■■\"]","[\"§3§l■■■■■\"]","[\"§3§l■■□■■\"]","[\"§9消耗:§l10MP§9.\"]","[\"§9冷却时间:§l3s§9.\"]","[\"§9最大锁定:§l3§9人.\"]"]}}
#费伤比:21 倍率210% CD:3s 定位:低MP消耗连击物理

give @p minecraft:music_disc_chirp{from_map:1b,skill_id:"剑气",display:{Name:"[\"§4§l『剑系』§6剑气\"]",Lore:["[\"§9在剑刃上叠加1层剑气,使下次普攻会附带§l75%§9物理伤害的剑气.\"]","[\"§9剑气最多可以叠加10层,每次普攻消耗一层.\"]","[\"§9锁定范围:\"]","[\"§3§l■■■\"]","[\"§3§l■■■\"]","[\"§3§l■■■\"]","[\"§3§l■■■\"]","[\"§3§l■□■\"]","[\"§9消耗:§l5MP§9.\"]","[\"§9冷却时间:§l0s§9.\"]","[\"§9最大锁定:§l3§9人.\"]"]}}
#费伤比:15 倍率225% CD:7s 条件:侧位 定位:高倍率群攻物理



give @p minecraft:music_disc_chirp{from_map:1b,skill_id:"万剑归宗",display:{Name:"[\"§4§l『剑系』§6万剑归宗\"]",Lore:["[\"§9切换『剑』的普通攻击模式为万剑归宗形态,持续15s.\"]","[\"§9攻击间隔极大幅度缩短,攻击距离+2格,每次攻击回复1MP.\"]","[\"§d普攻锁定最近2名敌人,随机召唤X剑造成§l45~70%§d的物理伤害,倍率随生成剑的材质决定.\"]","[\"§9锁定范围:\"]","[\"§3以玩家为中心半径为6的圆形.§l\"]","[\"§9消耗:§l75MP§9.\"]","[\"§9冷却时间:§l20s§9.\"]","[\"§9最大锁定:§l2§9人.\"]"]}}
# #费伤比37.5 倍率:75~150%


give @p minecraft:music_disc_chirp{from_map:1b,skill_id:"烈焰横扫",display:{Name:"[\"§4§l『剑系』§6烈焰横扫\"]",Lore:["[\"§9向前方较宽范围持剑横扫,造成§65%§9的法术伤害,并叠加§l12s§9燃烧.\"]","[\"§9若命中单位已经是燃烧状态,则叠加的燃烧时间减半.\"]","[\"§d燃烧:此状态下的单位每0.75秒受到3点真实伤害,持续时间可以被叠加.\"]","[\"§9锁定范围:\"]","[\"§3§l ■■■■■■■■■\"]","[\"§3§l ■■■■■■■■■\"]","[\"§3§l■■■■■■■■■■■\"]","[\"§3§l■■■■■□■■■■■\"]","[\"§9消耗:§l10MP§9.\"]","[\"§9冷却时间:§l3s§9.\"]","[\"§9最大锁定:§l5§9人.\"]"]}}

#缴械 disarm
 give @p minecraft:music_disc_chirp{from_map:1b,skill_id:"缴械",display:{Name:"[\"§4§l『剑系』§6缴械\"]",Lore:["[\"§9击落前方最近的一名敌人手中的武器,对BOSS无效.\"]","[\"§9锁定范围:\"]","[\"§3§l■■■\"]","[\"§3§l■■■\"]","[\"§3§l■■■\"]","[\"§3§l■■■\"]","[\"§3§l □\"]","[\"§9消耗:§l15MP§9.\"]","[\"§9冷却时间:§l10s§9.\"]","[\"§9最大锁定:§l1§9人.\"]"]}}

#悬赏之刃 bounty blade
 give @p minecraft:music_disc_chirp{from_map:1b,skill_id:"悬赏之刃",display:{Name:"[\"§4§l『剑系』§6悬赏之刃\"]",Lore:["[\"§9眩晕前方最近的一名敌人§l0.5s§9,并造成§l35%§9的真实伤害.\"]","[\"§9如果该技能击杀了敌人,则额外多掉落6个绿宝石和4个经验球,甚至有15%的概率掉落金苹果.\"]","[\"§9锁定范围:\"]","[\"§3§l■■■\"]","[\"§3§l■■■\"]","[\"§3§l■■■\"]","[\"§3§l■■■\"]","[\"§3§l □\"]","[\"§9消耗:§l10MP§9.\"]","[\"§9冷却时间:§l4s§9.\"]","[\"§9最大锁定:§l1§9人.\"]"]}}
#费伤比:20 倍率70% CD:2s 定位:低倍率群攻物理
#费伤比:20 倍率70% CD:2s 定位:低倍率群攻物理

#旋风斩 whirlwind
give @p minecraft:music_disc_chirp{from_map:1b,skill_id:"旋风斩",display:{Name:"[\"§4§l『剑系』§6旋风斩\"]",Lore:["[\"§9激活旋风buff,持续§l10s§9,每§l2s§9自动攻击周围敌人.\"]","[\"§9每次攻击造成§l125%§9的物理伤害.\"]","[\"§9攻击范围:\"]","[\"§3§l以玩家为中心半径为6的圆形\"]","[\"§9消耗:§l20MP§9.\"]","[\"§9冷却时间:§l20s§9.\"]","[\"§9每次最多攻击:§l2§9个敌人.\"]","[\"§9总攻击次数:§l5§9次.\"]"]}}
#费伤比:31.25 倍率125%×5=625% CD:20s 定位:持续型自动攻击buff

#烈焰横扫 flame_slash
give @p minecraft:music_disc_chirp{from_map:1b,skill_id:"烈焰横扫",display:{Name:"[\"§4§l『剑系』§6烈焰横扫\"]",Lore:["[\"§9向前方宽范围持剑横扫,造成§l65%§9的法术伤害,并叠加§l12s§9燃烧.\"]","[\"§9若命中单位已经是燃烧状态,则叠加的燃烧时间减半.\"]","[\"§d燃烧:此状态下的单位每0.75秒受到3点真实伤害,持续时间可叠加.\"]","[\"§9锁定范围:\"]","[\"§3§l ■■■■■■■■■\"]","[\"§3§l ■■■■■■■■■\"]","[\"§3§l■■■■■■■■■■■\"]","[\"§3§l■■■■■□■■■■■\"]","[\"§9消耗:§l10MP§9.\"]","[\"§9冷却时间:§l3s§9.\"]","[\"§9最大锁定:§l5§9人.\"]"]}}
#费伤比:6.5 倍率65% CD:3s 定位:持续燃烧法术伤害

#回弹 parry
give @p minecraft:music_disc_chirp{from_map:1b,skill_id:"弹反",display:{Name:"[\"§4§l『剑系』§6回弹\"]",Lore:["[\"§9将范围内的弹射物全部击飞反弹.\"]","[\"§9反弹的弹射物若击中敌人将造成等于其原本应对玩家造成伤害值的真实伤害.\"]","[\"§9若弹反成功,则回复释放者§l20MP§9.\"]","[\"§9锁定范围:\"]","[\"§3§l ■■■\"]","[\"§3§l■■■■■\"]","[\"§3§l■■■■■\"]","[\"§3§l■■■■■\"]","[\"§3§l■■□■■\"]","[\"§9消耗:§l0MP§9.\"]","[\"§9冷却时间:§l1s§9.\"]","[\"§9最大锁定:无上限.\"]"]}}
#费伤比:∞(反弹) 倍率:反弹伤害 CD:1s 定位:防御反击技能

#缴械 disarm
give @p minecraft:music_disc_chirp{from_map:1b,skill_id:"缴械",display:{Name:"[\"§4§l『剑系』§6缴械\"]",Lore:["[\"§9击落前方最近的一名敌人手中的武器,对BOSS无效.\"]","[\"§9锁定范围:\"]","[\"§3§l■■■\"]","[\"§3§l■■■\"]","[\"§3§l■■■\"]","[\"§3§l■■■\"]","[\"§3§l □\"]","[\"§9消耗:§l15MP§9.\"]","[\"§9冷却时间:§l10s§9.\"]","[\"§9最大锁定:§l1§9人.\"]"]}}
#费伤比:无伤害 CD:10s 定位:控制技能

#悬赏之刃 bounty_blade
give @p minecraft:music_disc_chirp{from_map:1b,skill_id:"悬赏之刃",display:{Name:"[\"§4§l『剑系』§6悬赏之刃\"]",Lore:["[\"§9眩晕前方最近的一名敌人§l0.5s§9,并造成§l35%§9的真实伤害.\"]","[\"§9如果该技能击杀了敌人,则额外多掉落§l6个绿宝石§9和§l4个经验球§9,甚至有§l15%§9的概率掉落金苹果.\"]","[\"§9锁定范围:\"]","[\"§3§l■■■\"]","[\"§3§l■■■\"]","[\"§3§l■■■\"]","[\"§3§l■■■\"]","[\"§3§l □\"]","[\"§9消耗:§l10MP§9.\"]","[\"§9冷却时间:§l4s§9.\"]","[\"§9最大锁定:§l1§9人.\"]"]}}
#费伤比:3.5 倍率35% CD:4s 定位:斩杀收益技能

#重斩 heavy_slash
give @p minecraft:music_disc_chirp{from_map:1b,skill_id:"重斩",display:{Name:"[\"§4§l『剑系』§6重斩\"]",Lore:["[\"§9延迟攻击型剑技,按下技能键后§l3秒§9后自动对锁定目标释放.\"]","[\"§9对最近的一名敌人造成§l400%§9的物理伤害.\"]","[\"§9锁定范围:\"]","[\"§3§l以玩家为中心半径为5的圆形.\"]","[\"§9消耗:§l10MP§9.\"]","[\"§9冷却时间:§l10s§9.\"]","[\"§9最大锁定:§l1§9人.\"]"]}}
#费伤比:40 倍率400% CD:10s 定位:延迟型高倍率单体物理


#风暴之舞 storm_dance
give @p minecraft:music_disc_chirp{from_map:1b,skill_id:"风暴剑舞",display:{Name:"[\"§4§l『剑系』§6风暴剑舞\"]",Lore:["[\"§9化身风暴,在周围快速旋转攻击,持续§l3s§9.\"]","[\"§9持续期间每§l0.5s§9对周围敌人造成§l85%§9的物理伤害.\"]","[\"§9最后爆发造成§l150%§9的物理伤害并击飞敌人.\"]","[\"§9锁定范围:\"]","[\"§3§l以玩家为中心半径为5的圆形\"]","[\"§9消耗:§l30MP§9.\"]","[\"§9冷却时间:§l15s§9.\"]","[\"§9最大锁定:§l8§9人.\"]"]}}
#费伤比:23.5 倍率:85%×6+150%=660% CD:15s 定位:持续AOE高倍率物理

#决斗领域 duel_domain
give @p minecraft:music_disc_chirp{from_map:1b,skill_id:"决斗领域",display:{Name:"[\"§4§l『剑系』§6决斗领域\"]",Lore:["[\"§9在脚下展开决斗领域,持续§l90s§9.\"]","[\"§9领域内玩家攻击力§l+15§9.\"]","[\"§9领域内敌人获得§l力量II§9效果.\"]","[\"§9领域范围:\"]","[\"§3§l以释放点为中心半径为12的圆形\"]","[\"§9消耗:§l40MP§9.\"]","[\"§9冷却时间:§l3s§9.\"]"]}}
#费伤比:增益型 CD:3s 定位:固定位置增益领域技能(敌我双方同时增强)





#弩系技能书
#快速装填 quickly_load
give @p minecraft:music_disc_chirp{from_map:1b,skill_id:"快速装填",display:{Name:"[\"§4§l『弩系』§6快速装填\"]",Lore:["[\"§9立刻为当前手持的弩装填一根箭矢,无需等待装填时间.\"]","[\"§9适合连弩快速输出或紧急应对.\"]","[\"§9锁定范围:\"]","[\"§3§l自身装填\"]","[\"§9消耗:§l10MP§9.\"]","[\"§9冷却时间:§l6s§9.\"]","[\"§9最大锁定:§l无\"]"]}}
#费伤比:无直接伤害 CD:6s 定位:快速装填辅助技能

#狙击 snipe
give @p minecraft:music_disc_chirp{from_map:1b,skill_id:"狙击",display:{Name:"[\"§4§l『弩系』§6狙击\"]",Lore:["[\"§9射出一发沿直线轨迹飞行的精准箭矢,飞行距离越远伤害越高.\"]","[\"§9依据飞行距离造成§l20%~500%§9的物理伤害.\"]","[\"§d距离5格内20%,每增加1格增加32%伤害,最高500%.\"]","[\"§9锁定范围:\"]","[\"§3§l直线射程约30格\"]","[\"§9消耗:§l15MP§9.\"]","[\"§9冷却时间:§l3s§9.\"]","[\"§9最大锁定:§l1§9人.\"]"]}}
#费伤比:1.3~33.3 倍率:20%~500% CD:3s 定位:超远距离单体狙击

#穿甲雷 armor_piercing_mine
give @p minecraft:music_disc_chirp{from_map:1b,skill_id:"穿甲雷",display:{Name:"[\"§4§l『弩系』§6穿甲雷\"]",Lore:["[\"§9在地上放置一颗地雷,§l5s§9后地雷部署完毕.\"]","[\"§9敌人踩在上方会引爆地雷造成§l150%§9的物理伤害,并在§l10s§9内防御力降低§l50%§9.\"]","[\"§9锁定范围:\"]","[\"§3§l以地雷为中心半径为6的圆形\"]","[\"§9消耗:§l40MP§9.\"]","[\"§9冷却时间:§l15s§9.\"]","[\"§9最大锁定:§l8§9人.\"]"]}}
#费伤比:3.75 倍率:150% CD:15s 定位:陷阱削甲控场

#加农炮 cannon
give @p minecraft:music_disc_chirp{from_map:1b,skill_id:"加农炮",display:{Name:"[\"§4§l『弩系』§6加农炮\"]",Lore:["[\"§9蓄力§l4s§9后向前方轰出3格宽弹道的巨型火弹,飞出一段距离后产生爆炸.\"]","[\"§9沿途对敌人造成§l325%×2§9的物理伤害.\"]","[\"§9爆炸对周围敌人造成§l500%§9的物理伤害,并附带眩晕§l4s§9、燃烧§l12s§9.\"]","[\"§d副作用:技能结束后的§l12s§9内防御力§l-65%§9,攻击§l-30%§9.\"]","[\"§9锁定范围:\"]","[\"§3§l直线弹道约20格,爆炸半径5格\"]","[\"§9消耗:§l100MP§9.\"]","[\"§9冷却时间:§l60s§9.\"]","[\"§9最大锁定:沿途无上限,爆炸§l5§9人.\"]"]}}
#费伤比:11.5 倍率:325%×2+500%=1150% CD:60s 定位:超高倍率终极炮击

#点火 ignite
give @p minecraft:music_disc_chirp{from_map:1b,skill_id:"点火",display:{Name:"[\"§4§l『弩系』§6点火\"]",Lore:["[\"§9射出一枚火焰弹,命中后爆炸对范围内敌人造成§l110%§9的法术伤害.\"]","[\"§9并使命中的敌人燃烧§l8s§9.\"]","[\"§d对苦力怕有特殊效果:立即引爆.\"]","[\"§9锁定范围:\"]","[\"§3§l爆炸半径3格\"]","[\"§9消耗:§l15MP§9.\"]","[\"§9冷却时间:§l4s§9.\"]","[\"§9最大锁定:§l5§9人.\"]"]}}
#费伤比:7.3 倍率:110% CD:4s 定位:范围燃烧法术伤害

#高压弹 high_pressure_shot
give @p minecraft:music_disc_chirp{from_map:1b,skill_id:"高压弹",display:{Name:"[\"§4§l『弩系』§6高压弹\"]",Lore:["[\"§9向前方发射一发高速精准弹,造成§l325%§9的物理伤害.\"]","[\"§d副作用:命中的敌人获得§l速度III§d和§l力量III§d效果,持续§l10s§d.\"]","[\"§9锁定范围:\"]","[\"§3§l直线射程约30格\"]","[\"§9消耗:§l25MP§9.\"]","[\"§9冷却时间:§l12s§9.\"]","[\"§9最大锁定:§l1§9人.\"]"]}}
#费伤比:13 倍率:325% CD:12s 定位:单体超高伤但强化敌人

#凝滞弹 stasis_shot
give @p minecraft:music_disc_chirp{from_map:1b,skill_id:"凝滞弹",display:{Name:"[\"§4§l『弩系』§6凝滞弹\"]",Lore:["[\"§9射出寒冰弹,碰撞后爆炸造成§l75%§9的物理伤害.\"]","[\"§9命中的敌人获得§l减速II§9效果,持续§l10s§9.\"]","[\"§9锁定范围:\"]","[\"§3§l爆炸半径3格\"]","[\"§9消耗:§l15MP§9.\"]","[\"§9冷却时间:§l8s§9.\"]","[\"§9最大锁定:§l3§9人.\"]"]}}
#费伤比:5 倍率:75% CD:8s 定位:范围减速控制





#杖系技能书
#天降甘露 nectar
give @p minecraft:music_disc_chirp{from_map:1b,skill_id:"天降甘露",display:{Name:"[\"§4§l『杖系』§6天降甘露\"]",Lore:["[\"§9降下治愈甘露,令受到沐浴的玩家获得生命回复III,持续§l10s§9.\"]","[\"§d生命回复期间如果受到伤害,buff将会消失.\"]","[\"§9锁定范围:\"]","[\"§3§l以玩家为中心半径为5的圆形\"]","[\"§9消耗:§l25MP§9.\"]","[\"§9冷却时间:§l20s§9.\"]","[\"§9最大锁定:§l2§9人.\"]"]}}
#费伤比:无伤害 CD:20s 定位:团队治疗辅助技能

#魂灵爆破 soul_blast
give @p minecraft:music_disc_chirp{from_map:1b,skill_id:"噬魂",display:{Name:"[\"§4§l『杖系』§6魂灵爆破\"]",Lore:["[\"§9在玩家位置放置一个延迟爆破marker,§l6秒§9蓄力后开始爆炸.\"]","[\"§9每§l5tick§9爆炸一次,共爆炸§l4次§9,每次造成§l175%§9法术伤害并眩晕§l2秒§9.\"]","[\"§d总持续时间7秒后marker消失.\"]","[\"§9锁定范围:\"]","[\"§3§l以marker为中心半径为5的圆形\"]","[\"§9消耗:§l35MP§9.\"]","[\"§9冷却时间:§l3s§9.\"]","[\"§9最大锁定:§l4§9人.\"]"]}}
#费伤比:20 倍率:175%×4=700% CD:3s 定位:延迟AOE控制法术伤害

#炎爆术 flame_blast
give @p minecraft:music_disc_chirp{from_map:1b,skill_id:"炎爆术",display:{Name:"[\"§4§l『杖系』§6炎爆术\"]",Lore:["[\"§9引爆周围敌人的燃烧层数,造成§l(燃烧时间s×10)§9点的真实伤害(上限500)并眩晕§l1.25s§9.\"]","[\"§d需要配合燃烧技能使用,燃烧时间越长伤害越高.\"]","[\"§9锁定范围:\"]","[\"§3§l以玩家为中心半径为8的圆形\"]","[\"§9消耗:§l50MP§9.\"]","[\"§9冷却时间:§l60s§9.\"]","[\"§9最大锁定:§l无上限§9.\"]"]}}
#费伤比:变动(依赖燃烧层数) 倍率:真实伤害 CD:60s 定位:燃烧引爆终结技

#火焰喷射 flame_spray
give @p minecraft:music_disc_chirp{from_map:1b,skill_id:"火焰喷射",display:{Name:"[\"§4§l『杖系』§6火焰喷射\"]",Lore:["[\"§9向前方长矩形范围持续喷射火焰,持续§l4s§9.\"]","[\"§9每§l0.5s§9为范围内敌人叠加§l2s§9燃烧.\"]","[\"§d持续施法期间无法移动.\"]","[\"§9锁定范围:\"]","[\"§3§l前方长10格宽3格的矩形\"]","[\"§9消耗:§l30MP§9.\"]","[\"§9冷却时间:§l20s§9.\"]","[\"§9最大锁定:§l5§9人.\"]"]}}
#费伤比:无直接伤害 CD:20s 定位:持续施法燃烧叠加

#暗影领域 shadow_field
give @p minecraft:music_disc_chirp{from_map:1b,skill_id:"暗影领域",display:{Name:"[\"§4§l『杖系』§6暗影领域\"]",Lore:["[\"§9展开暗影领域,持续§l10s§9.\"]","[\"§9领域内的敌人每秒受到§l25%§9的法术伤害,并被施加缓慢II和虚弱I.\"]","[\"§9领域内的玩家隐身且移动速度§l+15%§9.\"]","[\"§9锁定范围:\"]","[\"§3§l以玩家为中心半径为7的圆形\"]","[\"§9消耗:§l45MP§9.\"]","[\"§9冷却时间:§l35s§9.\"]","[\"§9最大锁定:§l无上限§9.\"]"]}}
#费伤比:5.6 倍率:25%×10=250% CD:35s 定位:控场debuff领域

#游荡灯笼 wandering_lantern
give @p minecraft:music_disc_chirp{from_map:1b,skill_id:"游荡灯笼",display:{Name:"[\"§4§l『杖系』§6游荡灯笼\"]",Lore:["[\"§9召唤一个游荡的魔法灯笼跟随玩家,持续§l15s§9.\"]","[\"§9灯笼会自动攻击周围8格内的敌人,每§l2s§9造成§l60%§9的法术伤害.\"]","[\"§9灯笼存在期间,玩家MP回复速度§l+50%§9.\"]","[\"§9锁定范围:\"]","[\"§3§l以灯笼为中心半径为8的圆形\"]","[\"§9消耗:§l35MP§9.\"]","[\"§9冷却时间:§l25s§9.\"]","[\"§9最大锁定:§l3§9人.\"]"]}}
#费伤比:12.9 倍率:60%×7.5=450% CD:25s 定位:召唤物持续输出+MP加速

#弱化弹 weakness_shot
give @p minecraft:music_disc_chirp{from_map:1b,skill_id:"弱化弹",display:{Name:"[\"§4§l『杖系』§6弱化弹\"]",Lore:["[\"§9射出暗能量弹,碰撞后爆炸造成§l60%§9的法术伤害.\"]","[\"§9命中的敌人获得§l虚弱II§9效果,持续§l10s§9.\"]","[\"§9锁定范围:\"]","[\"§3§l爆炸半径4格\"]","[\"§9消耗:§l18MP§9.\"]","[\"§9冷却时间:§l10s§9.\"]","[\"§9最大锁定:§l5§9人.\"]"]}}
#费伤比:3.3 倍率:60% CD:10s 定位:范围虚弱debuff

#无系
 give @p minecraft:music_disc_chirp{from_map:1b,skill_id:"御血",display:{Name:"[\"§4§l『无系』§6御血\"]",Lore:["[\"§9扣除自身25%生命值,攻击力§l+50%§9,持续§l12s§9.\"]","[\"§9锁定范围:\"]","[\"§3玩家自身.\"]","[\"§9消耗:§l0MP§9.\"]","[\"§9冷却时间:§l20s§9.\"]","[\"§9最大锁定:§l1§9人.\"]"]}}

give @p minecraft:music_disc_chirp{from_map:1b,skill_id:"圣盾",display:{Name:"[\"§4§l『无系』§6圣盾\"]",Lore:["[\"§9获得一个吸收§l24§9点伤害的护盾,持续§l20s§9.\"]","[\"§9锁定范围:\"]","[\"§3玩家自身.\"]","[\"§9消耗:§l50MP§9.\"]","[\"§9冷却时间:§l80s§9.\"]","[\"§9最大锁定:§l2§1人.\"]"]}}

give @p minecraft:music_disc_chirp{from_map:1b,skill_id:"震荡波",display:{Name:"[\"§4§l『无系』§6震荡波\"]",Lore:["[\"§9向周围扫出一道宽波,眩晕§l4s§9,同时附加12s减速II与虚落II.\"]","[\"§9锁定范围:\"]","[\"§3§l   ■■■■■\"]","[\"§3§l   ■■■■■\"]","[\"§3§l   ■■■■■\"]","[\"§3§l ■■■■■■■■■\"]","[\"§3§l ■■■■■■■■■\"]","[\"§3§l■■■■■■■■■■■\"]","[\"§3§l■■■■■□■■■■■\"]","[\"§3玩家自身.\"]","[\"§9消耗:§l10MP§9.\"]","[\"§9冷却时间:§l30s§9.\"]","[\"§9最大锁定:§l8§1人.\"]"]}}

 
give @p minecraft:music_disc_chirp{from_map:1b,skill_id:"紫晶标记",display:{Name:"[\"§4§l『无系』§6紫晶标记\"]",Lore:["[\"§9在地面上放置一个紫水晶标记,再按一次技能玩家可以传送至标记处.\"]","[\"§3§ln如果传回时距离>10格,则在返回时周围敌人造成0.75s眩晕.\"]","[\"§9锁定范围:\"]","[\"§3§l以玩家为中心半径为§l50§3格的圆形.\"]","[\"§9消耗:§l2MP§9.\"]","[\"§9冷却时间:§l0s§9.\"]","[\"§9最大锁定:§l1§9人.\"]"]}}

give @p minecraft:music_disc_chirp{from_map:1b,skill_id:"冲刺",display:{Name:"[\"§4§l『无系』§6冲刺\"]",Lore:["[\"§9位移技能,向前方进行一定距离的冲刺.\"]","[\"§d§l无法冲刺过'坑'/'悬崖'.\"]","[\"§d§l释放时请保证视角平视,俯视/仰视均会导致释放失败.\"]","[\"§9冲刺距离:§3§l10§3格.\"]","[\"§9消耗:§l10MP§9.\"]","[\"§9冷却时间:§l0s§9.\"]","[\"§9最大锁定:§l0§9人.\"]"]}}

give @p minecraft:music_disc_chirp{from_map:1b,skill_id:"后撤",display:{Name:"[\"§4§l『无系』§6后撤\"]",Lore:["[\"§9位移技能,向后方进行一定距离的位移,并对周围敌人减速40%持续2s.\"]","[\"§d§l无法后撤过'坑'/'悬崖'.\"]","[\"§d§l释放时请保证视角平视,俯视/仰视均会导致释放失败.\"]","[\"§9后侧距离:§3§l10§3格.\"]","[\"§9消耗:§l10MP§9.\"]","[\"§9冷却时间:§l0s§9.\"]","[\"§9最大锁定:§l0§9人.\"]"]}}

# ========================================技能分隔线========================================


#魂盘
give @p minecraft:music_disc_chirp{from_map:1b,soul_disc:1b,sd_id:"亡者之怒",display:{Name:"[\"§9『魂盘』§4§4亡者之怒\"]",Lore:["[\"§9当血量低于20%时,攻击力+4,移动速度+20%.\"]"]}}
give @p minecraft:music_disc_strad{from_map:1b,soul_disc:1b,sd_id:"精准射击",display:{Name:"[\"§9『魂盘』§1§d精准射击\"]",Lore:["[\"§9近距离射击(5格半径内)时,弩的暴击率提高20%.\"]"]}}
give @p minecraft:music_disc_mall{from_map:1b,soul_disc:1b,sd_id:"魔术置换",display:{Name:"[\"§9『魂盘』§5§l魔术置换\"]",Lore:["[\"§9剑的伤害类型由物理伤害切换为法术伤害.\"]","[\"§9§m咋哩,没见过近战法师啊?.\"]"]}}
give @p minecraft:music_disc_mellohi{from_map:1b,soul_disc:1b,sd_id:"迅捷之杖",display:{Name:"[\"§9『魂盘』§e§l迅捷之杖\"]",Lore:["[\"§9杖的攻击间隔缩短三分之一.\"]"]}}
give @p minecraft:music_disc_pigstep{from_map:1b,soul_disc:1b,sd_id:"烈火焚心",display:{Name:"[\"§9『魂盘』§4§l烈火焚心\"]",Lore:["[\"§9燃烧状态下的敌人移动速度-40%.\"]"]}}
give @p minecraft:music_disc_ward{from_map:1b,soul_disc:1b,sd_id:"反击回复",display:{Name:"[\"§9『魂盘』§2§l反击回复\"]",Lore:["[\"§9剑系『回弹』成功时,回复4HP.\"]"]}}
give @p minecraft:music_disc_stal{from_map:1b,soul_disc:1b,sd_id:"厄运数字4",display:{Name:"[\"§9『魂盘』§4§l厄运数字4\"]",Lore:["[\"§9当周围10格半径内存在HP末尾数字为4的敌人时候(如24/54/64等),受到44%的真实伤害.\"]","[\"§9§m米4达狂喜.\"]"]}}
give @p minecraft:music_disc_11{from_map:true,soul_disc:1b,sd_id:"苦痛荆棘",display:{Name:'"§9『魂盘』§2苦痛荆棘"',Lore:["[\"§9每次受到伤害时,对5格半径内敌人造成75%的真实伤害并中毒I12s.\"]"]}}
give @p minecraft:music_disc_11{from_map:true,soul_disc:1b,sd_id:"受击充能",display:{Name:'"§9『魂盘』§9受击充能"',Lore:["[\"§9每次受到伤害时,回复2MP.\"]"]}}
give @p minecraft:music_disc_11{from_map:true,soul_disc:1b,sd_id:"自动充能",display:{Name:'"§9『魂盘』§9自动充能"',Lore:["[\"§9每经过2s,自动回复1MP.\"]"]}}
give @p minecraft:music_disc_11{from_map:true,soul_disc:1b,sd_id:"蜕变挽歌",display:{Name:'"§9『魂盘』§6蜕变挽歌"',Lore:["[\"§9血量为满血时,挥剑会叠加一层剑气,效果详见技能剑气.\"]"]}}
give @p minecraft:music_disc_11{from_map:true,soul_disc:1b,sd_id:"反隐侦测",display:{Name:'"§9『魂盘』§9反隐侦测"',Lore:["[\"§9会令周围8格内的隐身单位显形.\"]"]}}
give @p minecraft:music_disc_11{from_map:true,soul_disc:1b,sd_id:"真实之眼",display:{Name:'"§5『魂盘』§9真实之眼"',Lore:["[\"§9造成的所有真实伤害倍率提高25%.\"]"]}}
give @p minecraft:music_disc_11{from_map:true,soul_disc:1b,sd_id:"圣泉恩惠",display:{Name:'"§5『魂盘』§3圣泉恩惠"',Lore:["[\"§9只有虔诚的人才能获得泉水的祝福,最大生命值+15%.\"]"]}}
give @p minecraft:music_disc_11{from_map:true,soul_disc:1b,sd_id:"射杀装填",display:{Name:'"§5『魂盘』§4射杀装填"',Lore:["[\"§9周围每有一名敌人死亡时,都会立刻在玩家当前主/副手弩上装填一根箭矢.\"]"]}}
give @p minecraft:music_disc_11{from_map:true,soul_disc:1b,sd_id:"伤害修正",display:{Name:'"§5『魂盘』§4伤害修正"',Lore:["[\"§9将原本只能造成1点伤害的威力提升至2点伤害.\"]"]}}
give @p minecraft:music_disc_11{from_map:true,soul_disc:1b,sd_id:"聚气成刃",display:{Name:'"§5『魂盘』§4聚气成刃"',Lore:["[\"§9技能剑气最大可以叠加30至层.\"]"]}}
give @p minecraft:music_disc_11{from_map:true,soul_disc:1b,sd_id:"战斗续航",display:{Name:'"§5『魂盘』§4战斗续航"',Lore:["[\"§9血量低于50%时,击杀敌人会回复自身4点生命值.此效果有3.5s的冷却时间.\"]"]}}









