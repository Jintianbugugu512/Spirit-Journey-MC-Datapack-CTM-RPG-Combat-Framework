#第二位以后的玩家选择

$execute unless entity @a[tag=player_$(index_pro)] run tellraw @s "选择失败,请先选择$(index_pro)号玩家之后再选择$(index)号玩家."
$execute unless entity @a[tag=player_$(index_pro)] run return 0


$execute if entity @a[tag=player_$(index)] run tellraw @s "选择失败,已经有其他人选择了$(index)号玩家,不能再选择了!"
$execute if entity @a[tag=player_$(index)] run return 0

execute if entity @s[tag=have_index] run tellraw @s "选择失败,你已经选择了自己的玩家序号,不能再选择了!"
execute if entity @s[tag=have_index] run return 0

$execute unless entity @a[tag=player_$(index)] run tellraw @s "选择成功,你已经成为$(index)号玩家!"


$execute unless entity @a[tag=player_$(index)] run give @s minecraft:written_book{title:"§9『系统手册』§6-$(index)号玩家",author:"§4属于$(index)号玩家的系统手册,极其重要的物品,请时刻随身携带!",pages:["[\"\",{\"text\":\"『目标查询』\",\"bold\":\"true\"},{\"text\":\"\\n\"},{\"text\":\"鼠标左键此处查询玩家当前可进行的游戏目标.\",\"underlined\":\"true\",\"clickEvent\":{\"action\":\"run_command\",\"value\":\"/function y_other:z_budao/player_manual/task\"}},{\"text\":\"\\n\"},{\"text\":\"\\n\"},{\"text\":\"(仅提供简单指引，告诉当前可以做的事，需从这些事中进行选择，不会把具体要做什么一五一十得告诉哦.)(在靠近目标时,会有紫色高亮显示,注意哦)\"}]","[\"\",{\"text\":\"『技能装配』\",\"bold\":\"true\"},{\"text\":\"\\n\"},{\"text\":\"鼠标左键此处可传送至技能装配屋.\",\"underlined\":\"true\",\"clickEvent\":{\"action\":\"run_command\",\"value\":\"/function y_other:z_budao/player_manual/skill_room\"}},{\"text\":\"\\n\"},{\"text\":\"\\n\"},{\"text\":\"技能装配屋内可以让玩家装备获得的『剑系』/『弩系』/『杖系』技能.\"}]","[\"\",{\"text\":\"『探索度查询』\",\"bold\":\"true\"},{\"text\":\" 鼠标右键此处查询当前所在区域的探索率.\",\"underlined\":\"true\",\"clickEvent\":{\"action\":\"run_command\",\"value\":\"/function y_other:z_budao/player_manual/completeness\"}},{\"text\":\"\\n\"},{\"text\":\"\\n\"},{\"text\":\"(探索率受到『道具的收集&村民的解救&BOSS的击杀』三个因素所影响.当探索率达到100%就说明你把当前这个场景毕业啦!)\"}]","[\"\",{\"text\":\"『属性查询』\",\"bold\":\"true\"},{\"text\":\" 鼠标右键此处查询玩家自身的攻击力,魂槽数量等属性.\",\"underlined\":\"true\",\"clickEvent\":{\"action\":\"run_command\",\"value\":\"/function y_other:z_budao/player_manual/attribute_query\"}},{\"text\":\"\\n\"},{\"text\":\"\\n\"},{\"text\":\"(所查询的属性值会受到当前buff的影响.)\"}]","[\"\",{\"text\":\"『玩家传送』\",\"bold\":\"true\"},{\"text\":\"\\n\"},{\"text\":\"\\n\"},{\"text\":\"传送至1号玩家\",\"underlined\":\"true\",\"clickEvent\":{\"action\":\"run_command\",\"value\":\"/function y_other:z_budao/player_manual/tp_player1 {index:1}\"}},{\"text\":\"\\n\"},{\"text\":\"传送至2号玩家\",\"underlined\":\"true\",\"clickEvent\":{\"action\":\"run_command\",\"value\":\"/function y_other:z_budao/player_manual/tp_player1 {index:2}\"}},{\"text\":\"\\n\"},{\"text\":\"传送至3号玩家\",\"underlined\":\"true\",\"clickEvent\":{\"action\":\"run_command\",\"value\":\"/function y_other:z_budao/player_manual/tp_player1 {index:3}\"}},{\"text\":\"\\n\"},{\"text\":\"传送至4号玩家\",\"underlined\":\"true\",\"clickEvent\":{\"action\":\"run_command\",\"value\":\"/function y_other:z_budao/player_manual/tp_player1 {index:4}\"}},{\"text\":\"\\n\"},{\"text\":\"传送至5号玩家\",\"underlined\":\"true\",\"clickEvent\":{\"action\":\"run_command\",\"value\":\"/function y_other:z_budao/player_manual/tp_player1 {index:5}\"}},{\"text\":\"\\n\"},{\"text\":\"传送至6号玩家\",\"underlined\":\"true\",\"clickEvent\":{\"action\":\"run_command\",\"value\":\"/function y_other:z_budao/player_manual/tp_player1 {index:6}\"}},{\"text\":\"\\n\"},{\"text\":\"传送至7号玩家\",\"underlined\":\"true\",\"clickEvent\":{\"action\":\"run_command\",\"value\":\"/function y_other:z_budao/player_manual/tp_player1 {index:7}\"}},{\"text\":\"\\n\"},{\"text\":\"传送至8号玩家\",\"underlined\":\"true\",\"clickEvent\":{\"action\":\"run_command\",\"value\":\"/function y_other:z_budao/player_manual/tp_player1 {index:8}\"}}]"]} 1

$execute unless entity @a[tag=player_$(index)] run tag @s add have_index
$execute unless entity @a[tag=player_$(index)] run tag @s add player_$(index)

