execute if score #p temp matches 1 run tellraw @a "§d如果是多人游戏,请确认多人游戏中所有玩家均已到齐,之后将不能再有玩家加入游戏."
execute if score #p temp matches 1 run tellraw @a "§l§4-再次按下按钮以确认-."

execute if score #p temp matches 2 run tellraw @a "§d请确认所有玩家均已到齐,之后将不能再有玩家加入游戏."
execute if score #p temp matches 2 run tellraw @a "§l§4-再次按下按钮以确认-."

execute if score #p temp matches 3 run tellraw @a "§d请确认所有玩家都已经选择了对应玩家序号,并且拿到了自己的系统手册."
execute store result score #p temp1 run execute if entity @a
execute store result score #p temp2 run execute if entity @a[tag=have_index]

execute if score #p temp matches 3 run tellraw @a [{"text":"目前系统检测到共有"},{"score": {"name": "#p","objective": "temp1"},"bold": true},{"text":"位玩家在线."}]
execute if score #p temp matches 3 run tellraw @a [{"text":"已经选择对应玩家序号的玩家共有"},{"score": {"name": "#p","objective": "temp2"},"bold": true},{"text":"位玩家."}]
execute if score #p temp matches 3 run execute if score #p temp1 > #p temp2 run scoreboard players operation #p temp1 -= #p temp2
execute if score #p temp matches 3 run execute if score #p temp1 > #p temp2 run tellraw @a [{"text":"还有"},{"score": {"name": "#p","objective": "temp1"},"bold": true},{"text":"位玩家没有选择序号,不能开始游戏."}]
execute if score #p temp matches 3 run execute if score #p temp1 > #p temp2 run tellraw @a "所有玩家都已经选好了玩家序号,可以开始游戏了!"
execute if score #p temp matches 3 run tellraw @a "§l§4-再次按下按钮以确认-."

execute if score #p temp matches 4 run function y_other:init/start

scoreboard players add #p temp 1

