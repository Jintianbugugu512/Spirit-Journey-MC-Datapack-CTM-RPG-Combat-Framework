execute as @p at @s run summon minecraft:text_display ~0.9 ~4 ~1 {text:'"§0Shift+左键"',background:1145,alignment:centre,line_width:400,Rotation:[90f,0f]}
execute as @p at @s run summon minecraft:text_display ~0.9 ~4 ~3 {text:'"§0Shift+空格"',background:1145,alignment:centre,line_width:400,Rotation:[90f,0f]}
execute as @p at @s run summon minecraft:text_display ~0.9 ~4 ~5 {text:'"§0Shift+右键"',background:1145,alignment:centre,line_width:400,Rotation:[90f,0f]}

execute as @p at @s run summon minecraft:item_display ~0.9 ~1.6 ~ {item:{id:"minecraft:iron_sword",Count:1b},Rotation:[90f,0f]}
execute as @p at @s run summon minecraft:item_display ~0.9 ~2.6 ~ {item:{id:"minecraft:crossbow",Count:1b},Rotation:[-90f,0f]}
execute as @p at @s run summon minecraft:item_display ~0.9 ~3.6 ~ {item:{id:"minecraft:carrot_on_a_stick",Count:1b},Rotation:[90f,0f]}

execute as @e[limit=3,sort=nearest,type=item_display] run data merge entity @s {transformation:{scale:[0.7f,0.7f,0.7f]},start_interpolation:0,interpolation_duration:20}