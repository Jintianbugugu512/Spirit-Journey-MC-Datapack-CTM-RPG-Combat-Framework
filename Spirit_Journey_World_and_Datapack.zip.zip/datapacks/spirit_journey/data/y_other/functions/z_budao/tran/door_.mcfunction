























data remove entity @s interaction
scoreboard players set @s detect_right1 0

#修改按钮自身的旋转与缩放
data merge entity @e[limit=1,sort=nearest,tag=door_] {transformation:{left_rotation:[-1f,0.0f,0.0f,0.0f],scale:[0f,0f,0f]},start_interpolation:0,interpolation_duration:20}


#修改周围方块的旋转与缩放
execute as @e[tag=door_block,distance=..10] run data merge entity @s {transformation:{left_rotation:[0.8f,0.6f,0.0f,0.0f],scale:[0f,0f,0f]},start_interpolation:0,interpolation_duration:12}

#消除周围的屏障
execute as @e[tag=door_block,distance=..10] at @s run setblock ~ ~ ~ air replace



#2s后删除
scoreboard players set @e[tag=door,distance=..10] countDown 40
scoreboard players set @e[tag=door_,distance=..10] countDown 40
scoreboard players set @e[tag=door_block,distance=..10] countDown 40
