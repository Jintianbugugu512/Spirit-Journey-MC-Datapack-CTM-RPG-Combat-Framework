

execute store result score @s detect_right1 run data get entity @s interaction.timestamp
scoreboard players set @s temp 0
execute if score @s detect_right1 > @s temp run function y_other:z_budao/tran/door_

