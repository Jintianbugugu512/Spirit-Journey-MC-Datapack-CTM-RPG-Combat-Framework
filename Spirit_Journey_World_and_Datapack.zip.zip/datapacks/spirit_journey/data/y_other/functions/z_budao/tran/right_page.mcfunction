#是最后一页就直接不执行
execute if score #page temp matches 6 run return 2
kill @e[tag=tit]
execute as @a at @s run playsound item.book.page_turn ambient @s ~ ~ ~
scoreboard players add #page temp 1

# Page 1
execute if score #page temp matches 1 run summon text_display 10.9 293 0.3 {\
text:'[\
"",\
{"text":"§0§l欢迎游玩〖生灵之旅〗\\n\\n","bold":true},\
{"text":"§0作者: Mana\\n\\n"},\
{"text":"§4§nPS:右键讲台的左右两侧按钮可以进行翻页哦!§0\\n\\n\\n\\n\\n"},\
{"text":"§lPage:1/6"}\
]',\
background:1145,\
alignment:left,\
line_width:400,\
Rotation:[90f,0f],\
transformation:{scale:[3f,3f,3f]},\
start_interpolation:0,\
interpolation_duration:15,\
Tags:["tit"]\
}

# Page 2
execute if score #page temp matches 2 run summon text_display 10.9 293 0.3 {\
text:'[\
"",\
{"text":"§0§l〖感谢名单〗\\n\\n","bold":true},\
{"text":"§0本地图的建筑/地形使用了以下作者的作品,在此表示感谢!\\n\\n"},\
{"text":"§0梦想小镇+童话镇 ------ By:【sjy】\\n"},\
{"text":"§0长留阁 ------- By:11月风飞舞\\n"},\
{"text":"§0九黎部落&有穷部落&遗失的云梦泽 ------ By:你喵我很忙\\n"},\
{"text":"§0神话天坑·瑶池仙境 ------ By:大鹅不会飞\\n\\n\\n"},\
{"text":"§0§l〖地形制作〗\\n\\n","bold":true},\
{"text":"§0茶馆笔刷包&下午茶树包 --- 相关协议在帖子内.\\n\\n\\n\\n"},\
{"text":"§lPage:2/6"}\
]',\
background:1145,\
alignment:left,\
line_width:400,\
Rotation:[90f,0f],\
transformation:{scale:[3f,3f,3f]},\
start_interpolation:0,\
interpolation_duration:15,\
Tags:["tit"]\
}

# Page 3
execute if score #page temp matches 3 run summon text_display 10.9 293 1.2 {\
text:'[\
"",\
{"text":"§0§l〖地图设置〗\\n\\n","bold":true},\
{"text":"§0地图使用版本: 1.20.2+\\n"},\
{"text":"§0游戏人数: 1~8人均可\\n"},\
{"text":"§4粒子效果: 开到最大§0\\n"},\
{"text":"§0游戏模式: 冒险\\n"},\
{"text":"§0允许作弊: 开\\n"},\
{"text":"§0材质包: 将地图材质包置于最上方.\\n\\n\\n"},\
{"text":"§0§l〖注意事项〗\\n\\n","bold":true},\
{"text":"§01. 请不要用指令修改出生点,修改出生点请使用床.\\n"},\
{"text":"§02. 本地图禁止tp指令,传送请使用地图自带的传送阵和系统手册的玩家互传功能.\\n"},\
{"text":"§03. 因为禁止tp,当然kill指令快速回城也是不行的,随意传送极其容易出bug!\\n\\n\\n"},\
{"text":"§lPage:3/6"}\
]',\
background:1145,\
alignment:left,\
line_width:400,\
Rotation:[90f,0f],\
transformation:{scale:[3f,3f,3f]},\
start_interpolation:0,\
interpolation_duration:15,\
Tags:["tit"]\
}

# Page 4
execute if score #page temp matches 4 run summon text_display 10.9 293 1.2 {\
text:'[\
"",\
{"text":"§0§l〖实况相关〗\\n\\n","bold":true},\
{"text":"§0你可以随意录制/直播本地图的实况.\\n\\n\\n"},\
{"text":"§0§l〖服务器相关〗\\n\\n","bold":true},\
{"text":"§0公益服务器在表明原作者前提下可使用本地图中的内容,商业服务器禁止使用.\\n\\n\\n\\n\\n"},\
{"text":"§lPage:4/6"}\
]',\
background:1145,\
alignment:left,\
line_width:400,\
Rotation:[90f,0f],\
transformation:{scale:[3f,3f,3f]},\
start_interpolation:0,\
interpolation_duration:15,\
Tags:["tit"]\
}

# Page 5
execute if score #page temp matches 5 run summon text_display 10.9 293.5 1 {\
text:'[\
"",\
{"text":"§0§l〖地图介绍〗\\n\\n","bold":true},\
{"text":"§0〖生灵之旅〗是一张结合了MC原版RPG和类银河恶魔城(简称类银)玩法的冒险地图.\\n"},\
{"text":"§0玩法会和『空洞骑士』『终焉之莉莉丝』『TEVI』这类游戏比较类似.\\n\\n\\n"},\
{"text":"§0『与其他rpg地图的不同之处』\\n\\n","bold":true},\
{"text":"§01: 几乎不需要肝装备和材料,地图中装备和材料主要都通过探索获得.\\n"},\
{"text":"§02. 地图以玩家探索为主,所以不会告诉玩家当前具体该做些什么,玩家需要四处逛图找事做.\\n"},\
{"text":"§03. 地图探索没有固定顺序,地图数值增长很小不会被区域难度限制探索自由.\\n\\n"},\
{"text":"§0PS:为了照顾不熟悉类银游戏的玩家,作者在玩家手册中添加了『目标』,可以给出提示告诉玩家当前可以做的事.§0\\n\\n\\n"},\
{"text":"§lPage:5/6"}\
]',\
background:1145,\
alignment:left,\
line_width:400,\
Rotation:[90f,0f],\
transformation:{scale:[3f,3f,3f]},\
start_interpolation:0,\
interpolation_duration:15,\
Tags:["tit"]\
}

# Page 6
execute if score #page temp matches 6 run summon text_display 10.9 293.5 0 {\
text:'[\
"",\
{"text":"§0§l『最后』\\n\\n","bold":true},\
{"text":"§0最后,也是最重要的,当然是要玩的开心啦!祝你游玩愉快ヾ(≧▽≦*)o\\n\\n"},\
{"text":"§4§n右键身后的磁石以进入后面的房间.§0\\n\\n\\n\\n\\n\\n\\n"},\
{"text":"§lPage:6/6"}\
]',\
background:1145,\
alignment:left,\
line_width:400,\
Rotation:[90f,0f],\
transformation:{scale:[3f,3f,3f]},\
start_interpolation:0,\
interpolation_duration:15,\
Tags:["tit"]\
}
