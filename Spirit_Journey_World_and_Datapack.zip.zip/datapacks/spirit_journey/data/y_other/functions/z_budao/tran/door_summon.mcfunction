#起始房间 

summon interaction -3.3 293 0 {width:1.3,height:1.3,response:true,Tags:["door"]}
summon item_display -3.2 293.5 0 {item:{id:"lodestone",Count:1b},Tags:["door_"]}


summon item_display -4 292.5 1 {item:{id:"oak_planks",Count:1b},Tags:["door_block"]}
summon item_display -4 292.5 0 {item:{id:"oak_planks",Count:1b},Tags:["door_block"]}
summon item_display -4 292.5 -1 {item:{id:"oak_planks",Count:1b},Tags:["door_block"]}
summon item_display -4 293.5 1 {item:{id:"oak_planks",Count:1b},Tags:["door_block"]}
summon item_display -4 294.5 1 {item:{id:"oak_planks",Count:1b},Tags:["door_block"]}
summon item_display -4 293.5 0 {item:{id:"oak_planks",Count:1b},Tags:["door_block"]}
summon item_display -4 294.5 0 {item:{id:"oak_planks",Count:1b},Tags:["door_block"]}
summon item_display -4 293.5 -1 {item:{id:"oak_planks",Count:1b},Tags:["door_block"]}
summon item_display -4 294.5 -1 {item:{id:"oak_planks",Count:1b},Tags:["door_block"]}







