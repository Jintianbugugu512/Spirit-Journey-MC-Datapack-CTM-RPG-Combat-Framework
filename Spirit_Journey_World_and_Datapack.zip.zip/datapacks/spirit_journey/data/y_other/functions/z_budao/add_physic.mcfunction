#execute at @p run
scoreboard players add @e[tag=budao,sort=nearest,limit=1] physical_armor 1
scoreboard players add @e[tag=little_budao,distance=..30] physical_armor 1
execute as @e[tag=budao,limit=1,sort=nearest] run tellraw @p [{"text":"不倒翁的防御已经增加至"},{"score": {"name": "@s","objective": "physical_armor"},"bold": true}]



#tellraw @p [{"text":"不倒翁的防御力已经增加至"},{"score": {"name": "@p","objective": "MP"},"bold": true,"color": "blue"}]
