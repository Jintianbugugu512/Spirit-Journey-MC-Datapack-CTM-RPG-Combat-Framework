#execute at @p run
scoreboard players reset @e[tag=budao,sort=nearest,limit=1] physical_armor
scoreboard players reset @e[tag=budao,sort=nearest,limit=1] magic_resist

scoreboard players reset @e[tag=budao,distance=..30] physical_armor
scoreboard players reset @e[tag=budao,distance=..30] magic_resist

execute as @e[tag=budao,limit=1,sort=nearest] run tellraw @p [{"text":"所有不倒翁的防御和魔抗已经重置为0"}]



#tellraw @p [{"text":"不倒翁的防御力已经增加至"},{"score": {"name": "@p","objective": "MP"},"bold": true,"color": "blue"}]
