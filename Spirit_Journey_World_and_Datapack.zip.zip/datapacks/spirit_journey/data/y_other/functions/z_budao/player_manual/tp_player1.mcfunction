#调用此函数的正确姿势



execute if entity @s[tag=battle_with_boss] run tellraw @s "『你正在与boss战斗中,不可以传送!』"
execute if entity @e[tag=battle_with_boss] run return 0

execute if entity @e[distance=..15,tag=enemy] run effect give @e[distance=..16,tag=enemy] glowing 3 1 true
execute if entity @e[distance=..15,tag=enemy] run tellraw @s "『你周围15格内存在敌方单位,不可以传送!』"
execute if entity @e[distance=..15,tag=enemy] run return 0

$execute if entity @a[tag=battle_with_boss,tag=player_$(index)] run tellraw @s "『传送对象正在与boss战斗中,不可以传送!』"
$execute if entity @a[tag=battle_with_boss,tag=player_$(index)] run return 0

$execute at @a[tag=player_$(index)] run execute if entity @e[distance=..15] run tellraw @s "『传送对象周围15格内存在敌方单位,不可以传送!』"
$execute as @a[tag=player_$(index)] at @s run execute if entity @e[distance=..15] run return 0

$tp @s @a[limit=1,tag=player_$(index)]
