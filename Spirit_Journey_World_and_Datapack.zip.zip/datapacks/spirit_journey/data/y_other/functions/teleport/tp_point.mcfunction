#召唤tp_point
#summon minecraft:interaction ~ ~1 ~ {width:1.3,height:1.3,response:true,Tags:["tp_point","0_point"]}
#summon minecraft:item_display ~ ~1 ~ {item:{id:"purple_stained_glass",Count:1b},Tags:["tp_point_block"]}
execute store result score @s detect_right1 run data get entity @s interaction.timestamp
scoreboard players set @s temp 0
# execute as @e[tag=tp_point_block] at @s run particle enchant ~ ~0.3 ~ 1 0.8 1 0.2 10 normal
execute if score @s detect_right1 > @s temp run function y_other:teleport/tp_list

