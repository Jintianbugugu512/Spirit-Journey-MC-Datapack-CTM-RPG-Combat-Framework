execute if entity @a[tag=battle_with_boss] run tellraw @p "『有玩家正在与boss战斗中,不可以传送!』"
execute if entity @e[tag=battle_with_boss] run return 0
return 1
#正确调用姿势
#/execute if function y_other:teleport.mcfunction/tp_boss run tp @p ~ ~ ~