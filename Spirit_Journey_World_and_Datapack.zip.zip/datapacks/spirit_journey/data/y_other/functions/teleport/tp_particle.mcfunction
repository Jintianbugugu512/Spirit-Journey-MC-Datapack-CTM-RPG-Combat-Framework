
execute unless entity @e[tag=tp] run execute as @e[tag=tp_point] at @s run summon text_display ~ ~-1 ~ {Tags:["tp"],ActiveEffects:[{Id:14b,Duration:200000,Amplifier:2b,Ambient:0b,ShowParticles:0b}]}
execute unless entity @e[tag=tp_] run execute as @e[tag=tp_point] at @s run summon text_display ~ ~-1 ~ {Tags:["tp_"],ActiveEffects:[{Id:14b,Duration:200000,Amplifier:2b,Ambient:0b,ShowParticles:0b}]}

scoreboard players set @e[tag=tp] countDown 90
scoreboard players set @e[tag=tp_] countDown 90

schedule function y_other:teleport/fun1 89t


