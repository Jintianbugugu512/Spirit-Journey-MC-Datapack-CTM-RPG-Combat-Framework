kill @e[tag=tp]
kill @e[tag=tp_]
kill @e[tag=tp_pivot]
kill @e[tag=tp__pivot]
