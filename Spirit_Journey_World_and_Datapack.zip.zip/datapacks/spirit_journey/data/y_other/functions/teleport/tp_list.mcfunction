#为已经使用过的传送点添加可以传送的权限.
execute if entity @s[tag=0_point] run tag @a[tag=player_1] add 0_point
execute if entity @s[tag=1_point] run tag @a[tag=player_1] add 1_point
execute if entity @s[tag=2_point] run tag @a[tag=player_1] add 2_point
execute if entity @s[tag=3_point] run tag @a[tag=player_1] add 3_point
execute if entity @s[tag=4_point] run tag @a[tag=player_1] add 4_point
execute if entity @s[tag=5_point] run tag @a[tag=player_1] add 5_point
execute if entity @s[tag=6_point] run tag @a[tag=player_1] add 6_point
execute if entity @s[tag=7_point] run tag @a[tag=player_1] add 7_point
execute if entity @s[tag=8_point] run tag @a[tag=player_1] add 8_point


#发送对应的传送点位
tellraw @p "§l§3---------------『点击以选择传送地点』---------------"
execute if entity @a[tag=player_1,tag=0_point] run tellraw @p [{"text":"§e『穴居村落』","clickEvent":{"action":"run_command","value":"/tp @s ~ ~10 ~"},"hoverEvent":{"action":"show_text","value":"§9左键此处传送至§e『穴居村落』"}}]
execute if entity @a[tag=player_1,tag=1_point] run tellraw @p [{"text":"§d『紫晶洞穴』","clickEvent":{"action":"run_command","value":"/tp @s -1013 100 1013"},"hoverEvent":{"action":"show_text","value":"§9左键此处传送至§d『紫晶洞穴』"}}]
execute if entity @a[tag=player_1,tag=2_point] run tellraw @p [{"text":"§b『水之圣殿』","clickEvent":{"action":"run_command","value":"/tp @s -824 100 1002"},"hoverEvent":{"action":"show_text","value":"§9左键此处传送至§b『水之圣殿』"}}]
execute if entity @a[tag=player_1,tag=3_point] run tellraw @p "23333"
execute if entity @a[tag=player_1,tag=4_point] run tellraw @p "23333"
execute if entity @a[tag=player_1,tag=5_point] run tellraw @p "23333"
execute if entity @a[tag=player_1,tag=6_point] run tellraw @p "23333"
execute if entity @a[tag=player_1,tag=7_point] run tellraw @p "23333"
execute if entity @a[tag=player_1,tag=8_point] run tellraw @p "23333"

data remove entity @s interaction
scoreboard players set @s detect_right1 0


scoreboard players add @s temp1 1
scoreboard players operation @s temp2 = @s temp1
scoreboard players set @s temp3 2
scoreboard players operation @s temp2 %= @s temp3

execute if entity @s[scores={temp2=0}] run data merge entity @e[limit=1,sort=nearest,tag=tp_point_block] {transformation:{left_rotation:[0.8f,0.6f,0.0f,0.0f]},start_interpolation:0,interpolation_duration:12}

execute if entity @s[scores={temp2=1}] run data merge entity @e[limit=1,sort=nearest,tag=tp_point_block] {transformation:{left_rotation:[0.0f,0.8f,0.6f,0.0f]},start_interpolation:0,interpolation_duration:12}

playsound ambient.nether_wastes.additions block @s

function y_other:teleport/tp_particle

