$data modify block ~ ~-1 ~ Items[0].tag.display.Name set value "[\"§$(input)\"]"
