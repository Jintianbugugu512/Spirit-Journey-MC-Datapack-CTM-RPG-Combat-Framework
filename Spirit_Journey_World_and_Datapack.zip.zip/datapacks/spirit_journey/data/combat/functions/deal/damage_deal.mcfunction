
#执行者为将要受到伤害的实体,在{"rate":"伤害倍率","type":"伤害类型","player":"造成伤害的玩家","interval":"cactus/generic"}下调用该函数.

#interval_stick用于管理所有攻击间隔
#$execute store result storage damage:$(player) rate float 1 data
execute store result score @s interval_stick run data get entity @s PortalCooldown
execute if score @s interval_stick matches 1.. run return 2

$data modify storage damage:$(player) rate set value $(rate)
$data merge storage damage:$(player) {interval:"$(interval)"}
$function combat:damage_type/$(type)_damage with storage damage:$(player)

#设置一下间隔
data modify entity @s PortalCooldown set value 2


