
$execute store result score @s attack_damage run attribute @s generic.attack_speed get $(rate)
execute store result storage input:damage damage int 1 run scoreboard players get @s attack_damage
#attack_box为以蝌蚪制成的3X3碰撞箱.
$execute as @e[tag=bullet_from_player] at @s run execute as @e[tag=enemy,distance=..$(radius),type=!text_display,nbt={HurtTime:10s}] at @s run function combat:damage_type/$(type)_damage with storage input:damage
#execute as @e[tag=attack_box] at @s run say 2333