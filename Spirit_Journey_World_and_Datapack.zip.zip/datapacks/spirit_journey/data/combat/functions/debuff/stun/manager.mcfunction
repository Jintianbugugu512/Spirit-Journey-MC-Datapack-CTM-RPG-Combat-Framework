# ==========================================
# 眩晕效果管理
# 眩晕期间禁用AI，显示粒子效果
# 执行者：entity_manager
# ==========================================

# 眩晕期间禁用AI
execute as @e[tag=enemy,scores={stun=1..}] run data modify entity @s NoAI set value 1b

# 恢复AI（stun <= 1）
execute as @e[tag=enemy,scores={stun=..1}] run data modify entity @s NoAI set value 0b

# 眩晕粒子效果
execute as @e[tag=enemy,scores={stun=1..}] at @s run particle effect ~ ~2 ~ 0.2 0.1 0.2 0 2

# 眩晕时间递减（每次减2）
scoreboard players remove @e[tag=enemy,scores={stun=1..}] stun 2
