scoreboard players operation #burn_damage fire = @s fire
scoreboard players set #burn_damage temp 15
scoreboard players operation #burn_damage fire %= #burn_damage temp
execute if score #burn_damage fire matches 0 run scoreboard players remove @s current_health 3