# ==========================================
# 燃烧伤害管理
# 从实体NBT读取Fire值，每15tick造成伤害
# 执行者：entity_manager
# ==========================================

# 读取所有敌人的燃烧状态到计分板（必须每tick执行，因为Fire是原生机制）
execute as @e[tag=enemy] run execute store result score @s fire run data get entity @s Fire

# 对燃烧中的敌人造成伤害
execute as @e[tag=enemy,scores={fire=1..}] run function combat:debuff/burn/tick
