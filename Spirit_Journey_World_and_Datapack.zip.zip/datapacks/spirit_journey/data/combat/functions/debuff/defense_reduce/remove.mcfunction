# ==========================================
# 恢复减防效果
# 将之前减少的防御值加回来
# 执行者：敌人实体
# ==========================================

# 恢复防御
scoreboard players operation @s physical_armor += @s defense_reduced_value

# 清除记录的减少值
scoreboard players set @s defense_reduced_value 0

# 视觉反馈（恢复效果）
particle scrape ~ ~1 ~ 0.3 0.5 0.3 0.1 15 force
particle wax_on ~ ~1 ~ 0.3 0.5 0.3 0.1 15 force
playsound block.anvil.use player @a ~ ~ ~ 0.5 1.5

# 显示恢复提示
summon text_display ~ ~2.1 ~ {text:'"§9§l破防buff结束"',Tags:["defense_text","MP_shower_"],billboard:center,background:1942251,see_through:true}
scoreboard players set @e[tag=defense_text,limit=1,sort=nearest] countDown 40
tag @e[tag=defense_text] remove defense_text
