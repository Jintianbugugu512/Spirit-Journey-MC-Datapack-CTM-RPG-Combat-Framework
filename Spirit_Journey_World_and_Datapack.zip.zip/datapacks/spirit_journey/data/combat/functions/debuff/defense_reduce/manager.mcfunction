# ==========================================
# 减防Buff管理
# 每tick递减持续时间，时间到时恢复防御
# 执行者：entity_manager
# ==========================================

# 首次获得减防效果时（duration刚被设置，但defense_reduced_value还是0或未设置）
execute as @e[tag=enemy,scores={defense_reduce_duration=1..}] unless score @s defense_reduced_value matches 1.. at @s run function combat:debuff/defense_reduce/apply

# 持续时间递减
scoreboard players remove @e[tag=enemy,scores={defense_reduce_duration=1..}] defense_reduce_duration 1

# 持续时间到期，恢复防御
execute as @e[tag=enemy,scores={defense_reduce_duration=0,defense_reduced_value=1..}] at @s run function combat:debuff/defense_reduce/remove

# 持续期间的视觉效果（每10tick显示一次破甲效果）
execute as @e[tag=enemy,scores={defense_reduce_duration=1..}] at @s if score @s defense_reduce_duration matches 0 run particle damage_indicator ~ ~1 ~ 0.2 0.3 0.2 0 2 force
execute as @e[tag=enemy,scores={defense_reduce_duration=1..}] at @s if score @s defense_reduce_duration matches 10 run particle damage_indicator ~ ~1 ~ 0.2 0.3 0.2 0 2 force
execute as @e[tag=enemy,scores={defense_reduce_duration=1..}] at @s if score @s defense_reduce_duration matches 20 run particle damage_indicator ~ ~1 ~ 0.2 0.3 0.2 0 2 force
execute as @e[tag=enemy,scores={defense_reduce_duration=1..}] at @s if score @s defense_reduce_duration matches 30 run particle damage_indicator ~ ~1 ~ 0.2 0.3 0.2 0 2 force
execute as @e[tag=enemy,scores={defense_reduce_duration=1..}] at @s if score @s defense_reduce_duration matches 40 run particle damage_indicator ~ ~1 ~ 0.2 0.3 0.2 0 2 force
execute as @e[tag=enemy,scores={defense_reduce_duration=1..}] at @s if score @s defense_reduce_duration matches 50 run particle damage_indicator ~ ~1 ~ 0.2 0.3 0.2 0 2 force
execute as @e[tag=enemy,scores={defense_reduce_duration=1..}] at @s if score @s defense_reduce_duration matches 60 run particle damage_indicator ~ ~1 ~ 0.2 0.3 0.2 0 2 force
