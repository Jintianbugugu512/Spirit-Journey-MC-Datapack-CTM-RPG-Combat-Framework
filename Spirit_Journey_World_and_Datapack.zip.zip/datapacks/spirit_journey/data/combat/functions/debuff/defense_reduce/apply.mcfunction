# ==========================================
# 应用减防效果
# 将敌人的物理防御减少50%
# 执行者：敌人实体
# ==========================================

# 计算减少的防御值（50% = physical_armor / 2）
scoreboard players operation @s defense_reduced_value = @s physical_armor
scoreboard players set #2 const 2
scoreboard players operation @s defense_reduced_value /= #2 const

# 减少防御
scoreboard players operation @s physical_armor -= @s defense_reduced_value

# 视觉反馈（破甲效果）
particle crit ~ ~1 ~ 0.3 0.6 0.3 0.1 80 force
playsound entity.item.break player @a ~ ~ ~ 1 0.5

# 显示减少的防御值
summon text_display ~ ~2.1 ~ {Tags:["defense_text","MP_shower_"],billboard:center,background:1942251,see_through:true}
scoreboard players operation @e[tag=defense_text,limit=1,sort=nearest] defense_reduced_value = @s defense_reduced_value
execute as @e[tag=defense_text,limit=1,sort=nearest] run data modify entity @s text set value '[{"text":"物理防御-","color":"red","bold":true},{"score":{"name":"@s","objective":"defense_reduced_value"},"color":"red","bold":true}]'
scoreboard players set @e[tag=defense_text,limit=1,sort=nearest] countDown 40
tag @e[tag=defense_text] remove defense_text
