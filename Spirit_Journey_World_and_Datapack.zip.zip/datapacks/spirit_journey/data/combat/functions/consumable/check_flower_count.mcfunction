# ==========================================
# 消耗品携带数量检测
# 功能：检测玩家携带的火把花和瓶子草数量
# 超过最大携带量时给予中毒效果并提示
# 在合理范围内右键使用时调用回血/回蓝功能
# ==========================================

# ==================== 火把花（回血道具）检测 ====================

# 检测玩家携带的火把花数量
execute store result score @s red_Flower run clear @s torchflower 0

# 超过最大携带量：中毒提示
execute if score @s red_Flower > @s max_Flower run title @s actionbar "§4『你的身体抗性无法携带那么多火把花!扔掉几个吧.』"
execute if score @s red_Flower > @s max_Flower run effect give @s[scores={interval_pos_record=9}] poison 1 1 true

# 在合理范围内且右键使用：调用回血功能
execute if score @s red_Flower <= @s max_Flower if entity @a[tag=right_click,scores={red_Flower=1..}] run function y_other:prop/torchflower_

# ==================== 瓶子草（回蓝道具）检测 ====================

# 检测玩家携带的瓶子草数量
execute store result score @s blue_Flower run clear @s pitcher_plant 0

# 超过最大携带量：中毒提示
execute if score @s blue_Flower > @s max_Flower run title @s actionbar "§4『你的身体抗性无法携带那么多瓶子草!扔掉几个吧.』"
execute if score @s blue_Flower > @s max_Flower run effect give @s[scores={interval_pos_record=9}] poison 1 1 true

# 在合理范围内且右键使用：调用回蓝功能
execute if score @s blue_Flower <= @s max_Flower if entity @a[tag=right_click,scores={blue_Flower=1..}] run function y_other:prop/pitcher_plant_
