# ==========================================
# 消耗品与战斗系统管理
# 功能：
#   1. 火把花踩踏回血检测
#   2. 瓶子草踩踏回蓝检测
#   3. 消耗品携带数量检测
# ==========================================

# ==================== 消耗品踩踏检测 ====================

# 火把花回血（踩在火把花上时潜行触发）
execute as @a[scores={put_shift=1..}] at @s if block ~ ~ ~ torchflower run function y_other:prop/torchflower

# 瓶子草回蓝（踩在瓶子草上时潜行触发）
execute as @a[scores={put_shift=1..}] at @s if block ~ ~ ~ pitcher_plant run function y_other:prop/pitcher_plant

# ==================== 消耗品携带数量检测 ====================

# 检测火把花和瓶子草的携带数量，超量则中毒
execute as @a at @s run function combat:consumable/check_flower_count

