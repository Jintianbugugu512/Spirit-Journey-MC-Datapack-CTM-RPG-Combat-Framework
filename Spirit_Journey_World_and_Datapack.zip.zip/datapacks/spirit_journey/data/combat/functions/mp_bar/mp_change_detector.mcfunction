# ==========================================
# MP变化检测
# 只有当MP的十位数变化时（方块数量变化）才更新显示
# ==========================================

# 计算当前MP的十位数（MP / 10）
scoreboard players operation @s temp = @s MP
scoreboard players set #10 const 10
scoreboard players operation @s temp /= #10 const

# 对比当前十位数与上次记录的十位数
# 只有不相等时才更新显示
execute unless score @s temp = @s MP_last run function combat:mp_bar/calculate_mp

# 更新记录的十位数值
scoreboard players operation @s MP_last = @s temp
