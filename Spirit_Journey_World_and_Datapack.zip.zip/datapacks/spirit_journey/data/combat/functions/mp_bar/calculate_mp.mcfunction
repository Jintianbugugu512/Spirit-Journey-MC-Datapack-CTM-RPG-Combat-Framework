# ==========================================
# MP条计算与显示
# 用实心方块(■)表示已有MP，空心方块(□)表示缺少的MP
# 每10点MP显示一个方块，总共10个方块
# max_MP固定为100
# ==========================================

# 计算已有的MP方块数量（MP / 10）
scoreboard players operation @s temp = @s MP
scoreboard players set #10 const 10
scoreboard players operation @s temp /= #10 const

# 根据temp的值（0-10）显示对应的MP条
execute if score @s temp matches 0 run title @s actionbar [{"text":"□□□□□□□□□□","color":"dark_gray"}]
execute if score @s temp matches 1 run title @s actionbar [{"text":"■","color":"blue"},{"text":"□□□□□□□□□","color":"dark_gray"}]
execute if score @s temp matches 2 run title @s actionbar [{"text":"■■","color":"blue"},{"text":"□□□□□□□□","color":"dark_gray"}]
execute if score @s temp matches 3 run title @s actionbar [{"text":"■■■","color":"blue"},{"text":"□□□□□□□","color":"dark_gray"}]
execute if score @s temp matches 4 run title @s actionbar [{"text":"■■■■","color":"blue"},{"text":"□□□□□□","color":"dark_gray"}]
execute if score @s temp matches 5 run title @s actionbar [{"text":"■■■■■","color":"blue"},{"text":"□□□□□","color":"dark_gray"}]
execute if score @s temp matches 6 run title @s actionbar [{"text":"■■■■■■","color":"blue"},{"text":"□□□□","color":"dark_gray"}]
execute if score @s temp matches 7 run title @s actionbar [{"text":"■■■■■■■","color":"blue"},{"text":"□□□","color":"dark_gray"}]
execute if score @s temp matches 8 run title @s actionbar [{"text":"■■■■■■■■","color":"blue"},{"text":"□□","color":"dark_gray"}]
execute if score @s temp matches 9 run title @s actionbar [{"text":"■■■■■■■■■","color":"blue"},{"text":"□","color":"dark_gray"}]
execute if score @s temp matches 10.. run title @s actionbar [{"text":"■■■■■■■■■■","color":"blue"}]

