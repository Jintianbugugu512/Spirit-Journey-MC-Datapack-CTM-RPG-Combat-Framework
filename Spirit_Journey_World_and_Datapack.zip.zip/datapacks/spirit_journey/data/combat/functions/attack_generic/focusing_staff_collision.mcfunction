# 凝杖能量球碰撞检测和伤害计算
# 执行者：已发射的光灵箭
# 根据箭矢的 temp 值（蓄力时间）计算伤害倍率

# 检测周围是否有敌人
execute if entity @e[tag=enemy,distance=..2.4] run function combat:attack_generic/focusing_staff_damage
