#execute as @a[scores={use_NetheriteSword=1..}] at @s run

# 蜕变挽歌魂盘效果：满血时挥剑触发剑气
$execute if entity @s[nbt={Inventory:[{tag:{sd_id:"蜕变挽歌"}}]}] run function soul_disc:metamorphosis/check_full_hp with storage damage:$(player)

# 释放剑气
$execute if score @s sword_light_count matches 1.. run function skill:sword_skill/sword_light/light with storage damage:$(player)
execute if score @s sword_light_count matches 1.. run scoreboard players remove @s sword_light_count 1

# 刺剑攻击逻辑
# 第一刀：造成70%倍率伤害
$execute as @e[distance=..6,tag=enemy,nbt={HurtTime:10s},limit=1] at @s run function combat:deal/damage_deal {"rate":"70","type":"physic","player":"$(player)","interval":"cactus"}

# 设置连击计时器（8tick，每2tick触发一次，共4次）
scoreboard players set @s rapier_combo 8

scoreboard players add @s MP 4
scoreboard players reset @s use_NetheriteSword