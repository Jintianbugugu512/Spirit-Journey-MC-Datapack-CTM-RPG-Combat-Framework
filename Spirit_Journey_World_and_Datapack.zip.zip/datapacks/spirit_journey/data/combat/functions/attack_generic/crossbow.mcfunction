$execute anchored eyes as @e[type=arrow,limit=1,sort=nearest] at @s run function combat:attack_generic/crossbow_ with storage damage:$(player)

scoreboard players reset @s use_Crossbow