# 连弩爆炸伤害（精准射击 - 近距离5格内）
# 随机造成 30%-80% 物理伤害（每2%一档，共26档）
# 对最近最多3名敌人

# 爆炸粒子效果
particle explosion ~ ~0.4 ~ 0.0 0.0 0.0 0.0 1

# 随机伤害倍率（1-26对应30%-80%，每2%递增）
execute store result score @s temp run random value 1..26

# 对最近最多3名敌人造成伤害
execute if entity @s[scores={temp=1}] as @e[tag=enemy,distance=..2.5,limit=3,sort=nearest] run function combat:deal/damage_deal {"rate":"30","type":"physic","player":"player_1","interval":"generic"}
execute if entity @s[scores={temp=2}] as @e[tag=enemy,distance=..2.5,limit=3,sort=nearest] run function combat:deal/damage_deal {"rate":"32","type":"physic","player":"player_1","interval":"generic"}
execute if entity @s[scores={temp=3}] as @e[tag=enemy,distance=..2.5,limit=3,sort=nearest] run function combat:deal/damage_deal {"rate":"34","type":"physic","player":"player_1","interval":"generic"}
execute if entity @s[scores={temp=4}] as @e[tag=enemy,distance=..2.5,limit=3,sort=nearest] run function combat:deal/damage_deal {"rate":"36","type":"physic","player":"player_1","interval":"generic"}
execute if entity @s[scores={temp=5}] as @e[tag=enemy,distance=..2.5,limit=3,sort=nearest] run function combat:deal/damage_deal {"rate":"38","type":"physic","player":"player_1","interval":"generic"}
execute if entity @s[scores={temp=6}] as @e[tag=enemy,distance=..2.5,limit=3,sort=nearest] run function combat:deal/damage_deal {"rate":"40","type":"physic","player":"player_1","interval":"generic"}
execute if entity @s[scores={temp=7}] as @e[tag=enemy,distance=..2.5,limit=3,sort=nearest] run function combat:deal/damage_deal {"rate":"42","type":"physic","player":"player_1","interval":"generic"}
execute if entity @s[scores={temp=8}] as @e[tag=enemy,distance=..2.5,limit=3,sort=nearest] run function combat:deal/damage_deal {"rate":"44","type":"physic","player":"player_1","interval":"generic"}
execute if entity @s[scores={temp=9}] as @e[tag=enemy,distance=..2.5,limit=3,sort=nearest] run function combat:deal/damage_deal {"rate":"46","type":"physic","player":"player_1","interval":"generic"}
execute if entity @s[scores={temp=10}] as @e[tag=enemy,distance=..2.5,limit=3,sort=nearest] run function combat:deal/damage_deal {"rate":"48","type":"physic","player":"player_1","interval":"generic"}
execute if entity @s[scores={temp=11}] as @e[tag=enemy,distance=..2.5,limit=3,sort=nearest] run function combat:deal/damage_deal {"rate":"50","type":"physic","player":"player_1","interval":"generic"}
execute if entity @s[scores={temp=12}] as @e[tag=enemy,distance=..2.5,limit=3,sort=nearest] run function combat:deal/damage_deal {"rate":"52","type":"physic","player":"player_1","interval":"generic"}
execute if entity @s[scores={temp=13}] as @e[tag=enemy,distance=..2.5,limit=3,sort=nearest] run function combat:deal/damage_deal {"rate":"54","type":"physic","player":"player_1","interval":"generic"}
execute if entity @s[scores={temp=14}] as @e[tag=enemy,distance=..2.5,limit=3,sort=nearest] run function combat:deal/damage_deal {"rate":"56","type":"physic","player":"player_1","interval":"generic"}
execute if entity @s[scores={temp=15}] as @e[tag=enemy,distance=..2.5,limit=3,sort=nearest] run function combat:deal/damage_deal {"rate":"58","type":"physic","player":"player_1","interval":"generic"}
execute if entity @s[scores={temp=16}] as @e[tag=enemy,distance=..2.5,limit=3,sort=nearest] run function combat:deal/damage_deal {"rate":"60","type":"physic","player":"player_1","interval":"generic"}
execute if entity @s[scores={temp=17}] as @e[tag=enemy,distance=..2.5,limit=3,sort=nearest] run function combat:deal/damage_deal {"rate":"62","type":"physic","player":"player_1","interval":"generic"}
execute if entity @s[scores={temp=18}] as @e[tag=enemy,distance=..2.5,limit=3,sort=nearest] run function combat:deal/damage_deal {"rate":"64","type":"physic","player":"player_1","interval":"generic"}
execute if entity @s[scores={temp=19}] as @e[tag=enemy,distance=..2.5,limit=3,sort=nearest] run function combat:deal/damage_deal {"rate":"66","type":"physic","player":"player_1","interval":"generic"}
execute if entity @s[scores={temp=20}] as @e[tag=enemy,distance=..2.5,limit=3,sort=nearest] run function combat:deal/damage_deal {"rate":"68","type":"physic","player":"player_1","interval":"generic"}
execute if entity @s[scores={temp=21}] as @e[tag=enemy,distance=..2.5,limit=3,sort=nearest] run function combat:deal/damage_deal {"rate":"70","type":"physic","player":"player_1","interval":"generic"}
execute if entity @s[scores={temp=22}] as @e[tag=enemy,distance=..2.5,limit=3,sort=nearest] run function combat:deal/damage_deal {"rate":"72","type":"physic","player":"player_1","interval":"generic"}
execute if entity @s[scores={temp=23}] as @e[tag=enemy,distance=..2.5,limit=3,sort=nearest] run function combat:deal/damage_deal {"rate":"74","type":"physic","player":"player_1","interval":"generic"}
execute if entity @s[scores={temp=24}] as @e[tag=enemy,distance=..2.5,limit=3,sort=nearest] run function combat:deal/damage_deal {"rate":"76","type":"physic","player":"player_1","interval":"generic"}
execute if entity @s[scores={temp=25}] as @e[tag=enemy,distance=..2.5,limit=3,sort=nearest] run function combat:deal/damage_deal {"rate":"78","type":"physic","player":"player_1","interval":"generic"}
execute if entity @s[scores={temp=26}] as @e[tag=enemy,distance=..2.5,limit=3,sort=nearest] run function combat:deal/damage_deal {"rate":"80","type":"physic","player":"player_1","interval":"generic"}

# 给玩家回复 8 MP
$scoreboard players add @a[tag=$(player)] MP 2

# 删除箭矢
kill @s
