execute if entity @s[scores={interval_stick=1..}] run scoreboard players reset @s use_Stick
execute if entity @s[scores={interval_stick=1..}] run return 0

execute positioned 0.0 0.0 0.0 run summon armor_stand ^ ^ ^2 {Tags:["mmark_"],NoGravity:1b}
#execute anchored eyes run summon llama_spit ^ ^ ^1 {NoGravity:1b,Tags:["stick_bullet","count__",],Passengers:[{id:"minecraft:item_display",item:{id:"ender_pearl",Count:1b},Tags:["bomb"]}]}
execute store result storage sj:other motion_x double 0.0000001 run data get entity @e[limit=1,tag=mmark_] Pos[0] 10000000
execute store result storage sj:other motion_y double 0.0000001 run data get entity @e[limit=1,tag=mmark_] Pos[1] 10000000
execute store result storage sj:other motion_z double 0.0000001 run data get entity @e[limit=1,tag=mmark_] Pos[2] 10000000

function combat:attack_generic/shot with storage sj:other
execute as @e[tag=count__] run data modify entity @s Motion set from entity @e[limit=1,tag=mmark_] Pos
kill @e[tag=mmark_,type=armor_stand]
scoreboard players set @e[type=llama_spit,tag=count__] countDown 4
tag @e[type=llama_spit,tag=count__] remove count__

scoreboard players reset @s use_Stick
scoreboard players set @s interval_stick 15
execute if entity @s[nbt={Inventory:[{tag:{sd_id:"迅捷之杖"}}]},tag=!overload] run scoreboard players set @s interval_stick 11

