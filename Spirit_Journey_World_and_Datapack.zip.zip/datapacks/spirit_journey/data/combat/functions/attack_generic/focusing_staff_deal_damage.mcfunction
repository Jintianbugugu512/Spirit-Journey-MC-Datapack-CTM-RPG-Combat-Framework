# 凝杖造成魔法伤害
# 通过 storage 传递 rate 参数

# 对最近的敌人造成伤害（不检测 interval_stick）
$execute as @e[tag=enemy,distance=..2.5,limit=1,sort=nearest] run function combat:deal/damage_deal {"rate":"$(rate)","type":"magic","player":"player_1","interval":"generic"}

# 获取射手信息（如果需要回复MP）
execute on origin run scoreboard players add @s MP 4
execute on origin if entity @s[tag=enemy,tag=boss] run scoreboard players add @a[distance=..50,limit=1,sort=nearest] MP 4
