execute store result score @s interval_stick run data get entity @s PortalCooldown
$execute if entity @s[scores={interval_stick=..0},tag=!BOSS] run scoreboard players add @a[tag=$(player)] MP 2
$execute if entity @s[scores={interval_stick=..0},tag=BOSS] run scoreboard players add @a[tag=$(player)] MP 4


