data modify entity @s damage set value -99
data modify entity @s crit set value 0
data modify entity @s PierceLevel set value 2

tag @s add bullet_from_crossbow

# execute as @e[tag=bullet_from_player,limit=1] at @s if entity @e[tag=enemy,distance=..2.5] on origin run function combat:deal/bow_damage_deal {"rate":"1.5","type":"physical","radius":"3"}
# execute as @e[tag=bullet_from_player] at @s if entity @e[tag=enemy,distance=..2.5,nbt={HurtTime:10s}] run kill @s