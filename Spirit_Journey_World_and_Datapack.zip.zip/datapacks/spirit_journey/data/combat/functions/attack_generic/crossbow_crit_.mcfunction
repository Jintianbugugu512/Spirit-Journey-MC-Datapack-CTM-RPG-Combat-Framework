execute store result score @s temp run random value 1..10
execute if entity @s[scores={temp=1..3}] run execute as @e[tag=enemy,distance=..2.5,limit=1,sort=nearest] run function combat:deal/damage_deal {"rate":"375","type":"physic","player":"player_1","interval":"generic"}
execute if entity @s[scores={temp=1..3}] run particle crit ~ ~0.4 ~ 0.6 0.5 0.6 0.4 20


execute if entity @s[scores={temp=4..10}] run execute as @e[tag=enemy,distance=..2.5,limit=1,sort=nearest] run function combat:deal/damage_deal {"rate":"150","type":"physic","player":"player_1","interval":"generic"}

$execute as @e[tag=enemy,distance=..2.5,limit=1,sort=nearest] run damage @s 0 minecraft:cactus by @a[limit=1,tag=$(player)]
$scoreboard players add @a[tag=$(player)] MP 8

kill @s
