# 凝杖能量球发射
# 执行者：玩家
# 参数：player - 玩家标签

# 检测发射间隔，如果还在冷却中则阻止发射
execute if entity @s[scores={interval_stick=1..}] run scoreboard players reset @s use_Stick_
execute if entity @s[scores={interval_stick=1..}] run return 0

# 在玩家眼前召唤光灵箭
$execute anchored eyes run summon spectral_arrow ^ ^ ^2 {Tags:["focusing_spit_launched","focusing_spit_$(player)","focusing_spit_new"],NoGravity:1b,damage:-99d,life:120}

# 复制玩家的蓄力值到光灵箭的temp
$scoreboard players operation @e[tag=focusing_spit_new,limit=1] temp = @a[tag=$(player),limit=1] charge_of_stick

# 给予固定动量（朝玩家所指方向发射）
# 使用 data modify 从玩家的 Rotation 计算方向
execute anchored eyes positioned ^ ^ ^3 run summon marker ~ ~ ~ {Tags:["motion_helper"]}
execute as @e[tag=focusing_spit_new,limit=1] at @s facing entity @e[tag=motion_helper,limit=1] feet run tp @s ~ ~ ~ ~ ~
execute as @e[tag=focusing_spit_new,limit=1] at @s run tp @s ^ ^ ^1
execute store result score #x temp run data get entity @e[tag=focusing_spit_new,limit=1] Pos[0] 1000
execute store result score #y temp run data get entity @e[tag=focusing_spit_new,limit=1] Pos[1] 1000
execute store result score #z temp run data get entity @e[tag=focusing_spit_new,limit=1] Pos[2] 1000
execute as @e[tag=focusing_spit_new,limit=1] at @s run tp @s ^ ^ ^-1
execute store result score #x2 temp run data get entity @e[tag=focusing_spit_new,limit=1] Pos[0] 1000
execute store result score #y2 temp run data get entity @e[tag=focusing_spit_new,limit=1] Pos[1] 1000
execute store result score #z2 temp run data get entity @e[tag=focusing_spit_new,limit=1] Pos[2] 1000
scoreboard players operation #x temp -= #x2 temp
scoreboard players operation #y temp -= #y2 temp
scoreboard players operation #z temp -= #z2 temp
execute store result entity @e[tag=focusing_spit_new,limit=1] Motion[0] double 0.001 run scoreboard players get #x temp
execute store result entity @e[tag=focusing_spit_new,limit=1] Motion[1] double 0.001 run scoreboard players get #y temp
execute store result entity @e[tag=focusing_spit_new,limit=1] Motion[2] double 0.001 run scoreboard players get #z temp

# 清理辅助实体
kill @e[tag=motion_helper]

# 移除临时标签
tag @e[tag=focusing_spit_new] remove focusing_spit_new

# 清零玩家蓄力值
scoreboard players reset @s charge_of_stick

# 重置玩家的 use_Stick_
scoreboard players reset @s use_Stick_

# 设置发射间隔（10tick）
scoreboard players set @s interval_stick 10
