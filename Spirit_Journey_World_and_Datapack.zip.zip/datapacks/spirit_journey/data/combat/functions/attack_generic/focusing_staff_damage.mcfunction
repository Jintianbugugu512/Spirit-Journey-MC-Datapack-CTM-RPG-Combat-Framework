# 凝杖能量球伤害计算
# 执行者：已发射的光灵箭
# 根据 temp 值计算伤害倍率（1%-350%）

# temp 0-200 对应 1%-350%
# 10秒蓄力时间（200 tick）
# 使用公式：damage = 1 + (temp * 349 / 200) = 1 + (temp * 1.745)

# 计算伤害倍率
scoreboard players set #base temp 1
scoreboard players set #multiplier temp 349
scoreboard players operation #damage temp = @s temp
scoreboard players operation #damage temp *= #multiplier temp
scoreboard players set #divisor temp 200
scoreboard players operation #damage temp /= #divisor temp
scoreboard players operation #damage temp += #base temp

# 对最近的敌人造成魔法伤害
execute store result storage damage:temp rate int 1 run scoreboard players get #damage temp
function combat:attack_generic/focusing_staff_deal_damage with storage damage:temp

# 爆炸粒子效果 - 紫水晶方块破碎向四周爆裂（在敌人位置）
execute as @e[tag=enemy,distance=..2.5,limit=1,sort=nearest] at @s run particle block amethyst_block ~ ~1 ~ 0.5 0.5 0.5 0.3 50
execute as @e[tag=enemy,distance=..2.5,limit=1,sort=nearest] at @s run particle block amethyst_cluster ~ ~1 ~ 0.6 0.6 0.6 0.2 30

# 删除箭矢
kill @s
