# 凝杖蓄力粒子效果
# 执行者：玩家
# 在玩家眼前显示紫色粒子
# 参数：player - 玩家标签



# 10秒蓄力（200 tick），前2秒无粒子（0-40 tick）
$execute if score @a[tag=$(player),limit=1] charge_of_stick matches 31..60 anchored eyes positioned ^ ^-0.6 ^2 run particle dust 0.8 0.2 1.0 1.0 ~ ~ ~ 0.1 0.1 0.1 0.01 1
$execute if score @a[tag=$(player),limit=1] charge_of_stick matches 61..80 anchored eyes positioned ^ ^-0.6 ^2 run particle dust 0.8 0.2 1.0 1.0 ~ ~ ~ 0.08 0.08 0.08 0.01 2
$execute if score @a[tag=$(player),limit=1] charge_of_stick matches 81..100 anchored eyes positioned ^ ^-0.6 ^2 run particle dust 0.8 0.2 1.0 1.0 ~ ~ ~ 0.06 0.06 0.06 0.01 3
$execute if score @a[tag=$(player),limit=1] charge_of_stick matches 101..130 anchored eyes positioned ^ ^-0.6 ^2 run particle dust 0.8 0.2 1.0 1.0 ~ ~ ~ 0.05 0.05 0.05 0.01 4
$execute if score @a[tag=$(player),limit=1] charge_of_stick matches 131..160 anchored eyes positioned ^ ^-0.6 ^2 run particle dust 0.8 0.2 1.0 1.0 ~ ~ ~ 0.05 0.05 0.05 0.01 5
$execute if score @a[tag=$(player),limit=1] charge_of_stick matches 161..199 anchored eyes positioned ^ ^-0.6 ^2 run particle dust 0.8 0.2 1.0 1.0 ~ ~ ~ 0.05 0.05 0.05 0.01 6

# 满蓄力特效（200 tick）- 紫色粒子
$execute if score @a[tag=$(player),limit=1] charge_of_stick matches 200 anchored eyes positioned ^ ^-0.6 ^2 run particle dust 0.8 0.2 1.0 1.0 ~ ~ ~ 0.05 0.05 0.05 0.01 6


