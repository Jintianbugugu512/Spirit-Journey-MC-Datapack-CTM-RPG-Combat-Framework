#execute as @a[scores={use_IronSword=1..}] at @s run

# 蜕变挽歌魂盘效果：满血时挥剑触发剑气
$execute if entity @s[nbt={Inventory:[{tag:{sd_id:"蜕变挽歌"}}]}] run function soul_disc:metamorphosis/check_full_hp with storage damage:$(player)

$execute if score @s sword_light_count matches 1.. run function skill:sword_skill/sword_light/light with storage damage:$(player)
execute if score @s sword_light_count matches 1.. run scoreboard players remove @s sword_light_count 1


$execute as @e[distance=..6,tag=enemy,nbt={HurtTime:10s},limit=1] at @s run function combat:deal/damage_deal {"rate":"100","type":"physic","player":"$(player)","interval":"cactus"}
scoreboard players add @s MP 4
scoreboard players reset @s use_IronSword