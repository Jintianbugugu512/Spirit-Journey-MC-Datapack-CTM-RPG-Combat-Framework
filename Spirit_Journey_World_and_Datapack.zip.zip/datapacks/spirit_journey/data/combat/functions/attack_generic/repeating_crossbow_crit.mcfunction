# 连弩爆炸伤害（无精准射击）
# 随机造成 30%-50% 物理伤害（每2%一档，共11档）
# 对最近最多3名敌人

# 爆炸粒子效果
particle explosion ~ ~0.4 ~ 0.0 0.0 0.0 0.0 1

# 随机伤害倍率（1-11对应30%-50%，每2%递增）
execute store result score @s temp run random value 1..11

# 对最近最多3名敌人造成伤害
execute if entity @s[scores={temp=1}] as @e[tag=enemy,distance=..2.5,limit=3,sort=nearest] run function combat:deal/damage_deal {"rate":"30","type":"physic","player":"player_1","interval":"generic"}
execute if entity @s[scores={temp=2}] as @e[tag=enemy,distance=..2.5,limit=3,sort=nearest] run function combat:deal/damage_deal {"rate":"32","type":"physic","player":"player_1","interval":"generic"}
execute if entity @s[scores={temp=3}] as @e[tag=enemy,distance=..2.5,limit=3,sort=nearest] run function combat:deal/damage_deal {"rate":"34","type":"physic","player":"player_1","interval":"generic"}
execute if entity @s[scores={temp=4}] as @e[tag=enemy,distance=..2.5,limit=3,sort=nearest] run function combat:deal/damage_deal {"rate":"36","type":"physic","player":"player_1","interval":"generic"}
execute if entity @s[scores={temp=5}] as @e[tag=enemy,distance=..2.5,limit=3,sort=nearest] run function combat:deal/damage_deal {"rate":"38","type":"physic","player":"player_1","interval":"generic"}
execute if entity @s[scores={temp=6}] as @e[tag=enemy,distance=..2.5,limit=3,sort=nearest] run function combat:deal/damage_deal {"rate":"40","type":"physic","player":"player_1","interval":"generic"}
execute if entity @s[scores={temp=7}] as @e[tag=enemy,distance=..2.5,limit=3,sort=nearest] run function combat:deal/damage_deal {"rate":"42","type":"physic","player":"player_1","interval":"generic"}
execute if entity @s[scores={temp=8}] as @e[tag=enemy,distance=..2.5,limit=3,sort=nearest] run function combat:deal/damage_deal {"rate":"44","type":"physic","player":"player_1","interval":"generic"}
execute if entity @s[scores={temp=9}] as @e[tag=enemy,distance=..2.5,limit=3,sort=nearest] run function combat:deal/damage_deal {"rate":"46","type":"physic","player":"player_1","interval":"generic"}
execute if entity @s[scores={temp=10}] as @e[tag=enemy,distance=..2.5,limit=3,sort=nearest] run function combat:deal/damage_deal {"rate":"48","type":"physic","player":"player_1","interval":"generic"}
execute if entity @s[scores={temp=11}] as @e[tag=enemy,distance=..2.5,limit=3,sort=nearest] run function combat:deal/damage_deal {"rate":"50","type":"physic","player":"player_1","interval":"generic"}

# 给玩家回复 8 MP
$scoreboard players add @a[tag=$(player)] MP 2

# 删除箭矢
kill @s
