# 刺剑连击检测
# 每2tick触发一次随机刺击（每次60%倍率）

# 减少计时器
scoreboard players remove @s rapier_combo 1



# 每2tick执行一次（计时器为  4, 2, 0 时触发）


# 第1刺
$execute if score @s rapier_combo matches 4 at @s as @e[tag=enemy,distance=..5,sort=random,limit=1] at @s run tag @s add rapier_combo_object_$(player)
$execute if score @s rapier_combo matches 4 as @e[tag=rapier_combo_object_$(player)] at @s run function combat:deal/damage_deal {"rate":"60","type":"physic","player":"$(player)","interval":"generic"}
$execute if score @s rapier_combo matches 4 as @e[tag=rapier_combo_object_$(player)] at @s run particle sweep_attack ^ ^1 ^ 0.0 0.3 0.0 0.1 1
$tag @e[tag=rapier_combo_object_$(player)] remove rapier_combo_object_$(player)

# 第2刺
$execute if score @s rapier_combo matches 2 at @s as @e[tag=enemy,distance=..5,sort=random,limit=1] at @s run tag @s add rapier_combo_object_$(player)
$execute if score @s rapier_combo matches 2 as @e[tag=rapier_combo_object_$(player)] at @s run function combat:deal/damage_deal {"rate":"60","type":"physic","player":"$(player)","interval":"generic"}
$execute if score @s rapier_combo matches 2 as @e[tag=rapier_combo_object_$(player)] at @s run particle sweep_attack ^ ^1 ^ 0.0 0.3 0.0 0.1 1
$tag @e[tag=rapier_combo_object_$(player)] remove rapier_combo_object_$(player)

# 第3刺
$execute if score @s rapier_combo matches 0 at @s as @e[tag=enemy,distance=..5,sort=random,limit=1] at @s run tag @s add rapier_combo_object_$(player)
$execute if score @s rapier_combo matches 0 as @e[tag=rapier_combo_object_$(player)] at @s run function combat:deal/damage_deal {"rate":"60","type":"physic","player":"$(player)","interval":"generic"}
$execute if score @s rapier_combo matches 0 as @e[tag=rapier_combo_object_$(player)] at @s run particle sweep_attack ^ ^1 ^ 0.0 0.3 0.0 0.1 1
$tag @e[tag=rapier_combo_object_$(player)] remove rapier_combo_object_$(player)

# 结束连击
execute if score @s rapier_combo matches 0 run scoreboard players reset @s rapier_combo
$execute if score @s rapier_combo matches 0 run tag @e[tag=rapier_combo_object_$(player)] remove rapier_combo_object_$(player)
