# 凝杖发射后的箭矢粒子效果
# 执行者：已发射的光灵箭
# 根据箭矢自身的 temp 显示不同密度的紫色粒子

execute if score @s temp matches 1..20 run particle dust 0.8 0.2 1.0 1.0 ~ ~ ~ 0.08 0.08 0.08 0.01 2
execute if score @s temp matches 21..40 run particle dust 0.8 0.2 1.0 1.0 ~ ~ ~ 0.08 0.08 0.08 0.01 4
execute if score @s temp matches 41..60 run particle dust 0.8 0.2 1.0 1.0 ~ ~ ~ 0.08 0.08 0.08 0.01 6
execute if score @s temp matches 61..80 run particle dust 0.8 0.2 1.0 1.0 ~ ~ ~ 0.08 0.08 0.08 0.01 8
execute if score @s temp matches 81..100 run particle dust 0.8 0.2 1.0 1.0 ~ ~ ~ 0.08 0.08 0.08 0.01 10
execute if score @s temp matches 101..120 run particle dust 0.8 0.2 1.0 1.0 ~ ~ ~ 0.08 0.08 0.08 0.01 12
execute if score @s temp matches 121..140 run particle dust 0.8 0.2 1.0 1.0 ~ ~ ~ 0.08 0.08 0.08 0.01 14
execute if score @s temp matches 141.. run particle dust 0.8 0.2 1.0 1.0 ~ ~ ~ 0.09 0.09 0.09 0.015 16
execute if score @s temp matches 200.. run particle dust 0.8 0.2 1.0 1.0 ~ ~ ~ 0.1 0.1 0.1 0.02 16
