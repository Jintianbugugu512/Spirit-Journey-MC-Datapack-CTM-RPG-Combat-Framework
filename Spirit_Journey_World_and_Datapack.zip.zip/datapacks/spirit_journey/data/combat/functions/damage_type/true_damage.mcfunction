
#执行者为将要受到伤害的实体,在with damage:player_1 下调用该函数.

#$execute store result score @s temp run attribute @a[tag=$(player)] generic.attack_speed get $(rate)
$execute store result score @s temp run attribute @a[limit=1,tag=$(player)] generic.luck get
$scoreboard players set #rate temp $(rate)
scoreboard players operation @s temp *= #rate temp
scoreboard players set #hundred temp 100
scoreboard players operation @s temp /= #hundred temp

# 真实之眼魂盘效果：真实伤害+25%
$execute if entity @a[limit=1,tag=$(player),nbt={Inventory:[{tag:{sd_id:"真实之眼"}}]}] run scoreboard players set #true_eye_bonus temp 125
$execute unless entity @a[limit=1,tag=$(player),nbt={Inventory:[{tag:{sd_id:"真实之眼"}}]}] run scoreboard players set #true_eye_bonus temp 100
scoreboard players operation @s temp *= #true_eye_bonus temp
scoreboard players set #hundred temp 100
scoreboard players operation @s temp /= #hundred temp

# execute if score @s temp >= @s h1 run execute store result storage damage:damage damage_ int 0.01 run scoreboard players get @s h1
# execute if score @s temp >= @s h1 run execute if score @s h1 matches 1..100 run data modify storage damage:damage damage_ set value 1
# execute if score @s temp >= @s h1 run execute run function combat:healthbar/damage

execute if score @s temp matches ..1 run damage @s 1
execute if score @s temp matches ..1 run return 1

$execute store result storage damage:$(player) damage int 1 run scoreboard players get @s temp
$function combat:damage_type/pm_damage with storage damage:$(player)

