#执行者为将要受到伤害的实体,在with damage:player_1 下调用该函数.
#$damage @s $(damage) minecraft:$(interval)

# #闪避
# execute store result score #miss temp run random value 1..100

# execute if score #miss temp < @s dodge run execute at @s anchored eyes run summon text_display ~ ~2.1 ~ {text:'"§lmiss"',Tags:["miss_shower","damage_shower"],billboard:center,background:1942251,see_through:true}
# execute if score #miss temp < @s dodge run scoreboard players set @e[tag=miss_shower] countDown 10
# execute if score #miss temp < @s dodge run tag @e[tag=miss_shower] remove miss_shower
# execute if score #miss temp < @s dodge run return 2

#造成伤害
$scoreboard players remove @s current_health $(damage)
scoreboard players set @s[scores={current_health=..0}] current_health 0
damage @s 0 minecraft:cactus
