#魔法伤害计算公式：伤害 = 攻击力 - 魔抗
#若造成伤害<1,则造成1点保底伤害.

# 获取玩家攻击力
$execute store result score @s temp run attribute @a[limit=1,tag=$(player)] generic.luck get
$scoreboard players set #rate temp $(rate)
scoreboard players operation @s temp *= #rate temp
scoreboard players set #hundred temp 100
scoreboard players operation @s temp /= #hundred temp

# 减去魔抗：伤害 = 攻击力 - 魔抗
scoreboard players operation @s temp -= @s magic_resist

# 转换为百分比（乘以100用于后续计算）
scoreboard players set #test temp 100
scoreboard players operation @s temp *= #test temp

# 保底伤害：如果伤害<=1点
# 有"伤害修正"魂盘：保底2点伤害
$execute if score @s temp matches ..100 if entity @a[limit=1,tag=$(player),nbt={Inventory:[{tag:{sd_id:"伤害修正"}}]}] run damage @s 2 minecraft:cactus
$execute if score @s temp matches ..100 if entity @a[limit=1,tag=$(player),nbt={Inventory:[{tag:{sd_id:"伤害修正"}}]}] run return 1

# 没有"伤害修正"魂盘：保底1点伤害
execute if score @s temp matches ..100 run damage @s 1 minecraft:cactus
execute if score @s temp matches ..100 run return 1

# 应用计算后的伤害
$execute store result storage damage:$(player) damage int 0.01 run scoreboard players get @s temp
$function combat:damage_type/pm_damage with storage damage:$(player)
