#所有召唤的敌方单位的盔甲与盔甲韧性必须设置为-99
#物理伤害=攻击力-防御力.
#若造成伤害<1,则造成1点保底伤害.

$execute store result score @s temp run attribute @a[limit=1,tag=$(player)] generic.luck get
$scoreboard players set #rate temp $(rate)
scoreboard players operation @s temp *= #rate temp
scoreboard players set #hundred temp 100
scoreboard players operation @s temp /= #hundred temp

scoreboard players operation @s temp -= @s physical_armor

scoreboard players set #test temp 100
scoreboard players operation @s temp *= #test temp


# execute if score @s temp >= @s h1 run execute store result storage damage:damage damage_ int 0.01 run scoreboard players get @s h1
# execute if score @s temp >= @s h1 run execute if score @s h1 matches 1..100 run data modify storage damage:damage damage_ set value 1
# execute if score @s temp >= @s h1 run execute run function combat:healthbar/damage

# 保底伤害：如果伤害<=1点
# 有"伤害修正"魂盘：保底2点伤害
$execute if score @s temp matches ..100 if entity @a[limit=1,tag=$(player),nbt={Inventory:[{tag:{sd_id:"伤害修正"}}]}] run damage @s 2 minecraft:cactus
$execute if score @s temp matches ..100 if entity @a[limit=1,tag=$(player),nbt={Inventory:[{tag:{sd_id:"伤害修正"}}]}] run return 1

# 没有"伤害修正"魂盘：保底1点伤害
execute if score @s temp matches ..100 run damage @s 1 minecraft:cactus
execute if score @s temp matches ..100 run return 1

$execute store result storage damage:$(player) damage int 0.01 run scoreboard players get @s temp
#$damage @s $(damage) minecraft:cactus
$function combat:damage_type/pm_damage with storage damage:$(player)
