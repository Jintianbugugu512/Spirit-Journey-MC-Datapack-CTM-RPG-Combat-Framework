# ==========================================
# 重置敌人原版血量
# 功能：将所有敌人的原版血量设置为满血1023
# 原因：本地图使用记分板统计血量，需要保持原版血量满值防止敌人死亡
# 调用频率：每100tick调用一次（由interval_manager调用）
# ==========================================

# 设置所有敌人的最大血量为1023
execute as @e[tag=enemy] run attribute @s minecraft:generic.max_health base set 1023

# 直接设置当前血量为1022.5（使用data命令）
# 血量设置小数防止武器剑造成原版伤害时被血量显示系统检测而显示扣一滴血.
# 只对计分板血量不是满血的敌人触发
execute as @e[tag=enemy] unless score @s current_health >= @s max_health run data modify entity @s Health set value 1022.5f

