data modify storage nbt:boss_name name set from entity @e[limit=1,sort=nearest,distance=..20,tag=show_healthbar] CustomName
execute store result bossbar healthbar max run scoreboard players get @e[limit=1,sort=nearest,tag=show_healthbar] max_health
execute store result bossbar healthbar value run scoreboard players get @e[limit=1,sort=nearest,distance=..20,tag=show_healthbar] current_health
execute at @s if entity @e[tag=show_healthbar,distance=..20] run bossbar set healthbar players @s
execute at @s unless entity @e[tag=show_healthbar,distance=..20] run bossbar remove healthbar
bossbar set healthbar style notched_6

function combat:healthbar/health_bar_name with storage nbt:boss_name



