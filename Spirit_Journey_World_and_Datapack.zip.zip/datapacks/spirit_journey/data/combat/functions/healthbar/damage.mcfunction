#下面语句用于调试
# execute store result score #temp temp run data get storage damage:damage damage_
# tellraw @p [{"score": {"name": "#temp","objective": "temp"},"bold": true}]
execute anchored eyes at @s positioned ~ ~2.1 ~ summon text_display as @s at @s run function combat:healthbar/damage_merge with storage damage:damage


