execute anchored eyes at @s positioned ^-0.6 ^ ^1.0 summon text_display as @s at @s run function combat:healthbar/damage_show_fp/damage_merge with storage damage:damage


