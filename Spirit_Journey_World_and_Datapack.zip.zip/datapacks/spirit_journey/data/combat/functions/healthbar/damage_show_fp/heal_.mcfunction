scoreboard players operation #temp1 temp = @s h2
scoreboard players operation @s h2 -= #temp1 temp
scoreboard players operation @s h2 -= #temp1 temp
execute store result storage damage:damage damage_ float 1 run scoreboard players get @s h2
execute anchored eyes at @s positioned ^-0.5 ^ ^1 summon text_display as @s at @s run function combat:healthbar/damage_show_fp/heal_merge with storage damage:damage


