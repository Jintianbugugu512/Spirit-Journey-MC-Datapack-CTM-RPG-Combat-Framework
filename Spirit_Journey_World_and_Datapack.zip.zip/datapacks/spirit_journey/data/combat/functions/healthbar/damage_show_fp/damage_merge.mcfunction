
$data merge entity @s {text:'"§4§l-$(damage_)"',Tags:["damage_shower"],billboard:center,background:1942251,see_through:true}
scoreboard players set @s countDown 10

