execute store result score @s h1 run data get entity @s Health 1
scoreboard players operation @s h2 -= @s h1

execute if entity @s[scores={h2=1..}] run execute store result storage damage:damage damage_ float 1 run scoreboard players get @s h2
execute if entity @s[scores={h2=1..}] as @s at @s run function combat:healthbar/damage_show_fp/damage with storage damage:damage

execute if score @s h2 matches -1 run scoreboard players operation @s h2 = @s h1
execute if score @s h2 matches -1 run return 2


#execute if entity @s[scores={h2=..-1}] run execute store result storage damage:damage damage_ float 0.01 run scoreboard players get @s h2
execute if entity @s[scores={h2=..-1}] as @s at @s run function combat:healthbar/damage_show_fp/heal_ with storage damage:damage

scoreboard players operation @s h2 = @s h1


# execute if entity @s[scores={h2=1..}] run execute store result storage damage:damage heal int -1 run scoreboard players get @s h2
# execute if entity @s[scores={h2=1..}] at @s run function combat:healthbar/heal with storage damage:damage
