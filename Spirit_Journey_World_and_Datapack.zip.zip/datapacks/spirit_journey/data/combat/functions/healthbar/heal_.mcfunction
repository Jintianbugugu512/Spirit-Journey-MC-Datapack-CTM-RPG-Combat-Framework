execute anchored eyes at @s positioned ~ ~2.1 ~ summon text_display as @s at @s run function combat:healthbar/heal_merge with storage damage:damage





