execute store result score @s h1 run scoreboard players get @s current_health
scoreboard players operation @s h2 -= @s h1

execute if entity @s[scores={h2=1..}] run execute store result storage damage:damage damage_ int 1 run scoreboard players get @s h2
execute if entity @s[scores={h2=1..}] at @s run function combat:healthbar/damage with storage damage:damage

execute if score @s h2 matches -1 run scoreboard players operation @s h2 = @s h1
execute if score @s h2 matches -1 run return 2

execute if entity @s[scores={h2=..-1}] run execute store result storage damage:damage damage_ int -1 run scoreboard players get @s h2
execute if entity @s[scores={h2=..-1}] at @s run function combat:healthbar/heal_ with storage damage:damage

scoreboard players operation @s h2 = @s h1

#将原版生命值的扣除变转为本地图计分板的.
execute store result score @s h3 run data get entity @s Health
scoreboard players operation @s h4 -= @s h3

execute if entity @s[scores={h4=1..}] run scoreboard players operation @s current_health -= @s h4
execute if entity @s[scores={h4=1..,current_health=..0}] run scoreboard players set @s current_health 0

scoreboard players operation @s h4 = @s h3

# execute if entity @s[scores={h2=1..}] run execute store result storage damage:damage heal int -1 run scoreboard players get @s h2
# execute if entity @s[scores={h2=1..}] at @s run function combat:healthbar/heal with storage damage:damage


