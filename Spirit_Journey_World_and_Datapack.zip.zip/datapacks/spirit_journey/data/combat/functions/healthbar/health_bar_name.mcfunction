$bossbar add healthbar $(name)
