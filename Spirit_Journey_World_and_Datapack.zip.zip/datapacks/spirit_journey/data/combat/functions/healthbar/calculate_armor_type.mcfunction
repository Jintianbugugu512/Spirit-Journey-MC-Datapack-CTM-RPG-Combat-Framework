# ==========================================
# 计算并存储怪物的防御类型标识
# 执行者：怪物实体
# 在召唤怪物时调用一次
# ==========================================

# 计算防御类型：物理防御 - 魔抗
scoreboard players operation #defense_diff temp = @s physical_armor
scoreboard players operation #defense_diff temp -= @s magic_resist

# 根据差值设置类型标识
# 高物防 (差值>=25): armor_type = 1 → ■
execute if score #defense_diff temp matches 25.. run scoreboard players set @s armor_type 1

# 均衡型 (差值在6到24之间): armor_type = 2 → ●
execute if score #defense_diff temp matches 6..24 run scoreboard players set @s armor_type 2

# 高魔抗 (差值<=5): armor_type = 3 → ★
execute if score #defense_diff temp matches ..5 run scoreboard players set @s armor_type 3
