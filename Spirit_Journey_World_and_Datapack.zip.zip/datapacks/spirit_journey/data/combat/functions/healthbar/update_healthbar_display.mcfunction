# 更新怪物头顶血条显示 - 20格血条版本 + 防御类型标识
# 优化1：只在血量变化时更新
# 优化2：防御类型从缓存读取，不重新计算

# 先检查是否有血量数据，没有就跳过
execute unless score @s current_health matches 1.. run return fail
execute unless score @s max_health matches 1.. run return fail

# 血量变化检测 - 如果血量没变化就跳过更新
execute if score @s current_health = @s last_health run return fail

# 更新记录的血量值
scoreboard players operation @s last_health = @s current_health

# 计算血量百分比 (current_health * 100 / max_health)
scoreboard players operation #percent temp = @s current_health
scoreboard players set #100 temp 100
scoreboard players operation #percent temp *= #100 temp
scoreboard players operation #percent temp /= @s max_health

# 计算血条长度 (百分比 / 5 = 0-20个方块)
scoreboard players operation #bar_length temp = #percent temp
scoreboard players set #5 temp 5
scoreboard players operation #bar_length temp /= #5 temp

# 确保血量>0时至少显示1格
execute if score @s current_health matches 1.. if score #bar_length temp matches 0 run scoreboard players set #bar_length temp 1

# 存储当前血量用于显示
execute store result storage healthbar:display current int 1 run scoreboard players get @s current_health

# 从缓存读取防御类型标识（不重新计算）
execute if score @s armor_type matches 1 run data modify storage healthbar:display type set value "■"
execute if score @s armor_type matches 2 run data modify storage healthbar:display type set value "●"
execute if score @s armor_type matches 3 run data modify storage healthbar:display type set value "★"

# 根据百分比范围选择颜色并显示
# 绿色: 60%-100% (12-20格)
execute if score #percent temp matches 60.. if score #bar_length temp matches 20 run function combat:healthbar/bars20/green_20 with storage healthbar:display
execute if score #percent temp matches 60.. if score #bar_length temp matches 19 run function combat:healthbar/bars20/green_19 with storage healthbar:display
execute if score #percent temp matches 60.. if score #bar_length temp matches 18 run function combat:healthbar/bars20/green_18 with storage healthbar:display
execute if score #percent temp matches 60.. if score #bar_length temp matches 17 run function combat:healthbar/bars20/green_17 with storage healthbar:display
execute if score #percent temp matches 60.. if score #bar_length temp matches 16 run function combat:healthbar/bars20/green_16 with storage healthbar:display
execute if score #percent temp matches 60.. if score #bar_length temp matches 15 run function combat:healthbar/bars20/green_15 with storage healthbar:display
execute if score #percent temp matches 60.. if score #bar_length temp matches 14 run function combat:healthbar/bars20/green_14 with storage healthbar:display
execute if score #percent temp matches 60.. if score #bar_length temp matches 13 run function combat:healthbar/bars20/green_13 with storage healthbar:display
execute if score #percent temp matches 60.. if score #bar_length temp matches 12 run function combat:healthbar/bars20/green_12 with storage healthbar:display

# 黄色: 20%-59% (4-11格)
execute if score #percent temp matches 20..59 if score #bar_length temp matches 11 run function combat:healthbar/bars20/yellow_11 with storage healthbar:display
execute if score #percent temp matches 20..59 if score #bar_length temp matches 10 run function combat:healthbar/bars20/yellow_10 with storage healthbar:display
execute if score #percent temp matches 20..59 if score #bar_length temp matches 9 run function combat:healthbar/bars20/yellow_9 with storage healthbar:display
execute if score #percent temp matches 20..59 if score #bar_length temp matches 8 run function combat:healthbar/bars20/yellow_8 with storage healthbar:display
execute if score #percent temp matches 20..59 if score #bar_length temp matches 7 run function combat:healthbar/bars20/yellow_7 with storage healthbar:display
execute if score #percent temp matches 20..59 if score #bar_length temp matches 6 run function combat:healthbar/bars20/yellow_6 with storage healthbar:display
execute if score #percent temp matches 20..59 if score #bar_length temp matches 5 run function combat:healthbar/bars20/yellow_5 with storage healthbar:display
execute if score #percent temp matches 20..59 if score #bar_length temp matches 4 run function combat:healthbar/bars20/yellow_4 with storage healthbar:display

# 红色: 0%-19% (1-3格)
execute if score #percent temp matches ..19 if score #bar_length temp matches 3 run function combat:healthbar/bars20/red_3 with storage healthbar:display
execute if score #percent temp matches ..19 if score #bar_length temp matches 2 run function combat:healthbar/bars20/red_2 with storage healthbar:display
execute if score #percent temp matches ..19 if score #bar_length temp matches 1 run function combat:healthbar/bars20/red_1 with storage healthbar:display

# 确保名称可见
data modify entity @s CustomNameVisible set value true
