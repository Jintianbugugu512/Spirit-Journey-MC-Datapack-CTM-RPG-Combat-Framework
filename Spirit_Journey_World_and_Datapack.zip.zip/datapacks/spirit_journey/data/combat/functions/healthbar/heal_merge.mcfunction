$data merge entity @s {text:'"§2§l$(damage_)"',Tags:["damage_shower"],billboard:center,background:1942251,see_through:true}
scoreboard players set @s countDown 10
