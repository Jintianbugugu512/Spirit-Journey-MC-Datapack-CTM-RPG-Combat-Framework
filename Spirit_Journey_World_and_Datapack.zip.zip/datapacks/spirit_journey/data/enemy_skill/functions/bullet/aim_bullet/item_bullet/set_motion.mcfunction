# 设置光灵箭朝向玩家的动量
# 必须在 facing entity 的上下文中执行
# 参数：
#   sp - 速度值

# 召唤临时marker在前方sp格处
$summon marker ^ ^ ^$(sp) {Tags:["aim_temp"]}

# 计算x方向动量
execute store result score #temp_x temp run data get entity @s Pos[0] 1000
execute store result score #temp_target_x temp run data get entity @e[tag=aim_temp,limit=1] Pos[0] 1000
scoreboard players operation #temp_target_x temp -= #temp_x temp
execute store result entity @s Motion[0] double 0.001 run scoreboard players get #temp_target_x temp

# 计算y方向动量
execute store result score #temp_y temp run data get entity @s Pos[1] 1000
execute store result score #temp_target_y temp run data get entity @e[tag=aim_temp,limit=1] Pos[1] 1000
scoreboard players operation #temp_target_y temp -= #temp_y temp
execute store result entity @s Motion[1] double 0.001 run scoreboard players get #temp_target_y temp

# 计算z方向动量
execute store result score #temp_z temp run data get entity @s Pos[2] 1000
execute store result score #temp_target_z temp run data get entity @e[tag=aim_temp,limit=1] Pos[2] 1000
scoreboard players operation #temp_target_z temp -= #temp_z temp
execute store result entity @s Motion[2] double 0.001 run scoreboard players get #temp_target_z temp

# 清理临时marker
kill @e[tag=aim_temp]
