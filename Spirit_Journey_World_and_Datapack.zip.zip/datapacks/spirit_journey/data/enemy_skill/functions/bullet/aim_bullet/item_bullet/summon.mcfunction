# 瞄准玩家的item_display子弹
# 调用方式: execute as @e[tag=enemy] at @s run function enemy_skill:bullet/aim_bullet/item_bullet/summon {"name":"iron_sword","sp":1,"r":2,"d":10}
# 参数：
#   name - 物品ID (如: iron_sword, diamond_sword)
#   sp - 速度 (如: 1, 2, 3)
#   r - 伤害半径 (如: 2, 3)
#   d - 造成伤害 (如: 10, 20)
#
# 基本逻辑：
#   1. 召唤光灵箭（无重力、可穿透、朝向玩家）
#   2. 召唤item_display骑乘在光灵箭上

# 让敌人面向最近的玩家
tp @s ~ ~ ~ facing entity @p[gamemode=!spectator]

# 召唤光灵箭，朝向玩家，设置无重力、可穿透、无伤害
execute facing entity @p[gamemode=!spectator] eyes positioned ^ ^ ^1 run summon spectral_arrow ~ ~1.5 ~ {Tags:["enemy_bullet","aim_item_bullet","enemy_bullet_new"],Motion:[0.0d,0.0d,0.0d],NoGravity:1b,PierceLevel:127b,damage:0d}

# 设置光灵箭的参数（半径和伤害存储到记分板）
$scoreboard players set @e[tag=enemy_bullet_new,sort=nearest,limit=1] radius $(r)
$scoreboard players set @e[tag=enemy_bullet_new,sort=nearest,limit=1] damage $(d)

# 设置子弹的剩余存在时间到记分板temp（固定120tick）
scoreboard players set @e[tag=enemy_bullet_new,sort=nearest,limit=1] temp 120

# 设置光灵箭朝向玩家的动量（使用传入的速度参数）
$execute as @e[tag=enemy_bullet_new,sort=nearest,limit=1] at @s facing entity @p[gamemode=!spectator] eyes run function enemy_skill:bullet/aim_bullet/item_bullet/set_motion {"sp":$(sp)}

# 召唤item_display，面向玩家，水平放置（pitch=-90让物品平飞）
$execute facing entity @p[gamemode=!spectator] eyes run summon item_display ~ ~1.5 ~ {Tags:["item_bullet","item_bullet_new"],item:{id:"minecraft:$(name)",Count:1b},transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}

# 设置item_display的旋转：继承当前朝向的yaw，pitch设为-90（水平）
execute as @e[tag=item_bullet_new,limit=1] at @s facing entity @p[gamemode=!spectator] eyes run tp @s ~ ~ ~ ~ -90

# 让item_display骑乘在光灵箭上
ride @e[tag=item_bullet_new,limit=1] mount @e[tag=enemy_bullet_new,limit=1]

# 移除new标签
tag @e[tag=enemy_bullet_new] remove enemy_bullet_new
tag @e[tag=item_bullet_new] remove item_bullet_new
