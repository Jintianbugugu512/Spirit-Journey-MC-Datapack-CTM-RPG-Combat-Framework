# 使用宏参数检测碰撞
# 参数：
#   radius - 检测半径

$execute if entity @a[distance=..$(radius)] run function enemy_skill:bullet/aim_bullet/item_bullet/on_hit
