# 瞄准玩家的实体子弹
# 调用方式: execute as @e[tag=enemy] at @s run function enemy_skill:bullet/aim_bullet/entity_bullet/summon {type:"arrow",sp:3}
# 参数说明:
#   type - 实体类型（"arrow", "snowball", "egg", "ender_pearl", "shulker_bullet"等）
#   sp   - 子弹速度（数值越大越快，建议范围：1-5）

# 让敌人面向最近的玩家
tp @s ~ ~ ~ facing entity @p[gamemode=!spectator]

# 从敌人位置朝着玩家方向射出实体
$execute facing entity @p[gamemode=!spectator] eyes positioned ^ ^ ^1 run summon $(type) ~ ~1.5 ~ {Tags:["enemy_bullet","enemy_bullet_new"],Motion:[0.0d,0.0d,0.0d]}

# 设置实体朝向玩家的动量
$execute as @e[tag=enemy_bullet_new,sort=nearest,limit=1] at @s facing entity @p[gamemode=!spectator] eyes run function enemy_skill:bullet/aim_bullet/entity_bullet/set_motion {sp:$(sp)}

# 移除new标签
tag @e[tag=enemy_bullet_new] remove enemy_bullet_new
