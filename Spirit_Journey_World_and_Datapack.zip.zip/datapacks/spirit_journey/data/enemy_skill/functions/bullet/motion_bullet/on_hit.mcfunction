# 子弹命中处理
# 造成伤害并清除子弹
# 注意：此函数由 display 调用，需要从骑乘的光灵箭获取数据并清除载具

# 调试信息
tellraw @a {"text":"[on_hit] 子弹命中，开始处理...","color":"gold","bold":true}

# 从骑乘的载具（光灵箭）获取 radius 和 damage 值
execute on vehicle run tellraw @a [{"text":"[on_hit] 从载具获取数据 - damage: ","color":"yellow"},{"score":{"name":"@s","objective":"damage"}},{"text":" radius: ","color":"yellow"},{"score":{"name":"@s","objective":"radius"}}]
execute on vehicle run execute store result storage temp radius int 1 run scoreboard players get @s radius
execute on vehicle run execute store result storage temp damage int 1 run scoreboard players get @s damage

# 显示存储的数据
tellraw @a [{"text":"[on_hit] storage temp 数据: ","color":"yellow"},{"nbt":"radius","storage":"temp"},{"text":" / ","color":"white"},{"nbt":"damage","storage":"temp"}]

# 调用伤害应用（在 display 的位置）
tellraw @a {"text":"[on_hit] 准备调用 damage_apply...","color":"yellow"}
execute at @s run function enemy_skill:bullet/motion_bullet/damage_apply with storage temp

# 清除载具（光灵箭）
execute on vehicle run kill @s

# 清除自己（display）
kill @s
tellraw @a {"text":"[on_hit] 处理完成，已清除子弹","color":"green"}
