# 动量子弹系统 - 直线发射子弹

## 📋 功能说明

这是一个基于光灵箭和display的子弹系统，具有以下特点：
- 直线飞行（无重力）
- 可穿透实体
- 范围伤害
- 自动生命周期管理
- 零tick开销（骑乘系统）
- 支持 block_display 和 item_display

## 🎯 调用方式

```mcfunction
execute as @e[tag=enemy] at @s run function enemy_skill:bullet/motion_bullet/summon {type:"block_display",name:"minecraft:oak_log",mx:2.0,my:0.0,mz:0.0,t:100,scale:1,dr:2,damage:10}
```

## 📖 参数说明

| 参数 | 类型 | 说明 | 示例 |
|------|------|------|------|
| `type` | 字符串 | display类型（"block_display" 或 "item_display"） | `"block_display"` |
| `name` | 字符串 | 方块/物品ID（block用方块，item用物品） | `"minecraft:oak_log"` |
| `mx` | 小数 | X轴动量（东西方向，正值向东，负值向西） | `2.0` |
| `my` | 小数 | Y轴动量（上下方向，正值向上，负值向下） | `0.5` |
| `mz` | 小数 | Z轴动量（南北方向，正值向南，负值向北） | `1.0` |
| `t` | 整数 | 存在时间（单位：tick，20tick=1秒） | `100` |
| `scale` | 小数 | 视觉大小（display的缩放比例） | `1.0` |
| `dr` | 整数 | 伤害半径（单位：格） | `2` |
| `damage` | 整数 | 伤害值 | `10` |

## 💡 使用示例

### Block Display（方块显示）

#### 水平直射
```mcfunction
# 召唤敌人
/summon zombie ~ ~ ~ {Tags:["enemy"]}

# 向东发射橡木原木
/execute as @e[tag=enemy] at @s run function enemy_skill:bullet/motion_bullet/summon {type:"block_display",name:"minecraft:oak_log",mx:2.0,my:0.0,mz:0.0,t:100,scale:1,dr:1,damage:10}

# 向西发射石头
/execute as @e[tag=enemy] at @s run function enemy_skill:bullet/motion_bullet/summon {type:"block_display",name:"minecraft:stone",mx:-2.0,my:0.0,mz:0.0,t:100,scale:1,dr:1,damage:10}
```

#### 竖直发射
```mcfunction
# 向上发射岩浆块
/execute as @e[tag=enemy] at @s run function enemy_skill:bullet/motion_bullet/summon {type:"block_display",name:"minecraft:magma_block",mx:0.0,my:2.0,mz:0.0,t:100,scale:1,dr:1,damage:15}

# 向下发射冰块
/execute as @e[tag=enemy] at @s run function enemy_skill:bullet/motion_bullet/summon {type:"block_display",name:"minecraft:ice",mx:0.0,my:-1.5,mz:0.0,t:100,scale:1,dr:1,damage:15}
```

#### 斜向发射
```mcfunction
# 斜向上发射钻石块
/execute as @e[tag=enemy] at @s run function enemy_skill:bullet/motion_bullet/summon {type:"block_display",name:"minecraft:diamond_block",mx:1.5,my:0.5,mz:0.0,t:120,scale:1,dr:1,damage:12}

# 45度角发射金块
/execute as @e[tag=enemy] at @s run function enemy_skill:bullet/motion_bullet/summon {type:"block_display",name:"minecraft:gold_block",mx:1.0,my:1.0,mz:0.0,t:100,scale:1,dr:1,damage:10}
```

### Item Display（物品显示）

```mcfunction
# 向东发射钻石剑
/execute as @e[tag=enemy] at @s run function enemy_skill:bullet/motion_bullet/summon {type:"item_display",name:"minecraft:diamond_sword",mx:2.0,my:0.0,mz:0.0,t:100,scale:1,dr:2,damage:10}

# 向西发射三叉戟
/execute as @e[tag=enemy] at @s run function enemy_skill:bullet/motion_bullet/summon {type:"item_display",name:"minecraft:trident",mx:-2.0,my:0.0,mz:0.0,t:100,scale:2,dr:2,damage:20}

# 向上发射火焰弹
/execute as @e[tag=enemy] at @s run function enemy_skill:bullet/motion_bullet/summon {type:"item_display",name:"minecraft:fire_charge",mx:0.0,my:2.0,mz:0.0,t:80,scale:1.5,dr:1,damage:8}

# 斜向发射末影珍珠
/execute as @e[tag=enemy] at @s run function enemy_skill:bullet/motion_bullet/summon {type:"item_display",name:"minecraft:ender_pearl",mx:1.5,my:0.5,mz:0.0,t:100,scale:1,dr:2,damage:12}
```

### 不同类型的子弹

#### 小型快速子弹（紫珀块）
```mcfunction
/execute as @e[tag=enemy] at @s run function enemy_skill:bullet/motion_bullet/summon {type:"block_display",name:"minecraft:purpur_block",mx:3.0,my:0.0,mz:0.0,t:60,scale:0.5,dr:1,damage:5}
```

#### 大型慢速重炮（黑曜石）
```mcfunction
/execute as @e[tag=enemy] at @s run function enemy_skill:bullet/motion_bullet/summon {type:"block_display",name:"minecraft:obsidian",mx:1.0,my:0.0,mz:0.0,t:200,scale:2,dr:3,damage:30}
```

#### 远程狙击弹（末地石）
```mcfunction
/execute as @e[tag=enemy] at @s run function enemy_skill:bullet/motion_bullet/summon {type:"block_display",name:"minecraft:end_stone",mx:4.0,my:0.0,mz:0.0,t:150,scale:1,dr:2,damage:20}
```

#### 扇形弹幕（连续发射多个火焰弹）
```mcfunction
/execute as @e[tag=enemy] at @s run function enemy_skill:bullet/motion_bullet/summon {type:"block_display",name:"minecraft:fire_coral_block",mx:2.0,my:0.0,mz:-0.5,t:100,scale:0.8,dr:1,damage:8}
/execute as @e[tag=enemy] at @s run function enemy_skill:bullet/motion_bullet/summon {type:"block_display",name:"minecraft:fire_coral_block",mx:2.0,my:0.0,mz:0.0,t:100,scale:0.8,dr:1,damage:8}
/execute as @e[tag=enemy] at @s run function enemy_skill:bullet/motion_bullet/summon {type:"block_display",name:"minecraft:fire_coral_block",mx:2.0,my:0.0,mz:0.5,t:100,scale:0.8,dr:1,damage:8}
```

#### 小视觉大范围伤害（荧石 - 狙击弹）
```mcfunction
/execute as @e[tag=enemy] at @s run function enemy_skill:bullet/motion_bullet/summon {type:"block_display",name:"minecraft:glowstone",mx:3.0,my:0.0,mz:0.0,t:150,scale:0.5,dr:3,damage:20}
```

#### 大视觉小范围伤害（海绵 - 重炮）
```mcfunction
/execute as @e[tag=enemy] at @s run function enemy_skill:bullet/motion_bullet/summon {type:"block_display",name:"minecraft:sponge",mx:1.0,my:0.0,mz:0.0,t:200,scale:2.0,dr:1,damage:30}
```

## ⚙️ 技术细节

### 碰撞检测
- 每tick检测子弹周围3格内是否有玩家
- 检测到玩家时立即触发伤害

### 伤害机制
- 对子弹位置半径 `dr` 格内的所有玩家造成伤害
- 造成伤害后子弹和display立即清除
- 伤害类型：`minecraft:cactus`

### 生命周期
- 存在时间由参数 `t` 控制
- 时间到后自动清除子弹和display
- 碰撞到玩家后立即清除

### 性能
- 使用骑乘系统，display自动跟随光灵箭
- 无需每tick传送，性能开销极低
- 20个子弹 = 每tick仅20次碰撞检测

## 🔧 相关文件

- `summon.mcfunction` - 主召唤函数
- `summon_block_display.mcfunction` - 召唤方块显示
- `summon_item_display.mcfunction` - 召唤物品显示
- `damage_apply.mcfunction` - 伤害应用
- `check_collision.mcfunction` - 碰撞检测
- `on_hit.mcfunction` - 命中处理

## 📝 注意事项

1. **光灵箭贴图**：建议使用资源包将光灵箭贴图改为透明，否则会看到箭矢
2. **记分板依赖**：需要 `temp`、`radius`、`damage` 记分板（已在scoreboard_creator中创建）
3. **标签系统**：
   - `enemy_bullet` - 通用子弹标签（所有子弹系统共用）
   - `motion_bullet` - 动量子弹专属标签（用于区分子弹类型）
   - `motion_bullet_display` - display实体标签（block_display和item_display共用）
4. **方向控制**：动量值越大，飞行速度越快
5. **视觉与伤害分离**：
   - `scale` 控制视觉大小（可以是小数，如0.5、1.5）
   - `dr` 控制伤害范围（整数，单位：格）
   - 两者独立，可以创造"小视觉大伤害"或"大视觉小伤害"的效果
6. **方块/物品选择**：
   - `type:"block_display"` 使用方块ID：`"minecraft:oak_log"`
   - `type:"item_display"` 使用物品ID：`"minecraft:diamond_sword"`
   - ID必须带引号

## 🎨 视觉效果

### Block Display 推荐方块
- 火焰系：`fire_coral_block`、`magma_block`、`netherrack`
- 冰冻系：`ice`、`packed_ice`、`blue_ice`
- 魔法系：`purpur_block`、`end_stone`、`glowstone`
- 重型：`obsidian`、`iron_block`、`stone`
- 宝石：`diamond_block`、`emerald_block`、`gold_block`

### Item Display 推荐物品
- 武器：`diamond_sword`、`trident`、`bow`、`crossbow`
- 弹药：`arrow`、`spectral_arrow`、`fire_charge`
- 魔法：`ender_pearl`、`ender_eye`、`nether_star`
- 工具：`diamond_pickaxe`、`golden_axe`

## 💡 设计建议

- **小型快速**：`scale:0.5`，`mx/my/mz:3.0+`，短存在时间
- **大型慢速**：`scale:2.0`，`mx/my/mz:1.0`，长存在时间
- **精准狙击**：小`scale`，大`dr`，高伤害
- **范围轰炸**：大`scale`，大`dr`，中等伤害
