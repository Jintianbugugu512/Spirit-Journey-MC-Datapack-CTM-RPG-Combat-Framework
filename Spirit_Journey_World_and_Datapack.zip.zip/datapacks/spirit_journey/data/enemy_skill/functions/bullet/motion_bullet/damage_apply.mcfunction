# 动量子弹伤害应用
# 在子弹位置对半径内的玩家造成伤害
# 参数：
#   radius - 伤害半径
#   damage - 伤害值

# 调试信息 - 显示执行位置和检测到的玩家
$tellraw @a [{"text":"[伤害应用] 位置: ","color":"yellow"},{"nbt":"Pos","entity":"@s"},{"text":" radius: ","color":"yellow"},{"text":"$(radius)","color":"white"},{"text">" damage: ","color":"yellow"},{"text":"$(damage)","color":"white"}]
$execute if entity @a[distance=..$(radius)] run tellraw @a [{"text":"[伤害应用] 检测到玩家: ","color":"green"},{"selector":"@a[distance=..$(radius)]"}]
$execute unless entity @a[distance=..$(radius)] run tellraw @a {"text":"[伤害应用] 半径内没有玩家！","color":"red"}

# 造成伤害
$execute as @a[distance=..$(radius)] run damage @s $(damage) minecraft:cactus
$execute as @a[distance=..$(radius)] run tellraw @s {"text":"[伤害应用] 已对你造成伤害！","color":"red","bold":true}

# 音效和粒子
$execute as @a[distance=..$(radius)] at @s run playsound entity.player.hurt master @a ~ ~ ~ 1 1
$execute as @a[distance=..$(radius)] at @s run particle damage_indicator ~ ~1 ~ 0.3 0.5 0.3 0 5 force

