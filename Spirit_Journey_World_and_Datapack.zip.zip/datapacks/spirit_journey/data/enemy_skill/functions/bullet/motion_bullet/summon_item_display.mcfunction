# 召唤 item_display
# 参数：
#   name - 物品ID
#   scale - 缩放比例
#   tx - X轴视觉偏移量
#   ty - Y轴视觉偏移量
#   tz - Z轴视觉偏移量

$summon item_display ~ ~ ~ {Tags:["motion_bullet_display","motion_bullet_display_new"],item:{id:"$(name)",Count:1b},transformation:{scale:[$(scale)f,$(scale)f,$(scale)f],translation:[$(tx)f,$(ty)f,$(tz)f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}

# 让display骑乘在光灵箭上
ride @e[tag=motion_bullet_display_new,limit=1] mount @e[tag=enemy_bullet_new,limit=1]
