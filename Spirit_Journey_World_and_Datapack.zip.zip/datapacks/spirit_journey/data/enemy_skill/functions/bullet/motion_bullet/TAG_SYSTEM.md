# Motion Bullet 标签系统说明

## 📋 标签架构

### 光灵箭载体（Spectral Arrow）
```
Tags: ["enemy_bullet", "motion_bullet", "enemy_bullet_new"]
```
- `enemy_bullet` - 通用子弹标签，所有子弹系统共用
- `motion_bullet` - **motion_bullet专属标签**，用于区分不同类型的子弹
- `enemy_bullet_new` - 临时标签，用于初始化，使用后立即移除

### Display实体（Block/Item Display）
```
Tags: ["motion_bullet_display", "motion_bullet_display_new"]
```
- `motion_bullet_display` - motion_bullet的display实体专属标签
- `motion_bullet_display_new` - 临时标签，用于骑乘绑定，使用后立即移除

## 🎯 为什么需要专属标签？

### 问题（改进前）
```mcfunction
# entity_manager.mcfunction
execute as @e[tag=enemy_bullet] run function ...
```
- `enemy_bullet`太通用，包含所有类型的子弹（motion、aim、其他）
- 无法区分是哪种子弹系统
- 导致不必要的函数调用，性能浪费

### 解决方案（改进后）
```mcfunction
# entity_manager.mcfunction
execute as @e[tag=motion_bullet] run function enemy_skill:bullet/motion_bullet/manage
execute as @e[tag=aim_item_bullet] run function enemy_skill:bullet/aim_bullet/...
```
- 每种子弹系统有专属标签
- 精确选择，避免误调用
- 代码阅读更清晰

## 📊 标签对比表

| 子弹类型 | 通用标签 | 专属标签 | Display标签 |
|---------|---------|---------|------------|
| Motion子弹 | `enemy_bullet` | `motion_bullet` | `motion_bullet_display` |
| Aim子弹 | `enemy_bullet` | `aim_item_bullet` | (待统一) |
| 其他子弹 | `enemy_bullet` | (待添加) | (待添加) |

## 🔧 调用示例

### 召唤子弹（自动添加标签）
```mcfunction
execute as @e[tag=enemy] at @s run function enemy_skill:bullet/motion_bullet/summon {
    type:"block_display",
    name:"minecraft:oak_log",
    mx:2.0, my:0.0, mz:0.0,
    t:100, scale:1, dr:2, damage:10,
    tx:0, ty:0, tz:0
}
# 自动创建：
# - 光灵箭：Tags:["enemy_bullet","motion_bullet"]
# - Display：Tags:["motion_bullet_display"]
```

### 管理子弹（使用专属标签）
```mcfunction
# entity_manager.mcfunction
execute as @e[tag=motion_bullet] run function enemy_skill:bullet/motion_bullet/manage
```

### 检测碰撞（在display上执行）
```mcfunction
# check_collision.mcfunction（由manage调用）
execute if entity @a[distance=..3] run function enemy_skill:bullet/motion_bullet/on_hit
```

## ✅ 改进效果

1. **可读性提升** - 一眼看出是motion_bullet系统
2. **性能优化** - 只处理motion_bullet，不误处理其他子弹
3. **维护便利** - 修改motion_bullet不影响其他子弹系统
4. **扩展性好** - 其他子弹系统可以参照添加专属标签

## 📝 注意事项

- 旧代码中的`block_bullet`已全部改为`motion_bullet_display`
- `enemy_bullet`仍保留作为通用标签（兼容性）
- 所有motion_bullet相关的选择器应使用`tag=motion_bullet`而非`tag=enemy_bullet`
