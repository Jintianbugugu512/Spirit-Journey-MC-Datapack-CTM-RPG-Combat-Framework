# 动量子弹发射函数
# 调用方式: execute as @e[tag=enemy] at @s run function enemy_skill:bullet/motion_bullet/summon {type:"block_display",name:"minecraft:oak_log",mx:0.0,my:1.0,mz:0.0,t:100,scale:1,dr:2,damage:10,tx:0,ty:0,tz:0}
# 参数说明:
#   type   - display类型（"block_display" 或 "item_display"）
#   name   - 方块/物品ID（block_display用方块如"minecraft:oak_log"，item_display用物品如"minecraft:diamond_sword"）
#   mx - X轴动量（东西方向，正值向东）
#   my - Y轴动量（上下方向，正值向上）
#   mz - Z轴动量（南北方向，正值向南）
#   t  - 存在时间（tick），光灵箭消失后display也会被清除
#   scale - 视觉大小（display的缩放比例）
#   dr - 伤害半径（伤害范围，单位：格）
#   damage - 伤害值
#   tx - display的X轴视觉偏移量（可以是小数）
#   ty - display的Y轴视觉偏移量（可以是小数）
#   tz - display的Z轴视觉偏移量（可以是小数）

# 召唤光灵箭实体，设置无重力、可穿透实体、无伤害
# 标签说明：enemy_bullet(通用子弹标签) + motion_bullet(motion子弹专属) + enemy_bullet_new(临时标签)
$summon spectral_arrow ~ ~1.5 ~ {Tags:["enemy_bullet","motion_bullet","enemy_bullet_new"],Motion:[$(mx)d,$(my)d,$(mz)d],NoGravity:1b,PierceLevel:127b,damage:0d}

# 设置子弹的剩余存在时间到记分板temp
$scoreboard players set @e[tag=enemy_bullet_new,limit=1] temp $(t)

# 设置子弹的伤害半径到记分板radius
$scoreboard players set @e[tag=enemy_bullet_new,limit=1] radius $(dr)

# 设置子弹的伤害值到记分板damage
$scoreboard players set @e[tag=enemy_bullet_new,limit=1] damage $(damage)

# 根据type参数召唤对应的display
# block_display: 使用block_state
# item_display: 使用item
$execute as @e[tag=enemy_bullet_new,limit=1] at @s if entity @s run function enemy_skill:bullet/motion_bullet/summon_display {type:"$(type)",name:"$(name)",scale:$(scale),tx:$(tx),ty:$(ty),tz:$(tz)}

# 移除new标签
tag @e[tag=enemy_bullet_new] remove enemy_bullet_new
tag @e[tag=motion_bullet_display_new] remove motion_bullet_display_new
