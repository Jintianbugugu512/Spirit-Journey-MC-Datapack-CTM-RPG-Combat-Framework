# 根据type参数召唤对应的display
# 参数：
#   type - "block_display" 或 "item_display"
#   name - 方块/物品ID
#   scale - 缩放比例
#   tx - X轴视觉偏移量
#   ty - Y轴视觉偏移量
#   tz - Z轴视觉偏移量

$function enemy_skill:bullet/y_bullet/summon_$(type) {name:"$(name)",scale:$(scale),tx:$(tx),ty:$(ty),tz:$(tz)}
