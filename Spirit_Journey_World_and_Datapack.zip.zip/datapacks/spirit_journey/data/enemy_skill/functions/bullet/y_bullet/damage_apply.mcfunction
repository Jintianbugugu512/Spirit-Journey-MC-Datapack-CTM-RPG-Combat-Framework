# 动量子弹伤害应用
# 在子弹位置对半径内的玩家造成伤害
# 参数：
#   radius - 伤害半径
#   damage - 伤害值

$execute as @a[distance=..$(radius)] run damage @s $(damage) minecraft:cactus
