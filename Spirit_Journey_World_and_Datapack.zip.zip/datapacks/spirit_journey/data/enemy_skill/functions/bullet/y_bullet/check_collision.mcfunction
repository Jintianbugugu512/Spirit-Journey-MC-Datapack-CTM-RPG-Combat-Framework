# Y轴颠倒子弹碰撞检测
# 检测子弹附近是否有玩家，如果有则造成伤害并移除子弹
# 注意：此函数由 display 调用，需要从骑乘的光灵箭获取数据

# 检测半径内是否有玩家（固定3格检测范围，实际伤害范围由on_hit中的radius决定）
execute if entity @a[distance=..3] run function enemy_skill:bullet/y_bullet/on_hit
