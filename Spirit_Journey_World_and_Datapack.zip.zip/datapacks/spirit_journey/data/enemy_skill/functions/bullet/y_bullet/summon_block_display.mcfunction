# 召唤 block_display（上下颠倒）
# 参数：
#   name - 方块ID
#   scale - 缩放比例
#   tx - X轴视觉偏移量
#   ty - Y轴视觉偏移量
#   tz - Z轴视觉偏移量

$summon block_display ~ ~ ~ {Tags:["block_bullet","block_bullet_new"],block_state:{Name:"$(name)"},transformation:{scale:[$(scale)f,$(scale)f,$(scale)f],translation:[$(tx)f,$(ty)f,$(tz)f],left_rotation:[1f,0f,0f,0f],right_rotation:[0f,0f,0f,1f]}}

# 让display骑乘在光灵箭上
ride @e[tag=block_bullet_new,limit=1] mount @e[tag=enemy_bullet_new,limit=1]
