# Y轴颠倒子弹生命周期管理与碰撞检测
# 整合原本在entity_manager中的逻辑
# 作用于带有 y_bullet 标签的 enemy_bullet 实体

# 生命周期递减
scoreboard players remove @s[scores={temp=1..}] temp 1

# 碰撞检测（以display为伤害中心）
execute at @s on passengers run function enemy_skill:bullet/y_bullet/check_collision

# 清理过期子弹（temp<=0）
execute if score @s temp matches ..0 on passengers run kill @s
execute if score @s temp matches ..0 run kill @s
