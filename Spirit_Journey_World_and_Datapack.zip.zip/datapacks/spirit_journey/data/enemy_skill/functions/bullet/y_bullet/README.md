# 动量子弹系统 - Y轴颠倒版本

## 📋 功能说明

这是 motion_bullet 的变体版本，所有功能完全相同，唯一的区别是：
- **display 模型上下颠倒**（绕X轴旋转180度）
- 适用于需要倒置显示的场景

## 🎯 调用方式

```mcfunction
execute as @e[tag=enemy] at @s run function enemy_skill:bullet/y_bullet/summon {type:"block_display",name:"minecraft:oak_log",mx:2.0,my:0.0,mz:0.0,t:100,scale:1,dr:2,damage:10}
```

## 📖 参数说明

| 参数 | 类型 | 说明 | 示例 |
|------|------|------|------|
| `type` | 字符串 | display类型（"block_display" 或 "item_display"） | `"block_display"` |
| `name` | 字符串 | 方块/物品ID | `"minecraft:oak_log"` |
| `mx` | 小数 | X轴动量（东西方向，正值向东，负值向西） | `2.0` |
| `my` | 小数 | Y轴动量（上下方向，正值向上，负值向下） | `0.5` |
| `mz` | 小数 | Z轴动量（南北方向，正值向南，负值向北） | `1.0` |
| `t` | 整数 | 存在时间（单位：tick，20tick=1秒） | `100` |
| `scale` | 小数 | 视觉大小（display的缩放比例） | `1.0` |
| `dr` | 整数 | 伤害半径（单位：格） | `2` |
| `damage` | 整数 | 伤害值 | `10` |

## 💡 使用示例

### Block Display（方块显示）- 上下颠倒
```mcfunction
# 召唤敌人
/summon zombie ~ ~ ~ {Tags:["enemy"]}

# 向X负方向（西）发射倒置的橡木原木
/execute as @e[tag=enemy] at @s run function enemy_skill:bullet/y_bullet/summon {type:"block_display",name:"minecraft:oak_log",mx:-2.0,my:0.0,mz:0.0,t:100,scale:1,dr:2,damage:10}

# 向X负方向发射倒置的岩浆块
/execute as @e[tag=enemy] at @s run function enemy_skill:bullet/y_bullet/summon {type:"block_display",name:"minecraft:magma_block",mx:-2.0,my:0.0,mz:0.0,t:100,scale:1,dr:2,damage:15}

# 向东发射倒置的末地石
/execute as @e[tag=enemy] at @s run function enemy_skill:bullet/y_bullet/summon {type:"block_display",name:"minecraft:end_stone",mx:2.0,my:0.0,mz:0.0,t:100,scale:1,dr:2,damage:10}
```

### Item Display（物品显示）- 上下颠倒
```mcfunction
# 向X负方向发射倒置的钻石剑
/execute as @e[tag=enemy] at @s run function enemy_skill:bullet/y_bullet/summon {type:"item_display",name:"minecraft:diamond_sword",mx:-2.0,my:0.0,mz:0.0,t:100,scale:1,dr:2,damage:10}

# 向东发射倒置的三叉戟
/execute as @e[tag=enemy] at @s run function enemy_skill:bullet/y_bullet/summon {type:"item_display",name:"minecraft:trident",mx:2.0,my:0.0,mz:0.0,t:100,scale:2,dr:2,damage:20}

# 向上发射倒置的火焰弹
/execute as @e[tag=enemy] at @s run function enemy_skill:bullet/y_bullet/summon {type:"item_display",name:"minecraft:fire_charge",mx:0.0,my:2.0,mz:0.0,t:80,scale:1.5,dr:1,damage:8}
```

### 斜向发射
```mcfunction
# 斜向上发射倒置的钻石块
/execute as @e[tag=enemy] at @s run function enemy_skill:bullet/y_bullet/summon {type:"block_display",name:"minecraft:diamond_block",mx:1.5,my:0.5,mz:0.0,t:120,scale:1,dr:1,damage:12}
```

## ⚙️ 技术细节

### 与 motion_bullet 的区别
- `left_rotation` 从 `[0f,0f,0f,1f]` 改为 `[1f,0f,0f,0f]`
- 这是绕X轴旋转180度的四元数表示
- 效果：模型上下颠倒

### 其他特性（完全相同）
- 无重力飞行
- 可穿透实体
- 碰撞检测（3格范围）
- 范围伤害（基于 dr 参数）
- 自动生命周期管理
- 零tick开销（骑乘系统）

## 📝 注意事项

1. **光灵箭贴图**：建议使用资源包将光灵箭贴图改为透明
2. **记分板依赖**：需要 `temp`、`radius`、`damage` 记分板
3. **标签系统**：
   - `enemy_bullet` - 光灵箭载体
   - `block_bullet` - display
4. **适用场景**：
   - 倒挂的剑、箭等武器
   - 特殊视觉效果
   - 从上方掉落的攻击

## 🔧 相关文件

- `summon.mcfunction` - 主召唤函数
- `summon_block_display.mcfunction` - 召唤倒置的方块显示
- `summon_item_display.mcfunction` - 召唤倒置的物品显示
- `check_collision.mcfunction` - 碰撞检测
- `damage_apply.mcfunction` - 伤害应用
- `on_hit.mcfunction` - 命中处理

## 💡 何时使用

- ✅ 需要倒置的武器模型（倒插的剑）
- ✅ 从天而降的攻击效果
- ✅ 特殊的视觉变化
- ❌ 普通子弹（使用 motion_bullet 即可）
