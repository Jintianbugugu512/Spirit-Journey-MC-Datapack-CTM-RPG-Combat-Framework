# 子弹命中处理
# 造成伤害并清除子弹
# 注意：此函数由 display 调用，需要从骑乘的光灵箭获取数据并清除载具

# 从骑乘的载具（光灵箭）获取 radius 和 damage 值并造成伤害
execute on vehicle run execute store result storage temp radius int 1 run scoreboard players get @s radius
execute on vehicle run execute store result storage temp damage int 1 run scoreboard players get @s damage
function enemy_skill:bullet/y_bullet/damage_apply with storage temp

# 清除载具（光灵箭）
execute on vehicle run kill @s

# 清除自己（display）
kill @s
