# ==========================================
# 亡语系统 - Deathrattle
# 怪物死亡前（current_health <= 0）触发的技能
# 执行者：kill_manager
# ==========================================

# 亡语技能注册区
# 格式：execute if entity @s[tag=怪物标签] at @s run function enemy_skill:deathrattle/技能名

# 示例：
# execute if entity @s[tag=explosive_zombie] at @s run function enemy_skill:deathrattle/explosion
# execute if entity @s[tag=poison_spider] at @s run function enemy_skill:deathrattle/poison_cloud
# execute if entity @s[tag=necromancer] at @s run function enemy_skill:deathrattle/summon_skeleton

# TODO: 在此添加亡语技能注册
