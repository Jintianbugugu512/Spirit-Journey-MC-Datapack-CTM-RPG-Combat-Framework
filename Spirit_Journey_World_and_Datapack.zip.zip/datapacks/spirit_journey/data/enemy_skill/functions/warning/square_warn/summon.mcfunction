# ==========================================
# 方形攻击预警 - 召唤（宏函数版本）
# 在敌人前方地面召唤一个方形预警标记
# 从小变大，然后消失
#
# 调用格式：
#   function enemy_skill:warning/square_warn/summon {scale_x:数字,scale_z:数字,tt:数字,et:数字}
#
# 参数说明：
#   scale_x: X轴最终缩放（宽度），1.0 = 1格
#   scale_z: Z轴最终缩放（长度），1.0 = 1格
#   tt: 变形时间（transform time），单位tick，建议5-20
#   et: 存在时间（exist time），单位tick，变形完成后停留的时间
#   总时长 = tt + et
#
# 调用示例：
#   # 标准1格×1格方形，10tick变形，20tick停留
#   execute as @e[tag=敌人] at @s run function enemy_skill:warning/square_warn/summon {scale_x:1.0,scale_z:1.0,tt:10,et:20}
#
#   # 2格×2格大方形，快速变形（5tick），长时间停留（40tick）
#   execute as @e[tag=敌人] at @s run function enemy_skill:warning/square_warn/summon {scale_x:2.0,scale_z:2.0,tt:5,et:40}
#
#   # 3格×1格长条形，慢速变形（20tick），短暂停留（10tick）
#   execute as @e[tag=敌人] at @s run function enemy_skill:warning/square_warn/summon {scale_x:3.0,scale_z:1.0,tt:20,et:10}
#
#   # 快速预警：5tick变形，5tick停留
#   execute as @e[tag=敌人] at @s run function enemy_skill:warning/square_warn/summon {scale_x:1.0,scale_z:1.0,tt:5,et:5}
# ==========================================

# 在敌人前方3格的地面召唤潜影壳显示实体
# 先召唤一个小的，然后通过 interpolation 自动放大
$summon item_display ^ ^0.1 ^3 {\
Tags:["square_warning","square_warning_new","warning"],\
transformation:{scale:[0.1f,0.1f,0.1f],translation:[0f,0f,0f],left_rotation:[0.7071f,0f,0f,0.7071f],right_rotation:[0f,0f,0f,1f]},\
item:{id:"minecraft:shulker_shell",Count:1b},\
billboard:"fixed",\
interpolation_duration:$(tt),\
start_interpolation:0,\
brightness:{sky:15,block:15}\
}

# 设置生命周期：tt(变形时间) + et(存在时间)
$scoreboard players set @e[tag=square_warning_new] temp $(tt)
$scoreboard players add @e[tag=square_warning_new] temp $(et)

# 直接在同一函数中触发放大动画
# 注意：旋转后 Y轴变成了长度，X轴是宽度，Z轴是厚度
$execute as @e[tag=square_warning_new,limit=1] run data modify entity @s transformation.scale set value [$(scale_x)f,$(scale_z)f,1.0f]

# 移除new标签
tag @e[tag=square_warning_new] remove square_warning_new

# 播放警告音效
playsound block.note_block.bass hostile @a[distance=..15] ^ ^0.1 ^3 0.8 0.5

# 生成警告粒子
particle dust 1.0 0.0 0.0 1.0 ^ ^0.1 ^3 0.5 0.05 0.5 0 10 force
