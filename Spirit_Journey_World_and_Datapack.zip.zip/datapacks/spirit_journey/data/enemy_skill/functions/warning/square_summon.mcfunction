# ==========================================
# 方形攻击预警 - 召唤（宏函数版本）
# 在敌人前方地面召唤一个方形预警标记
# 直接显示最终形态，停留后消失
#
# 注意：方形预警没有伤害参数 d
# 原因：方形范围判定复杂（dx/dy/dz），需要根据实际情况手动判定伤害范围
# 使用场景：召唤多个圆形预警（d:0）拟合方形区域，然后统一判定伤害
#
# 调用格式：
#   function enemy_skill:warning/square_summon {scale_x:数字,scale_z:数字,et:数字}
#
# 参数说明：
#   scale_x: X轴最终缩放（宽度），1.0 = 1格
#   scale_z: Z轴最终缩放（长度），1.0 = 1格
#   et: 存在时间（exist time），单位tick
#
# 伤害处理建议：
#   在技能函数中手动召唤多个圆形预警（d:0）拟合方形区域
#   然后统一使用 damage 命令或伤害函数造成伤害
#
# 调用示例：
#   # 标准1格×1格方形，20tick停留
#   execute as @e[tag=敌人] at @s run function enemy_skill:warning/square_summon {scale_x:1.0,scale_z:1.0,et:20}
#
#   # 2格×2格大方形，长时间停留（40tick）
#   execute as @e[tag=敌人] at @s run function enemy_skill:warning/square_summon {scale_x:2.0,scale_z:2.0,et:40}
#
#   # 3格×1格长条形，短暂停留（10tick）
#   execute as @e[tag=敌人] at @s run function enemy_skill:warning/square_summon {scale_x:3.0,scale_z:1.0,et:10}
# ==========================================

# 在敌人前方3格的地面召唤潜影壳显示实体，直接显示最终大小
# 旋转后 Y轴变成了长度，X轴是宽度，Z轴是厚度
$summon item_display ^ ^0.1 ^3 {\
Tags:["square_warning","square_warning_new","warning"],\
transformation:{scale:[$(scale_x)f,$(scale_z)f,1.0f],translation:[0f,0f,0f],left_rotation:[0.7071f,0f,0f,0.7071f],right_rotation:[0f,0f,0f,1f]},\
item:{id:"minecraft:shulker_shell",Count:1b},\
billboard:"fixed",\
brightness:{sky:15,block:15}\
}

# 设置生命周期
$scoreboard players set @e[tag=square_warning_new] temp $(et)

# 移除new标签
tag @e[tag=square_warning_new] remove square_warning_new

# 播放警告音效
playsound block.note_block.bass hostile @a[distance=..15] ^ ^0.1 ^3 0.8 0.5

# 生成警告粒子
particle dust 1.0 0.0 0.0 1.0 ^ ^0.1 ^3 0.5 0.05 0.5 0 10 force
