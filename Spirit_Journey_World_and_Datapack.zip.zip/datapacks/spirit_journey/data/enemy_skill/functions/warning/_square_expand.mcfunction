# ==========================================
# 方形攻击预警 - 触发放大动画（宏函数版本）
# 在召唤后1tick执行，修改transformation让interpolation生效
# 参数：
#   scale_x: X轴最终缩放
#   scale_z: Z轴最终缩放
# ==========================================

# 修改所有新召唤的方形预警，让它们放大到指定大小
$execute as @e[tag=square_warning_new] run data modify entity @s transformation.scale set value [$(scale_x)f,1.0f,$(scale_z)f]

# 移除new标签
tag @e[tag=square_warning_new] remove square_warning_new
