# ==========================================
# 圆形攻击预警 - 每tick管理（宏函数版本）
# 控制预警标记的生命周期和消失
# ==========================================

# 生命周期倒计时
scoreboard players remove @s temp 1

# 生命周期结束时造成伤害并消失
execute if score @s temp matches ..0 store result storage circle:warning radius int 1 run scoreboard players get @s radius
execute if score @s temp matches ..0 store result storage circle:warning damage int 1 run scoreboard players get @s damage
execute if score @s temp matches ..0 run function enemy_skill:warning/circle_warn/damage_apply with storage circle:warning
execute if score @s temp matches ..0 run particle cloud ~ ~0.5 ~ 0.5 0.1 0.5 0.05 10 force
execute if score @s temp matches ..0 run kill @s
