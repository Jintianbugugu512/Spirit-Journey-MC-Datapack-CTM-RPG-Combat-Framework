# ==========================================
# 圆形攻击预警 - 召唤（宏函数版本）
# 在敌人脚下召唤一个圆形预警标记
# 直接显示最终形态，停留后消失并造成伤害
#
# 调用格式：
#   function enemy_skill:warning/circle_summon {r:数字,et:数字,d:数字}
#
# 参数说明：
#   r: 半径，1.0 = 1格
#   et: 存在时间（exist time），单位tick
#   d: 伤害值（damage），消失时对范围内玩家造成的伤害
#      - 填入具体数值：自动造成伤害（如 d:8）
#      - 填入 d:0：不造成伤害，用于手动调用伤害函数
#
# 使用场景：
#   1. 标准圆形攻击：直接填入伤害值 d:8
#   2. 非正圆形攻击：填入 d:0，然后手动召唤多个圆形预警拟合复杂范围
#
# 调用示例：
#   # 标准半径2格圆形，20tick停留，8点伤害
#   execute as @e[tag=敌人] at @s run function enemy_skill:warning/circle_summon {r:2.0,et:20,d:8}
#
#   # 大范围半径4格，长时间停留（40tick），12点伤害
#   execute as @e[tag=敌人] at @s run function enemy_skill:warning/circle_summon {r:4.0,et:40,d:12}
#
#   # 用于拟合复杂形状，不自动造成伤害（手动控制）
#   execute as @e[tag=敌人] at @s run function enemy_skill:warning/circle_summon {r:2.0,et:20,d:0}
#   # 然后在技能函数中手动判定伤害范围
# ==========================================

# 在敌人脚下召唤粘液球显示实体，直接显示最终大小
# left_rotation 旋转90度让圆形平铺在地面
$summon item_display ~ ~0.05 ~ {\
Tags:["circle_warning","circle_warning_new","warning"],\
transformation:{scale:[$(r)f,$(r)f,0.1f],translation:[0f,0f,0f],left_rotation:[0.7071f,0f,0f,0.7071f],right_rotation:[0f,0f,0f,1f]},\
item:{id:"minecraft:slime_ball",Count:1b},\
billboard:"fixed",\
brightness:{sky:15,block:15}\
}

# 设置生命周期、半径和伤害参数
$scoreboard players set @e[tag=circle_warning_new] temp $(et)
$scoreboard players set @e[tag=circle_warning_new] radius $(r)
$scoreboard players set @e[tag=circle_warning_new] damage $(d)

# 移除new标签
tag @e[tag=circle_warning_new] remove circle_warning_new

# 播放警告音效
playsound block.note_block.bass hostile @a[distance=..15] ~ ~0.05 ~ 0.8 0.7

# 生成警告粒子
particle dust 1.0 0.0 0.0 1.0 ~ ~0.1 ~ 0.3 0.05 0.3 0 15 force
