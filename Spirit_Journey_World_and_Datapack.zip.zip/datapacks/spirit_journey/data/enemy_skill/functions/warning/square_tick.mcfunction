# ==========================================
# 方形攻击预警 - 每tick管理
# 控制预警标记的生命周期和消失
# ==========================================

# 生命周期倒计时
scoreboard players remove @s temp 1

# 生命周期结束时消失
execute if score @s temp matches ..0 run particle cloud ~ ~0.5 ~ 0.5 0.1 0.5 0.05 10 force
execute if score @s temp matches ..0 run kill @s
