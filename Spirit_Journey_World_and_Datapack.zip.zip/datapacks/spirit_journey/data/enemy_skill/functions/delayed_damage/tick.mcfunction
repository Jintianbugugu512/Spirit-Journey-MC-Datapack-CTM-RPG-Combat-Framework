scoreboard players remove @s temp 1
execute if score @s temp matches ..0 store result storage delayed:damage radius int 1 run scoreboard players get @s radius
execute if score @s temp matches ..0 store result storage delayed:damage damage int 1 run scoreboard players get @s damage
execute if score @s temp matches ..0 run function enemy_skill:delayed_damage/damage_apply with storage delayed:damage
execute if score @s temp matches ..0 run kill @s
