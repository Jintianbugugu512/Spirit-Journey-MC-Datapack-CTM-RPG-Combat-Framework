$execute as @a[distance=..$(radius)] run damage @s $(damage) minecraft:cactus
