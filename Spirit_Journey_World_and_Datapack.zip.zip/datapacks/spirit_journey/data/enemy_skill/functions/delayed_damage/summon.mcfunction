# ==========================================
# 延迟伤害 - 召唤（宏函数版本）
# 在指定位置召唤一个不可见的延迟伤害实体
# 倒计时结束后对范围内玩家造成伤害
#
# 调用格式：
#   function enemy_skill:delayed_damage/summon {r:半径,d:伤害,t:延迟}
#
# 参数说明：
#   r: 半径（格）
#   d: 伤害值
#   t: 延迟时间（tick）
#
# 调用示例：
#   execute as @e[tag=boss] at @s run function enemy_skill:delayed_damage/summon {r:2,d:8,t:20}
#   execute as @e[tag=elite] at @s run function enemy_skill:delayed_damage/summon {r:3,d:12,t:40}
# ==========================================

summon marker ~ ~ ~ {Tags:["delayed_damage","delayed_damage_new"]}
$scoreboard players set @e[tag=delayed_damage_new] temp $(t)
$scoreboard players set @e[tag=delayed_damage_new] radius $(r)
$scoreboard players set @e[tag=delayed_damage_new] damage $(d)
tag @e[tag=delayed_damage_new] remove delayed_damage_new