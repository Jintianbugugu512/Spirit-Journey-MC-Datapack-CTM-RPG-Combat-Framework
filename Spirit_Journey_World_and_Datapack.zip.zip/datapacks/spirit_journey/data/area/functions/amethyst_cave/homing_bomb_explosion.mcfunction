# ==========================================
# 追踪炮弹 - 爆炸效果
# 3格范围内对最多3个敌人造成30点真实伤害
# ==========================================

# 标记范围内最多3个敌人
tag @e[tag=enemy,distance=..3,limit=3,sort=nearest] add scene_bomb_explosion_target

# 对每个目标造成30点真实伤害
execute as @e[tag=scene_bomb_explosion_target] run damage @s 30 minecraft:cactus

# 清除目标标签
tag @e[tag=scene_bomb_explosion_target] remove scene_bomb_explosion_target

# 小型爆炸视觉效果（火炮风格）
particle explosion ~ ~ ~ 0.5 0.5 0.5 0 5
particle flame ~ ~ ~ 1.5 1.5 1.5 0.1 50
particle lava ~ ~ ~ 1 1 1 0 20
particle large_smoke ~ ~ ~ 1 1 1 0.05 30
particle dust 1.0 0.3 0.0 1.5 ~ ~ ~ 1 1 1 0 40

# 音效（小型爆炸）
playsound entity.generic.explode player @a ~ ~ ~ 1.2 1.2
playsound entity.firework_rocket.blast player @a ~ ~ ~ 1 0.8

# 清除子弹
kill @s
