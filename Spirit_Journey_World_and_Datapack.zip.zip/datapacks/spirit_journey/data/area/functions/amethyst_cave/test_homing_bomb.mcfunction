# ==========================================
# 测试追踪炮弹
# 在玩家位置发射炮弹
# 使用方法: /function area:amethyst_cave/test_homing_bomb
# ==========================================

execute as @a at @s run function area:amethyst_cave/homing_bomb
tellraw @a [{"text":"[测试] ","color":"yellow"},{"text":"已在玩家位置发射追踪炮弹！","color":"white"}]
