# ==========================================
# 场景机制 - 移除区域发光标签
# 由 area_glow 在5秒后自动调用
# ==========================================

tag @e[tag=area_glow_mark] remove can_glow
tag @e[tag=area_glow_mark] remove area_glow_mark
