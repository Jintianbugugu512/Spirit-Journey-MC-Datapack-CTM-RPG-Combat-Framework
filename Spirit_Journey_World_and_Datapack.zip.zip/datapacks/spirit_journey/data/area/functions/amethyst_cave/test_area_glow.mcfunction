# ==========================================
# 测试区域发光
# 在玩家位置周围10格敌人发光
# 使用方法: /function area:amethyst_cave/test_area_glow
# ==========================================

execute as @a at @s run function area:amethyst_cave/area_glow
tellraw @a [{"text":"[测试] ","color":"yellow"},{"text":"已触发区域发光！","color":"white"}]
