# ==========================================
# 场景机制 - 区域发光
# 让调用位置周围10格的敌人发光5秒
# 调用方式: execute positioned X Y Z run function area:amethyst_cave/area_glow
# ==========================================

# 检查10格内是否有敌人
execute unless entity @e[tag=enemy,distance=..10] run return 0

# 给周围10格内的敌人添加发光效果（5秒 = 100tick）和 can_glow 标签
tag @e[tag=enemy,distance=..10] add can_glow
tag @e[tag=enemy,distance=..10] add area_glow_mark
effect give @e[tag=enemy,distance=..10] glowing 5 0 true

# 音效
playsound block.beacon.power_select ambient @a ~ ~ ~ 1 1.5
playsound entity.experience_orb.pickup ambient @a ~ ~ ~ 1 0.8

# 视觉反馈：在每个被高亮的敌人位置播放粒子
execute as @e[tag=area_glow_mark] at @s run particle end_rod ~ ~1 ~ 0.5 0.8 0.5 0.1 20 force
execute as @e[tag=area_glow_mark] at @s run particle flash ~ ~1 ~ 0 0 0 0 1 force

# 中心位置特效
particle end_rod ~ ~1 ~ 3 1 3 0.1 50 force
particle electric_spark ~ ~1 ~ 3 1 3 0 30 force

# 5秒后移除标签
schedule function area:amethyst_cave/remove_area_glow 100t
