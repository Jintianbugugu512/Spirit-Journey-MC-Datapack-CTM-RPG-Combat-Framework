# ==========================================
# 追踪炮弹 - 场景机制技能
# 锁定20格内随机1个敌人发射炮弹
# 击中后3格范围内对最多3个敌人造成30点真实伤害
# 调用方式: execute positioned X Y Z run function area:amethyst_cave/homing_bomb
# ==========================================

# 检查20格内是否有敌人
execute unless entity @e[tag=enemy,distance=..20] run return 0

# 随机选择20格内1个敌人作为目标
tag @e[tag=enemy,distance=..20,limit=1,sort=random] add scene_bomb_target

# 音效（小型火炮发射）
playsound entity.firework_rocket.launch ambient @a ~ ~ ~ 1.5 0.8
playsound entity.blaze.shoot ambient @a ~ ~ ~ 1 1.2

# 召唤光灵箭（炮弹）- 朝向目标身体中心
execute facing entity @e[tag=scene_bomb_target,limit=1] feet run summon spectral_arrow ~ ~0.5 ~ {Tags:["summon","scene_bomb_bullet"],NoGravity:1b,Glowing:1b,PortalCooldown:100,PierceLevel:10,damage:0,crit:false,Color:16744192}

# 计算飞行方向（使用临时marker，速度1.0）
execute facing entity @e[tag=scene_bomb_target,limit=1] feet positioned 0.0 0.0 0.0 run summon marker ^ ^ ^1.0 {Tags:["mmark__"]}
execute as @e[tag=summon] run data modify entity @s Motion set from entity @e[limit=1,tag=mmark__] Pos

# 设置子弹寿命（120 tick）
scoreboard players set @e[tag=summon] temp 120

# 清理临时实体和标签
tag @e[tag=summon] remove summon
tag @e[tag=scene_bomb_target] remove scene_bomb_target
kill @e[tag=mmark__,type=marker]
