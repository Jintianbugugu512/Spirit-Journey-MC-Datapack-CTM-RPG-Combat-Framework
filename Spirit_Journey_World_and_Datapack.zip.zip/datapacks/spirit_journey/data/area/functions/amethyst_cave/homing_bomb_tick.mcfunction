# ==========================================
# 追踪炮弹 - 子弹移动与碰撞检测
# 每tick生成小型火炮粒子轨迹
# 检测是否命中敌人
# ==========================================

# 小型火炮粒子轨迹
particle flame ~ ~ ~ 0.2 0.2 0.2 0.02 5 force
particle lava ~ ~ ~ 0.1 0.1 0.1 0 1 force
particle smoke ~ ~ ~ 0.15 0.15 0.15 0.01 2 force
particle dust 1.0 0.5 0.0 0.8 ~ ~ ~ 0.1 0.1 0.1 0 3 force

# 子弹寿命递减
scoreboard players remove @s temp 1

# 超时自动清除
execute if score @s temp matches ..0 run kill @s

# 检测是否命中敌人（2.5格范围）
execute if entity @e[tag=enemy,distance=..2.5] run function area:amethyst_cave/homing_bomb_explosion
