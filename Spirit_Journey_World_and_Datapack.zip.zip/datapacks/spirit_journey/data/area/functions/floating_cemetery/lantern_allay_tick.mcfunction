# ==========================================
# 持灯悦灵 - 周围8格敌人发光
# 每tick执行，持续给周围敌人添加发光效果
# ==========================================

# 给周围8格内的敌人添加发光效果（2秒 = 40tick）和 can_glow 标签
tag @e[tag=enemy,distance=..8] add can_glow
effect give @e[tag=enemy,distance=..8] glowing 2 0 true

# 每20tick播放一次环境粒子效果
scoreboard players add @s temp2 1
execute if score @s temp2 matches 20.. run particle soul_fire_flame ~ ~0.5 ~ 0.3 0.3 0.3 0.02 5 force
execute if score @s temp2 matches 20.. run particle soul ~ ~0.5 ~ 0.4 0.4 0.4 0.01 3 force
execute if score @s temp2 matches 20.. run scoreboard players set @s temp2 0
