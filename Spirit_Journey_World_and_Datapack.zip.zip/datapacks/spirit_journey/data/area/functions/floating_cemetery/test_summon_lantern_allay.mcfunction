# ==========================================
# 测试召唤持灯悦灵
# 在玩家位置召唤一只持灯悦灵
# 使用方法: /function area:floating_cemetery/test_summon_lantern_allay
# ==========================================

summon allay ~ ~ ~ {Tags:["hold_lantern"],CustomName:'{"text":"持灯悦灵","color":"aqua"}'}
scoreboard players set @e[tag=hold_lantern,limit=1,sort=nearest] temp2 0
tellraw @a [{"text":"[测试] ","color":"yellow"},{"text":"已召唤持灯悦灵！","color":"aqua"}]
particle soul_fire_flame ~ ~1 ~ 0.5 0.5 0.5 0.1 30 force
