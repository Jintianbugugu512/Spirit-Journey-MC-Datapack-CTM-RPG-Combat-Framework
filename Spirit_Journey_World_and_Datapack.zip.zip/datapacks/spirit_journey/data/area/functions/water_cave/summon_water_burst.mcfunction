# ==========================================
# 召唤水崩实体
# 创建一个持续12秒的腐蚀性水雾区域
# 执行者：任意实体（通常是被击中的标靶方块）
# ==========================================

# 召唤marker实体
summon marker ~ ~ ~ {Tags:["water_burst","summon"]}

# 设置存在时间（12秒 = 240 tick）
scoreboard players set @e[tag=summon,limit=1,sort=nearest] temp 240

# 清除临时标签
tag @e[tag=summon] remove summon

# 视觉和音效反馈
particle splash ~ ~1 ~ 1 1 1 1 50 force
particle falling_water ~ ~2 ~ 1.5 1 1.5 0.3 100 force
playsound block.water.ambient block @a ~ ~ ~ 2 0.8
playsound entity.generic.splash block @a ~ ~ ~ 2 1
