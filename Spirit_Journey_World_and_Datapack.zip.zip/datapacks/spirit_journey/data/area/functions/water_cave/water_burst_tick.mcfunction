# ==========================================
# 水崩实体 Tick 函数
# 每tick执行的效果和碰撞检测
# 执行者：水崩marker实体
# ==========================================

# 粒子效果 - 周围3格内高密度水滴
particle splash ~ ~1 ~ 0.5 0.5 0.5 0.3 8 force
particle falling_water ~ ~1.5 ~ 0.8 0.8 0.8 0.2 6 force

# 粒子效果 - 周围8格内中量散开的水滴（甩水效果）
execute positioned ~3 ~ ~ run particle splash ~ ~1 ~ 0.3 0.3 0.3 0.1 2 force
execute positioned ~-3 ~ ~ run particle splash ~ ~1 ~ 0.3 0.3 0.3 0.1 2 force
execute positioned ~ ~ ~3 run particle splash ~ ~1 ~ 0.3 0.3 0.3 0.1 2 force
execute positioned ~ ~ ~-3 run particle splash ~ ~1 ~ 0.3 0.3 0.3 0.1 2 force
execute positioned ~2 ~ ~2 run particle splash ~ ~1 ~ 0.3 0.3 0.3 0.1 2 force
execute positioned ~-2 ~ ~2 run particle splash ~ ~1 ~ 0.3 0.3 0.3 0.1 2 force
execute positioned ~2 ~ ~-2 run particle splash ~ ~1 ~ 0.3 0.3 0.3 0.1 2 force
execute positioned ~-2 ~ ~-2 run particle splash ~ ~1 ~ 0.3 0.3 0.3 0.1 2 force

# 对范围内的敌人施加破防buff（3秒 = 60 tick）
execute as @e[tag=enemy,distance=..8] run scoreboard players set @s defense_reduce_duration 60

# 生命周期管理
scoreboard players remove @s temp 1
execute if score @s temp matches ..0 run kill @s

# 每20tick播放一次环境音效
execute if score @s temp matches 0 run playsound block.water.ambient block @a ~ ~ ~ 1 0.8
execute if score @s temp matches 20 run playsound block.water.ambient block @a ~ ~ ~ 1 0.8
execute if score @s temp matches 40 run playsound block.water.ambient block @a ~ ~ ~ 1 0.8
execute if score @s temp matches 60 run playsound block.water.ambient block @a ~ ~ ~ 1 0.8
execute if score @s temp matches 80 run playsound block.water.ambient block @a ~ ~ ~ 1 0.8
execute if score @s temp matches 100 run playsound block.water.ambient block @a ~ ~ ~ 1 0.8
execute if score @s temp matches 120 run playsound block.water.ambient block @a ~ ~ ~ 1 0.8
execute if score @s temp matches 140 run playsound block.water.ambient block @a ~ ~ ~ 1 0.8
execute if score @s temp matches 160 run playsound block.water.ambient block @a ~ ~ ~ 1 0.8
execute if score @s temp matches 180 run playsound block.water.ambient block @a ~ ~ ~ 1 0.8
execute if score @s temp matches 200 run playsound block.water.ambient block @a ~ ~ ~ 1 0.8
execute if score @s temp matches 220 run playsound block.water.ambient block @a ~ ~ ~ 1 0.8
