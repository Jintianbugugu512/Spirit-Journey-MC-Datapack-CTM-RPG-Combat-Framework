# ==========================================
# Entity Manager - 实体主循环管理器
# 每tick执行，管理所有非玩家实体的行为
# ==========================================

# ==================== 敌人系统 ====================

# 敌人血量限制（不超过最大值）
execute as @e[tag=enemy] at @s run execute if score @s current_health >= @s max_health run scoreboard players operation @s current_health = @s max_health

# 敌人血条与伤害显示
execute as @e[tag=enemy] at @s run function combat:healthbar/show_damage
execute as @e[tag=enemy] at @s run function combat:healthbar/update_healthbar_display

# 敌人发光效果管理（清除没有can_glow标签的发光）
effect clear @e[tag=enemy,tag=!can_glow] glowing

# 某些技能对敌人的受击冷却管理
execute as @e[tag=enemy,scores={hit_cooldown=1..}] run scoreboard players remove @s hit_cooldown 1

# ==================== Boss系统 ====================

# 紫晶核心Boss（区域优化：仅在玩家附近时执行）
execute if entity @a[x=-1013,y=100,z=1013,distance=..50] if entity @e[tag=chess_grid] run function boss:amethyst_core/chess_grid_tick
execute if entity @a[x=-1013,y=100,z=1013,distance=..50] as @e[tag=amethyst_core] at @s run function boss:amethyst_core/main

# 水滴骑士Boss（区域优化）
execute if entity @a[x=-824,y=100,z=1002,distance=..50] as @e[tag=water_knight] at @s run function boss:water_knight/main

# 铁面教官Boss（区域优化）
execute if entity @a[x=-651,y=100,z=1020,distance=..50] as @e[tag=iron_instructor] at @s run function boss:iron_instructor/main

# Boss血条清理系统（玩家远离时自动清空血条）
function boss:cleanup_bossbar

# ==================== 敌人技能实体 ====================
# 攻击预警系统
execute as @e[tag=square_warning] at @s run function enemy_skill:warning/square_warn/tick
execute as @e[tag=circle_warning] at @s run function enemy_skill:warning/circle_warn/tick
execute as @e[tag=purple_warning] at @s run function enemy_skill:warning/purple_warn/tick

# 延迟伤害
execute as @e[tag=delayed_damage] at @s run function enemy_skill:delayed_damage/tick

# ==================== 子弹系统 ====================

# 动量子弹（motion_bullet）
execute as @e[tag=motion_bullet] run function enemy_skill:bullet/motion_bullet/manage

# Y轴颠倒子弹（y_bullet）
execute as @e[tag=y_bullet] run function enemy_skill:bullet/y_bullet/manage

# 瞄准子弹（aim_item_bullet）
execute as @e[tag=aim_item_bullet] at @s on passengers run function enemy_skill:bullet/aim_bullet/item_bullet/check_collision

# ==================== Debuff管理 ====================

# - 减防buff
execute if entity @e[tag=enemy,scores={defense_reduce_duration=1..}] run function combat:debuff/defense_reduce/manager
# - 眩晕效果
execute if entity @e[tag=enemy,scores={stun=1..}] run function combat:debuff/stun/manager
# - 燃烧伤害（无条件调用，因为需要每tick读取原生Fire值,如果用nbt查询燃烧的话开销又会变大）
function combat:debuff/burn/manager

# ==================== 场景机制 ====================

# 场景追踪炮弹
execute as @e[tag=scene_bomb_bullet] at @s run function area:amethyst_cave/homing_bomb_tick
# 水崩实体
execute as @e[tag=water_burst] at @s run function area:water_cave/water_burst_tick

# ==================== 区域特殊实体 ====================

# 漂浮墓地 - 持灯悦灵
execute as @e[tag=hold_lantern] at @s run function area:floating_cemetery/lantern_allay_tick


# ==================== 世界中的物品 ====================
execute as @e[type=item_display,tag=item_on_world] at @s run function display:item_show
execute as @e[type=interaction,tag=tp_point] at @s run function y_other:teleport/tp_point
execute as @e[type=interaction,tag=door] at @s run function y_other:z_budao/tran/door
