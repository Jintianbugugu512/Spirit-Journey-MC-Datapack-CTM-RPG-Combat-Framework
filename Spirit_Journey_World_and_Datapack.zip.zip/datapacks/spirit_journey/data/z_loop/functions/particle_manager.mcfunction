#早期开发用来统一管理粒子效果了,后期开发的粒子效果都写在相关模块里,不写这了.

execute as @e[tag=tp] at @s run particle squid_ink ~ ~ ~ 0.3 0.2 0.3 0 5
execute as @e[tag=tp_] at @s run particle glow_squid_ink ~ ~ ~ 0.3 0.2 0.3 0 5
execute as @e[tag=snipe_bullet_] at @s run particle end_rod ~ ~ ~ 0.3 0.2 0.3 0 2
execute as @e[tag=stick_bullet] at @s run particle enchant ~ ~ ~ 0.3 0.2 0.3 0 10
execute as @e[tag=light] at @s run particle end_rod ~ ~ ~ 0 0 0 0 1


execute as @a[scores={blood_buff=1..}] at @s run particle lava ~ ~ ~ 0.8 0.5 0.8 0 8