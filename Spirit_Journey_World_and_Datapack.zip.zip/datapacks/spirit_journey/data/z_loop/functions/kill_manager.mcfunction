#早期开发用来统一kill逻辑的,后期开发的kill逻辑都写在相关模块里,不写这了.

#倒计时实体归零死亡,到－1才击杀是为了应用时可以写0更好看,可以用countDown=1来表示"还剩最后1个tick执行特殊逻辑"，而不是用 countDown=0 来表示这个状态.
kill @e[scores={countDown=..-1}]

#清理落地箭矢
kill @e[type=arrow,nbt={inGround:1b}]
kill @e[type=minecraft:spectral_arrow,nbt={inGround:1b}]

#怪物死亡
# 触发亡语技能（死亡前执行）
execute as @e[tag=enemy,scores={current_health=..0}] at @s run function enemy_skill:deathrattle/manager
# 敌人死亡时给附近玩家增加击杀计数（用于战斗续航魂盘等）
execute as @e[tag=enemy,scores={current_health=..0}] at @s run scoreboard players add @a[distance=..15] kill_zombie 1
# 击杀敌人
kill @e[tag=enemy,scores={current_health=..0}]

#清除落下的物体
execute as @e[tag=fall] at @s unless block ~ ~-0.1 ~ air run kill @e[tag=fall]




