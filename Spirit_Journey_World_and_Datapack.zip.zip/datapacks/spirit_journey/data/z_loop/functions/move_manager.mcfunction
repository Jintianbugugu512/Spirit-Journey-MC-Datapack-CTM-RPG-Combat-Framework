#早期开发用来统一tp移动的,后期开发的移动逻辑都写在相关模块里,不写这了.



execute as @e[tag=tp,scores={countDown=3..}] at @s run function display:other/horizontal_orbit {"tag":"tp","r":4,"h":"0","speed":18}
execute as @e[tag=tp_,scores={countDown=3..}] at @s run function display:other/horizontal_orbit {"tag":"tp_","r":4,"h":"0","speed":"-18"}

execute as @e[tag=tp_pivot] at @s run tp ~ ~0.04 ~
execute as @e[tag=tp__pivot] at @s run tp ~ ~0.04 ~

execute as @e[tag=fall] at @s run tp ~ ~-0.1 ~



execute as @e[tag=damage_shower] at @s run tp ~ ~0.04 ~
execute as @e[tag=MP_shower_] at @s run tp ~ ~0.04 ~

#万剑归宗剑的传送
execute as @e[tag=sword_attacker] at @s rotated ~ ~ run tp @s ^-0.2 ^0.2 ^

#悬赏之刃剑的移动
execute as @e[tag=bounty_sword] at @s run function skill:sword_skill/bounty_blade/bounty_blade_move
