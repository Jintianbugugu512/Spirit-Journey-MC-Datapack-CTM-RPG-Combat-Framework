#早期开发用来统一管理tag添加的管理器,后期开发tag添加都写在相关模块里,不写这了.

#为与BOSS战斗中的玩家添加tag
execute as @a at @s if entity @e[distance=..50,tag=boss] run tag @s add battle_with_boss
execute as @a at @s unless entity @e[distance=..50,tag=boss] run tag @s remove battle_with_boss

#为敌方与我方弹射物增加tag
execute as @e[type=arrow] at @s on origin run execute if entity @s[type=player] run tag @e[type=arrow,distance=..0.1] add bullet_from_player
execute as @e[type=arrow] at @s on origin run execute if entity @s[tag=enemy] run tag @e[type=arrow,distance=..0.1] add bullet_from_enemy


