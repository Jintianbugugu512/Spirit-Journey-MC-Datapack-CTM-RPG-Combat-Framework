# ==========================================
# Execute Manager - 玩家主循环管理器
# 每tick执行，管理所有玩家的行为
# ==========================================


#对玩家执行 - 使用通用处理函数
execute as @a[tag=player_1] run function player:player_common {"id":"1"}
execute as @a[tag=player_2] run function player:player_common {"id":"2"}
execute as @a[tag=player_3] run function player:player_common {"id":"3"}

#玩家自身显示血量与伤害显示
execute as @a at @s run function combat:healthbar/damage_show_fp/show_damage_fp

#消耗品与战斗系统管理
function combat:consumable/manage
#对话系统
function talk:talk_manager
#技能cd/最大mp限制
function skill:cd/manager

#player_common->player:click_detect,在此处重置click_detect中的相关检测变量
scoreboard players set @a put_shift 0
scoreboard players set @a jump 0
tag @a remove left_click
tag @a remove right_click












