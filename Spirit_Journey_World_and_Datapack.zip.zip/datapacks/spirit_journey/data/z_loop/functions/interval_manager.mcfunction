#用于处理间隔   /  间隔的函数调用

scoreboard players add @a[scores={interval_pos_record=..10}] interval_pos_record 1
scoreboard players set @a[scores={interval_pos_record=10..}] interval_pos_record 0


scoreboard players remove @a[scores={interval_can_tp=1..}] interval_can_tp 1

scoreboard players remove @a[scores={interval_output=1..}] interval_output 1


scoreboard players remove @a[scores={can_be_effect=1..}] can_be_effect 1

scoreboard players remove @a[scores={knowledge_power=1..}] knowledge_power 1

scoreboard players remove @e[scores={countDown=0..}] countDown 1

scoreboard players remove @e[scores={interval_stick=1..}] interval_stick 1


# 每100tick重置敌人原版血量（防止因原版血量耗尽而死亡）
scoreboard players add #health_reset_timer temp 1
execute if score #health_reset_timer temp matches 100.. run function combat:healthbar/reset_enemy_health
execute if score #health_reset_timer temp matches 100.. run scoreboard players set #health_reset_timer temp 0

# 每5tick管理技能槽位占位符
scoreboard players add #slot_timer temp 1
execute if score #slot_timer temp matches 5.. run function skill:manage_skill_slots
execute if score #slot_timer temp matches 5.. run scoreboard players set #slot_timer temp 0
