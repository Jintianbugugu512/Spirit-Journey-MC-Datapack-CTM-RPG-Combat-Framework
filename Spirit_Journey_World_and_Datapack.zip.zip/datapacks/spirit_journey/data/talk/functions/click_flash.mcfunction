# ==========================================
# 对话系统 - 点击闪光特效
# 玩家右键点击对话实体时触发的闪光粒子效果
# ==========================================

# 白色爆炸闪光（中心爆发）
particle flash ~ ~0.75 ~ 0 0 0 0 1 force

# 金色光芒散射（外扩）
particle end_rod ~ ~0.75 ~ 0.3 0.3 0.3 0.15 15 force
particle dust 1 1 0.7 1.5 ~ ~0.75 ~ 0.4 0.4 0.4 0 20 force

# 白色闪烁粒子（快速扩散）
particle glow ~ ~0.75 ~ 0.5 0.5 0.5 0.1 10 force

# 音效：成功点击音效
playsound minecraft:block.amethyst_block.chime block @a[distance=..10] ~ ~ ~ 1 1.5
playsound minecraft:entity.experience_orb.pickup block @a[distance=..10] ~ ~ ~ 0.5 1.8
