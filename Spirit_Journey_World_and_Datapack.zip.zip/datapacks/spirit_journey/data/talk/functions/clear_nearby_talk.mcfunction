# ==========================================
# 清除附近的对话实体
# 由玩家调用，删除5格半径内的所有对话interaction与marker
#
# 调用方式：
#   /function talk:clear_nearby_talk
# ==========================================

# 删除5格半径内的对话interaction实体
execute as @s at @s run kill @e[type=interaction,tag=talk,distance=..5]

# 删除5格半径内的对话粒子marker
execute as @s at @s run kill @e[type=marker,tag=talk_particle,distance=..5]

# 反馈信息
tellraw @s [{"text":"[系统] ","color":"yellow"},{"text":"已清除周围5格内的对话实体","color":"gray"}]
