# ==========================================
# 删除对话实体及其粒子marker
# ==========================================

# 获取自己的所有tag，找到对应的粒子marker
execute as @s[tag=test_talk] run kill @e[tag=test_talk_particle]

# 通用删除逻辑 - 删除所有与此interaction关联的粒子
execute at @s run kill @e[type=marker,tag=talk_particle,distance=..2]

# 删除自己
kill @s
