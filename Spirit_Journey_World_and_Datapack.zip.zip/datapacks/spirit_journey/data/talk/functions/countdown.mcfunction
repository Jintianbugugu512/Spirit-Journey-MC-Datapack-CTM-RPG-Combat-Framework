# ==========================================
# 对话系统 - 倒计时
# 每tick递减temp分数，并调用对应的对话内容
# ==========================================

# 递减temp（先递减，避免dialogue_end归零后再减变成负数）
scoreboard players remove @s temp 1

# 根据标签调用对应的对话内容
execute if entity @s[tag=test_talk] run function talk:dialogue/test_talk

# 在这里添加更多对话分发
# execute if entity @s[tag=merchant_talk] run function talk:dialogue/merchant_talk
# execute if entity @s[tag=guard_talk] run function talk:dialogue/guard_talk
