# ==========================================
# 对话结束处理
# 根据isloop决定是归零（可重复）还是删除实体
# ==========================================

# isloop = 1: 归零，可重复对话
execute if score @s isloop matches 1 run scoreboard players set @s temp 0

# isloop = 0: 删除实体及其粒子marker
execute if score @s isloop matches 0 as @s at @s run function talk:kill_talk_entity
