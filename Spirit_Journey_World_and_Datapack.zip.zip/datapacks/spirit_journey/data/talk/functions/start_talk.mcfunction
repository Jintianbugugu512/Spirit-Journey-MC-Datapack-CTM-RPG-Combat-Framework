# ==========================================
# 对话系统 - 开始对话
# 根据实体的标签分发到对应的对话函数并设置初始temp值
# ==========================================

# 测试对话NPC
execute if entity @s[tag=test_talk] run scoreboard players set @s temp 200

# 在这里添加更多对话实体的分发
# execute if entity @s[tag=merchant_talk] run scoreboard players set @s temp 300
# execute if entity @s[tag=guard_talk] run scoreboard players set @s temp 250
