# ==========================================
# 对话系统 - 右键点击检测
# 检测玩家是否右键点击了对话实体
# ==========================================

# 读取 interaction.timestamp
execute store result score @s detect_right1 run data get entity @s interaction.timestamp

# 如果有新的交互且temp为0（未在对话中），触发对话和闪光特效
scoreboard players set #zero temp 0
execute if score @s detect_right1 > #zero temp if score @s temp matches 0 run function talk:start_talk
execute if score @s detect_right1 > #zero temp if score @s temp matches 0 at @s run function talk:click_flash

# 清除交互数据
data remove entity @s interaction
