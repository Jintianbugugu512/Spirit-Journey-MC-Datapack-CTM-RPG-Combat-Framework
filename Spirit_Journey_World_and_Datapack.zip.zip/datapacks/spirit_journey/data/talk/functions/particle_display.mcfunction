# ==========================================
# 粒子特效管理器
# 为所有talk_particle标记的marker显示粒子特效
# 根据isloop显示不同的粒子效果
# ==========================================

# 获取对应interaction实体的isloop值
execute at @s positioned ~ ~-0.75 ~ as @e[type=interaction,tag=talk,distance=..0.1,limit=1] run scoreboard players operation @e[type=marker,tag=talk_particle,distance=..1,limit=1] isloop = @s isloop

# isloop = 1: 可重复对话 - 红色发光球体（重要、持续存在）
execute if score @s isloop matches 1 run particle end_rod ~ ~ ~ 0.15 0.15 0.15 0.02 2 normal
execute if score @s isloop matches 1 run particle dust 1 0.2 0.2 1.2 ~ ~ ~ 0.2 0.2 0.2 0 4 normal
execute if score @s isloop matches 1 run particle dust 1 0.4 0.3 1 ~ ~ ~ 0.15 0.15 0.15 0 2 normal

# isloop = 0: 一次性对话 - 绿色发光球体（友好、任务提示）
execute if score @s isloop matches 0 run particle end_rod ~ ~ ~ 0.15 0.15 0.15 0.02 2 normal
execute if score @s isloop matches 0 run particle dust 0.3 1 0.5 1.2 ~ ~ ~ 0.2 0.2 0.2 0 4 normal
execute if score @s isloop matches 0 run particle glow ~ ~ ~ 0.1 0.1 0.1 0 1 normal

# 缓慢旋转动画（通用）
execute at @s run tp @s ~ ~ ~ ~3 ~
