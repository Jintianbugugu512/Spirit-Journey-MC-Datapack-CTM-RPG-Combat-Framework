# ==========================================
# 测试对话NPC - test_talk
# 一个简单的对话示例
# ==========================================

# 第一句话 (temp = 200)
execute if score @s temp matches 200 run tellraw @a [{"text":"[神秘旅者] ","color":"gold"},{"text":"你好，冒险者。","color":"white"}]

# 第二句话 (temp = 160)
execute if score @s temp matches 160 run tellraw @a [{"text":"[神秘旅者] ","color":"gold"},{"text":"欢迎来到生灵之旅的世界。","color":"white"}]

# 第三句话 (temp = 120)
execute if score @s temp matches 120 run tellraw @a [{"text":"[神秘旅者] ","color":"gold"},{"text":"这里充满了危险与机遇...","color":"white"}]

# 第四句话 (temp = 80)
execute if score @s temp matches 80 run tellraw @a [{"text":"[神秘旅者] ","color":"gold"},{"text":"你准备好面对挑战了吗？","color":"white"}]

# 第五句话 (temp = 40)
execute if score @s temp matches 40 run tellraw @a [{"text":"[神秘旅者] ","color":"gold"},{"text":"那么，祝你好运！","color":"aqua"}]

# 对话结束时处理（temp已经被countdown减到0了）
execute if score @s temp matches 0 run function talk:dialogue_end
