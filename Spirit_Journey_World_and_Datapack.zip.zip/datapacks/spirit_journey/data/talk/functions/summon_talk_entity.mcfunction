# ==========================================
# 通用召唤对话交互实体（宏函数）
# 召唤一个只有粒子特效的对话实体
#
# 参数：
#   n: 名字（用作实体的tag）
#   isloop: 0=对话后删除, 1=可重复对话
#
# 调用示例：
#   execute at @s run function talk:summon_talk_entity {n:"merchant",isloop:1}
#   execute at @s run function talk:summon_talk_entity {n:"quest_giver",isloop:0}
# ==========================================

# 召唤interaction实体（用于检测右键）
$summon interaction ~ ~ ~ {width:1.0,height:1.5,response:true,Tags:["talk","$(n)"]}

# 初始化temp分数为0
$scoreboard players set @e[tag=$(n),limit=1,sort=nearest] temp 0

# 设置isloop标记（0或1）
$scoreboard players set @e[tag=$(n),limit=1,sort=nearest] isloop $(isloop)

# 召唤粒子显示用的marker（在interaction中心）
$summon marker ~ ~0.75 ~ {Tags:["talk_particle","$(n)_particle"]}

# 同步isloop到marker
$scoreboard players set @e[tag=$(n)_particle,limit=1,sort=nearest] isloop $(isloop)

tellraw @a[distance=..10] [{"text":"[系统] ","color":"yellow"},{"text":"对话实体 ","color":"gray"},{"text":"$(n)","color":"aqua"},{"text":" 已召唤 ","color":"gray"},{"text":"(isloop=$(isloop))","color":"dark_gray"}]
