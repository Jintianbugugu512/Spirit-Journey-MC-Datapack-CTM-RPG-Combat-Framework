# ==========================================
# 对话系统 - 右键检测与倒计时管理
# 在 player_manager 中调用
# ==========================================

# 检测所有对话实体的右键交互
execute as @e[type=interaction,tag=talk] at @s run function talk:detect_click

# 对所有正在对话的实体进行倒计时
execute as @e[tag=talk,scores={temp=1..}] at @s run function talk:countdown

# 显示所有对话实体的粒子特效
execute as @e[type=marker,tag=talk_particle] at @s run function talk:particle_display
