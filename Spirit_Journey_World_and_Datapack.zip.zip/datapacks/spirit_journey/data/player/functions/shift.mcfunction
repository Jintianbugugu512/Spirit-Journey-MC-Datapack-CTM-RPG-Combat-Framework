#探测玩家释放技能
# 剑技能：使用玩家专用触发器（硬编码 storage）
execute as @a[tag=left_click,tag=player_1,nbt={SelectedItem:{id:"minecraft:iron_sword"}}] at @s run function skill:trigger/sword_skill_trigger_1
execute as @a[tag=left_click,tag=player_2,nbt={SelectedItem:{id:"minecraft:iron_sword"}}] at @s run function skill:trigger/sword_skill_trigger_1
execute as @a[tag=left_click,tag=player_3,nbt={SelectedItem:{id:"minecraft:iron_sword"}}] at @s run function skill:trigger/sword_skill_trigger_1

execute as @a[scores={jump=1..},tag=player_1,nbt={SelectedItem:{id:"minecraft:iron_sword"}}] at @s run function skill:trigger/sword_skill_trigger_2
execute as @a[scores={jump=1..},tag=player_2,nbt={SelectedItem:{id:"minecraft:iron_sword"}}] at @s run function skill:trigger/sword_skill_trigger_2
execute as @a[scores={jump=1..},tag=player_3,nbt={SelectedItem:{id:"minecraft:iron_sword"}}] at @s run function skill:trigger/sword_skill_trigger_2

execute as @a[tag=right_click,tag=player_1,nbt={SelectedItem:{id:"minecraft:iron_sword"}}] at @s run function skill:trigger/sword_skill_trigger_3
execute as @a[tag=right_click,tag=player_2,nbt={SelectedItem:{id:"minecraft:iron_sword"}}] at @s run function skill:trigger/sword_skill_trigger_3
execute as @a[tag=right_click,tag=player_3,nbt={SelectedItem:{id:"minecraft:iron_sword"}}] at @s run function skill:trigger/sword_skill_trigger_3

execute as @a[tag=left_click,tag=player_1,nbt={SelectedItem:{id:"minecraft:netherite_sword"}}] at @s run function skill:trigger/sword_skill_trigger_1
execute as @a[tag=left_click,tag=player_2,nbt={SelectedItem:{id:"minecraft:netherite_sword"}}] at @s run function skill:trigger/sword_skill_trigger_1
execute as @a[tag=left_click,tag=player_3,nbt={SelectedItem:{id:"minecraft:netherite_sword"}}] at @s run function skill:trigger/sword_skill_trigger_1

execute as @a[scores={jump=1..},tag=player_1,nbt={SelectedItem:{id:"minecraft:netherite_sword"}}] at @s run function skill:trigger/sword_skill_trigger_2
execute as @a[scores={jump=1..},tag=player_2,nbt={SelectedItem:{id:"minecraft:netherite_sword"}}] at @s run function skill:trigger/sword_skill_trigger_2
execute as @a[scores={jump=1..},tag=player_3,nbt={SelectedItem:{id:"minecraft:netherite_sword"}}] at @s run function skill:trigger/sword_skill_trigger_2

execute as @a[tag=right_click,tag=player_1,nbt={SelectedItem:{id:"minecraft:netherite_sword"}}] at @s run function skill:trigger/sword_skill_trigger_3
execute as @a[tag=right_click,tag=player_2,nbt={SelectedItem:{id:"minecraft:netherite_sword"}}] at @s run function skill:trigger/sword_skill_trigger_3
execute as @a[tag=right_click,tag=player_3,nbt={SelectedItem:{id:"minecraft:netherite_sword"}}] at @s run function skill:trigger/sword_skill_trigger_3

# 弩技能：使用宏参数传递
$execute as @a[tag=left_click,tag=$(player),nbt={SelectedItem:{id:"minecraft:crossbow"}}] at @s run function skill:trigger/bow_skill_trigger_1 with storage damage:$(player)
$execute as @a[scores={jump=1..},tag=$(player),nbt={SelectedItem:{id:"minecraft:crossbow"}}] at @s run function skill:trigger/bow_skill_trigger_2 with storage damage:$(player)
$execute as @a[tag=right_click,tag=$(player),nbt={SelectedItem:{id:"minecraft:crossbow"}}] at @s run function skill:trigger/bow_skill_trigger_3 with storage damage:$(player)

# 杖技能：使用宏参数传递
# 散杖（胡萝卜钓竿）
$execute as @a[tag=left_click,tag=$(player),nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick"}}] at @s run function skill:trigger/stick_skill_trigger_1 with storage damage:$(player)
$execute as @a[scores={jump=1..},tag=$(player),nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick"}}] at @s run function skill:trigger/stick_skill_trigger_2 with storage damage:$(player)
$execute as @a[tag=right_click,tag=$(player),nbt={SelectedItem:{id:"minecraft:carrot_on_a_stick"}}] at @s run function skill:trigger/stick_skill_trigger_3 with storage damage:$(player)

# 凝杖（诡异菌钓竿）
$execute as @a[tag=left_click,tag=$(player),nbt={SelectedItem:{id:"minecraft:warped_fungus_on_a_stick"}}] at @s run function skill:trigger/stick_skill_trigger_1 with storage damage:$(player)
$execute as @a[scores={jump=1..},tag=$(player),nbt={SelectedItem:{id:"minecraft:warped_fungus_on_a_stick"}}] at @s run function skill:trigger/stick_skill_trigger_2 with storage damage:$(player)
$execute as @a[tag=right_click,tag=$(player),nbt={SelectedItem:{id:"minecraft:warped_fungus_on_a_stick"}}] at @s run function skill:trigger/stick_skill_trigger_3 with storage damage:$(player)
