$attribute @s generic.luck base set $(strength_)
$attribute @s generic.max_health base set $(max_HP)
$attribute @s generic.armor base set $(armor)

