#攻击属性设置
attribute @s generic.attack_damage base set 0.001
attribute @s generic.attack_speed base set 8


#攻击力属性设置
scoreboard players operation @s strength_ = @s strength

# 知识的力量buff（攻击力+50）
execute as @s[scores={knowledge_power=1..}] run scoreboard players add @s strength_ 50

# 决斗领域buff（攻击力+15）
execute as @s[scores={duel_domain_buff=1..}] run scoreboard players add @s strength_ 15

execute as @s[scores={blood_buff=1..}] run function skill:other_skill/blood/buff

# 亡者之怒buff（血量<20%时攻击力+15）
execute as @s[scores={wn_buff=1..}] run scoreboard players add @s strength_ 15

# execute as @s[scores={sword_rally_buff=1..}] run function skill:sword_skill/sword_rally/sword_rally_buff
#最大生命值属性设置
scoreboard players operation @s max_HP_ = @s max_HP

# 圣泉恩惠魂盘效果（最大生命值+15%）
execute if entity @s[nbt={Inventory:[{tag:{sd_id:"圣泉恩惠"}}]}] run function soul_disc:holy_spring/calculate_bonus

#护甲属性设置
scoreboard players operation @s armor_ = @s armor


execute as @s run execute store result storage player:attribute strength_ int 1 run scoreboard players get @s strength_
execute as @s run execute store result storage player:attribute max_HP int 1 run scoreboard players get @s max_HP_
execute as @s run execute store result storage player:attribute armor int 1 run scoreboard players get @s armor_
execute as @s run function player:attribute/set with storage player:attribute




