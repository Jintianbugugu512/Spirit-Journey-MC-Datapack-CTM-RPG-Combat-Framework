#player->1
# 检测下蹲+手持技能物品时生成交互实体
$execute as @s[scores={put_shift=1..},nbt={SelectedItem:{tag:{can_right_click:1b}}}] unless entity @e[tag=$(player)] run summon interaction ~ ~-0.5 ~ {Tags:["detect","$(player)"],height:0.3,width:0.3,response:true}

# 持续更新交互实体位置
$execute as @s anchored eyes run tp @e[tag=$(player)] ^ ^-0.15 ^0.3

# 不再下蹲时删除交互实体
$execute unless entity @s[scores={put_shift=1..}] run kill @e[tag=$(player)]


# 读取 interaction 的 timestamp
$execute store result score @s detect_left1 run data get entity @e[limit=1,tag=$(player)] attack.timestamp
$execute store result score @s detect_right1 run data get entity @e[limit=1,tag=$(player)] interaction.timestamp

# 设置零值用于比较
scoreboard players set #zero temp 0

# 只有当 timestamp > 0 时才添加标签（表示有新的交互）
$execute if score @s detect_left1 > #zero temp as @e[tag=$(player)] on attacker run tag @s add left_click
$execute if score @s detect_right1 > #zero temp as @e[tag=$(player)] on target run tag @s add right_click

# 清除交互数据，防止下一tick重复触发
$execute as @e[tag=$(player)] run data remove entity @s attack
$execute as @e[tag=$(player)] run data remove entity @s interaction

