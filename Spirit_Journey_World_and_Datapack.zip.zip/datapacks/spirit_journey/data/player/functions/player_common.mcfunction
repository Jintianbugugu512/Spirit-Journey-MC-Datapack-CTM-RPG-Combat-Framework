# 通用玩家处理函数 - 适用于所有玩家
# 通过宏参数 $(id) 动态处理不同玩家

# 反tp检查,interval_can_tp=0不可tp
$execute if entity @s[gamemode=adventure,scores={interval_can_tp=0},tag=!Mana] at @s run function anti_cheat:ban_tp {"player":"player_$(id)"}

# 点击检测
$execute at @s run function player:click_detect {"player":"detect_$(id)"}

# 魂盘
$execute at @s run function soul_disc:soul_manager with storage damage:player_$(id)

# 受伤检测系统
$function soul_disc:damage_reaction/check {"id":"$(id)"}

# 修改玩家的属性
execute at @s run function player:attribute/modify

# 知识的力量buff倒计时
execute if score @s knowledge_power matches 1.. run scoreboard players remove @s knowledge_power 1

# 技能释放
$execute if score @s put_shift matches 1.. at @s run function player:shift with storage damage:player_$(id)

# 统一技能检测（CD、Buff、子弹碰撞等）
$function skill:check_all_skills {"id":"$(id)"}

# 空中冲刺
#execute as @e[tag=airdash,type=arrow] at @s unless block ~ ~ ~ air run kill @s
#$execute as @e[tag=airdash_bullet_player_$(id),type=arrow] at @s as @a[tag=player_$(id)] run tp @s ~ ~ ~

# 三种武器的普通攻击
#单手剑普通攻击
$execute if entity @s[scores={use_IronSword=1..},nbt=!{Inventory:[{tag:{sd_id:"魔术置换"}}]}] at @s run function combat:attack_generic/sword with storage damage:player_$(id)
$execute if entity @s[scores={use_IronSword=1..},nbt={Inventory:[{tag:{sd_id:"魔术置换"}}]},tag=!overload] at @s run function combat:attack_generic/sword_ with storage damage:player_$(id)

# 刺剑普通攻击
$execute if entity @s[scores={use_NetheriteSword=1..},nbt=!{Inventory:[{tag:{sd_id:"魔术置换"}}]}] at @s run function combat:attack_generic/rapier with storage damage:player_$(id)
$execute if entity @s[scores={use_NetheriteSword=1..},nbt={Inventory:[{tag:{sd_id:"魔术置换"}}]},tag=!overload] at @s run function combat:attack_generic/rapier_ with storage damage:player_$(id)

# 刺剑连击检测
$execute if score @s rapier_combo matches 1.. if entity @s[nbt=!{Inventory:[{tag:{sd_id:"魔术置换"}}]}] run function combat:attack_generic/rapier_combo with storage damage:player_$(id)
$execute if score @s rapier_combo matches 1.. if entity @s[nbt={Inventory:[{tag:{sd_id:"魔术置换"}}]},tag=!overload] run function combat:attack_generic/rapier_combo_ with storage damage:player_$(id)

$execute if entity @s[scores={use_Crossbow=1..}] at @s run function combat:attack_generic/crossbow with storage damage:player_$(id)
# 猎弩箭矢伤害检测
$execute as @e[tag=bullet_from_crossbow] at @s if entity @e[tag=enemy,distance=..2.5] on origin if entity @s[tag=player_$(id),nbt=!{Inventory:[{tag:{sd_id:"精准射击"}}]},nbt={SelectedItem:{tag:{hunting_crossbow:1b}}}] as @e[type=arrow,tag=bullet_from_crossbow,limit=1,sort=nearest] at @s run function combat:attack_generic/crossbow_crit with storage damage:player_$(id)
$execute as @e[tag=bullet_from_crossbow] at @s if entity @e[tag=enemy,distance=..2.5] on origin if entity @s[tag=player_$(id),nbt={Inventory:[{tag:{sd_id:"精准射击"}}]},tag=!overload,distance=5.01..,nbt={SelectedItem:{tag:{hunting_crossbow:1b}}}] as @e[type=arrow,tag=bullet_from_crossbow,limit=1,sort=nearest] at @s run function combat:attack_generic/crossbow_crit with storage damage:player_$(id)
$execute as @e[tag=bullet_from_crossbow] at @s if entity @e[tag=enemy,distance=..2.5] on origin if entity @s[tag=player_$(id),nbt={Inventory:[{tag:{sd_id:"精准射击"}}]},tag=!overload,distance=..5,nbt={SelectedItem:{tag:{hunting_crossbow:1b}}}] as @e[type=arrow,tag=bullet_from_crossbow,limit=1,sort=nearest] at @s run function combat:attack_generic/crossbow_crit_ with storage damage:player_$(id)

# 连弩箭矢伤害检测
$execute as @e[tag=bullet_from_crossbow] at @s if entity @e[tag=enemy,distance=..2.5] on origin if entity @s[tag=player_$(id),nbt=!{Inventory:[{tag:{sd_id:"精准射击"}}]},nbt={SelectedItem:{tag:{repeating_crossbow:1b}}}] as @e[type=arrow,tag=bullet_from_crossbow,limit=1,sort=nearest] at @s run function combat:attack_generic/repeating_crossbow_crit with storage damage:player_$(id)
$execute as @e[tag=bullet_from_crossbow] at @s if entity @e[tag=enemy,distance=..2.5] on origin if entity @s[tag=player_$(id),nbt={Inventory:[{tag:{sd_id:"精准射击"}}]},tag=!overload,distance=5.01..,nbt={SelectedItem:{tag:{repeating_crossbow:1b}}}] as @e[type=arrow,tag=bullet_from_crossbow,limit=1,sort=nearest] at @s run function combat:attack_generic/repeating_crossbow_crit with storage damage:player_$(id)
$execute as @e[tag=bullet_from_crossbow] at @s if entity @e[tag=enemy,distance=..2.5] on origin if entity @s[tag=player_$(id),nbt={Inventory:[{tag:{sd_id:"精准射击"}}]},tag=!overload,distance=..5,nbt={SelectedItem:{tag:{repeating_crossbow:1b}}}] as @e[type=arrow,tag=bullet_from_crossbow,limit=1,sort=nearest] at @s run function combat:attack_generic/repeating_crossbow_crit_ with storage damage:player_$(id)

#散杖
$execute if entity @s[scores={use_Stick=1..}] at @s run function combat:attack_generic/stick with storage damage:player_$(id)
$execute at @e[tag=stick_bullet] as @e[tag=enemy,distance=..1.8] run function combat:attack_generic/stick_add_mp with storage damage:player_$(id)

$execute at @e[tag=stick_bullet] as @e[tag=enemy,distance=..1.8,scores={interval_stick=..0}] run function combat:deal/damage_deal {"rate":"80","type":"magic","player":"player_$(id)","interval":"generic"}

# 凝杖蓄力逻辑
# 手持凝杖时增加蓄力
execute if entity @s[nbt={SelectedItem:{tag:{focusing_staff:1b}}}] run scoreboard players add @s charge_of_stick 1
# 最长蓄力时间10秒（200tick）
execute if score @s charge_of_stick matches 201.. run scoreboard players set @s charge_of_stick 200

# 手持凝杖时在玩家眼前显示粒子效果
$execute if entity @s[nbt={SelectedItem:{tag:{focusing_staff:1b}}}] at @s run function combat:attack_generic/focusing_staff_particle with storage damage:player_$(id)

# 右键发射能量球
$execute if entity @s[nbt={SelectedItem:{tag:{focusing_staff:1b}}},scores={use_Stick_=1..}] at @s positioned ~ ~-0.6 ~ run function combat:attack_generic/focusing_staff_launch with storage damage:player_$(id)


# 发射后的能量球显示粒子
execute as @e[tag=focusing_spit_launched] at @s run function combat:attack_generic/focusing_staff_launched_particle

# 发射后的能量球碰撞检测
execute as @e[tag=focusing_spit_launched] at @s run function combat:attack_generic/focusing_staff_collision

# 血量显示
execute at @s run function combat:healthbar/health_bar_get

# MP条显示（只在MP十位数变化时更新）
execute at @s run function combat:mp_bar/mp_change_detector

# 其他道具
execute if entity @s[nbt={SelectedItem:{id:"minecraft:compass"}}] at @s run function y_other:prop/compass 
