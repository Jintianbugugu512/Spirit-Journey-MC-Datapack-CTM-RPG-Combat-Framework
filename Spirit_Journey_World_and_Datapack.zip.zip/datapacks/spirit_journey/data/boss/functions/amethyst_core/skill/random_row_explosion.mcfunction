# ==========================================
# 紫晶核心 - 技能：随机行爆炸
# 随机选择2行的所有格子产生方形预警
# ==========================================

# 清除之前的选择标记
tag @e[tag=chess_grid] remove selected

# 随机选择2个不同的行号（1-5）
scoreboard players set #random_row_1 temp 0
scoreboard players set #random_row_2 temp 0

# 生成第一个随机行号（1-5）
execute store result score #random_row_1 temp run random value 1..5

# 生成第二个随机行号（1-5）
execute store result score #random_row_2 temp run random value 1..5

# 选择这两行的所有格子
execute as @e[tag=chess_grid] if score @s row = #random_row_1 temp run tag @s add selected
execute as @e[tag=chess_grid] if score @s row = #random_row_2 temp run tag @s add selected

# 在选中的格子召唤方形预警（5×5格，延迟40tick）
execute as @e[tag=chess_grid,tag=selected] at @s positioned ~ ~ ~ run summon item_display ~ ~ ~ {Tags:["square_warning","square_warning_new","warning"],transformation:{scale:[5.0f,5.0f,1.0f],translation:[0f,0f,0f],left_rotation:[0.7071f,0f,0f,0.7071f],right_rotation:[0f,0f,0f,1f]},item:{id:"minecraft:shulker_shell",Count:1b},billboard:"fixed",brightness:{sky:15,block:15}}

# 设置生命周期
scoreboard players set @e[tag=square_warning_new] temp 40

# 给选中的格子添加爆炸标记（用于延迟召唤子弹）
tag @e[tag=chess_grid,tag=selected] add explosion_pending

# 移除new标签
tag @e[tag=square_warning_new] remove square_warning_new

# 清除选择标记
tag @e[tag=selected] remove selected

# 延迟40tick后召唤向上发射的子弹
schedule function boss:amethyst_core/skill/spawn_explosion_bullets 40t

say [紫晶核心] 双行爆炸攻击！
