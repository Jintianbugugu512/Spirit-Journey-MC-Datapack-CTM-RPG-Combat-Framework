# ==========================================
# 紫晶核心 - 生成爆炸子弹
# 在标记的格子上召唤向上发射的子弹
# ==========================================

# 在所有标记为explosion_pending的格子上召唤向上发射的子弹（y轴-5）
execute as @e[tag=chess_grid,tag=explosion_pending] at @s positioned ~ ~ ~ run function enemy_skill:bullet/motion_bullet/summon {type:"block_display",name:"minecraft:amethyst_cluster",mx:0.0,my:0.5,mz:0.0,t:100,scale:4,dr:0,damage:0,tx:-2,ty:-5,tz:-2}

# 清除爆炸标记
tag @e[tag=explosion_pending] remove explosion_pending

say [紫晶核心] 紫水晶簇爆发！
