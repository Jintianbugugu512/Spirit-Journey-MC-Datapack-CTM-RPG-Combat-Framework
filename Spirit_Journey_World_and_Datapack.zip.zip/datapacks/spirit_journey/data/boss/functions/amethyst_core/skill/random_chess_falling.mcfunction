# ==========================================
# 紫晶核心 - 技能：随机格子天降攻击（3个）
# 随机选择3个格子产生方形预警，从上方发射向下的子弹
# ==========================================

# 清除之前的选择标记
tag @e[tag=chess_grid] remove selected

# 随机选择3个格子
tag @e[tag=chess_grid,limit=3,sort=random] add selected

# 在选中的格子召唤方形预警（5×5格，延迟30tick）
execute as @e[tag=chess_grid,tag=selected] at @s positioned ~ ~ ~ run summon item_display ~ ~ ~ {Tags:["square_warning","square_warning_new","warning"],transformation:{scale:[5.0f,5.0f,1.0f],translation:[0f,0f,0f],left_rotation:[0.7071f,0f,0f,0.7071f],right_rotation:[0f,0f,0f,1f]},item:{id:"minecraft:shulker_shell",Count:1b},billboard:"fixed",brightness:{sky:15,block:15}}

# 设置生命周期（30tick）
scoreboard players set @e[tag=square_warning_new] temp 30

# 给选中的格子添加天降攻击标记
tag @e[tag=chess_grid,tag=selected] add falling_pending

# 移除new标签
tag @e[tag=square_warning_new] remove square_warning_new

# 清除选择标记
tag @e[tag=selected] remove selected

# 延迟30tick后召唤向下发射的子弹
schedule function boss:amethyst_core/skill/spawn_falling_bullets 30t

say [紫晶核心] 随机格子天降攻击！
