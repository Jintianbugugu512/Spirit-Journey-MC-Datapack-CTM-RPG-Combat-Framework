# 随机玩家打标
tag @r add boss_target

# 在BOSS处召唤潜影弹
execute at @s run summon shulker_bullet ~ ~3 ~ {Tags:["boss_bullet","bullet_new"],Steps:5}

# 写入目标UUID
execute as @e[tag=bullet_new,limit=1,sort=nearest] run data modify entity @s Target set from entity @a[tag=boss_target,limit=1] UUID

# 给它一个初始速度，至少让它动起来
execute as @e[tag=bullet_new,limit=1,sort=nearest] at @s facing entity @a[tag=boss_target,limit=1] eyes run data merge entity @s {Motion:[0.0,0.0,0.3]}

# 清理标签
tag @a[tag=boss_target] remove boss_target
tag @e[tag=bullet_new] remove bullet_new