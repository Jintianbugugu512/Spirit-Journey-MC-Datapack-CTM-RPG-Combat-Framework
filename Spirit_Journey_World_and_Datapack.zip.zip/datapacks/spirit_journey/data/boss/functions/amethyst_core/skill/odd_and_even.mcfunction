# ==========================================
# 紫晶核心 - 技能：奇偶组合攻击
# 先奇数格爆炸 → 40tick后偶数格天降 → 80tick后奇数格爆炸
# ==========================================

# 第一波：奇数格爆炸
function boss:amethyst_core/skill/odd_chess_explosion

# 第二波：40tick后偶数格天降
schedule function boss:amethyst_core/skill/even_chess_falling 40t

# 第三波：80tick后奇数格爆炸
schedule function boss:amethyst_core/skill/odd_chess_explosion 80t

say [紫晶核心] 奇偶组合攻击启动！
