# ==========================================
# 紫晶核心 - 生成天降子弹
# 在标记的格子上方召唤向下发射的子弹
# ==========================================

# 在所有标记为falling_pending的格子上方15格召唤向下发射的子弹
execute as @e[tag=chess_grid,tag=falling_pending] at @s positioned ~ ~15 ~ run function enemy_skill:bullet/y_bullet/summon {type:"block_display",name:"minecraft:amethyst_block",mx:0.0,my:-0.5,mz:0.0,t:100,scale:4,dr:2,damage:4,tx:-2,ty:-5,tz:2}

# 清除天降攻击标记
tag @e[tag=falling_pending] remove falling_pending

say [紫晶核心] 紫水晶簇天降！
