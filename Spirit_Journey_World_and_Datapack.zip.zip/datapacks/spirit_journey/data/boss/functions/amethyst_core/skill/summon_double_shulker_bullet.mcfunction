# ==========================================
# 紫晶核心 - 技能：双发追踪潜影弹
# 召唤2个潜影弹攻击随机玩家
# ==========================================

# 第一发：随机选择玩家并存储UUID
data modify storage boss:skill target_uuid_1 set from entity @r UUID
execute at @s run summon shulker_bullet ~ ~1 ~ {Tags:["boss_bullet","bullet_temp_1"],Steps:5}
data modify entity @e[tag=bullet_temp_1,limit=1,sort=nearest] Target set from storage boss:skill target_uuid_1
tag @e[tag=bullet_temp_1] remove bullet_temp_1

# 第二发：稍微偏移位置，随机选择玩家并存储UUID
data modify storage boss:skill target_uuid_2 set from entity @r UUID
execute at @s positioned ~0.5 ~ ~ run summon shulker_bullet ~ ~2 ~ {Tags:["boss_bullet","bullet_temp_2"],Steps:5}
data modify entity @e[tag=bullet_temp_2,limit=1,sort=nearest] Target set from storage boss:skill target_uuid_2
tag @e[tag=bullet_temp_2] remove bullet_temp_2

say [紫晶核心] 发射双重追踪潜影弹！
