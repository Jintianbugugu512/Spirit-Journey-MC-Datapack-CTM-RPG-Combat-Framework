# ==========================================
# 紫晶核心 - BOSS血条显示
# 为100格内的玩家显示BOSS血条
# ==========================================

# 如果BOSS血条不存在，创建它
execute unless entity @s[tag=bossbar_created] run bossbar add amethyst_core {"text":"紫晶核心","color":"light_purple","bold":true}
execute unless entity @s[tag=bossbar_created] run bossbar set amethyst_core color purple
execute unless entity @s[tag=bossbar_created] run bossbar set amethyst_core style notched_10
execute unless entity @s[tag=bossbar_created] run tag @s add bossbar_created

# 更新血条显示给100格内的玩家
bossbar set amethyst_core players @a[distance=..100]

# 更新血条数值（根据current_health和max_health计算百分比）
execute store result bossbar amethyst_core max run scoreboard players get @s max_health
execute store result bossbar amethyst_core value run scoreboard players get @s current_health

# 如果BOSS死亡，移除血条
execute if score @s current_health matches ..0 run bossbar remove amethyst_core
execute if score @s current_health matches ..0 run tag @s remove bossbar_created
