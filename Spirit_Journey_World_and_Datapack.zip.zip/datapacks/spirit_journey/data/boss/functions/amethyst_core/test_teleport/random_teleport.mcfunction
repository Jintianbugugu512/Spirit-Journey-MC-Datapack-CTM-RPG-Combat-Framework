# ==========================================
# 紫晶核心 - 随机传送
# 在指定范围内随机传送BOSS
# X: -1001 到 -1025
# Y: 100（固定）
# Z: 1001 到 1025
# ==========================================

# 生成随机X坐标（-1001 到 -1025，范围25格）
execute store result storage boss:teleport x int 1 run random value -1025..-1001

# 生成随机Z坐标（1001 到 1025，范围25格）
execute store result storage boss:teleport z int 1 run random value 1001..1025

# 固定Y坐标
data modify storage boss:teleport y set value 100

# 执行传送（使用宏函数）
function boss:amethyst_core/test_teleport/teleport_execute with storage boss:teleport

say [紫晶核心] 随机传送！

# 设置延迟释放技能标记（5tick后释放）
scoreboard players set @s temp1 5
tag @s add pending_skill
say [调试] 已设置pending_skill标签，temp1=5
