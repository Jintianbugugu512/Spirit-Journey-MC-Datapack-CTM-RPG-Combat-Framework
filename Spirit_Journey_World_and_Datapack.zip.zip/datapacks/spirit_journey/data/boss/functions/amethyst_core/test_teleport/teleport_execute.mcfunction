# ==========================================
# 紫晶核心 - 传送执行（宏函数）
# 实际执行传送命令
# ==========================================
playsound minecraft:entity.enderman.teleport master @a[distance=..12] ~ ~ ~ 1 1
effect give @s minecraft:invisibility 1 0 true
schedule function boss:amethyst_core/test_teleport/amethyst_core_particle 1t
$tp @s $(x) $(y) $(z)

