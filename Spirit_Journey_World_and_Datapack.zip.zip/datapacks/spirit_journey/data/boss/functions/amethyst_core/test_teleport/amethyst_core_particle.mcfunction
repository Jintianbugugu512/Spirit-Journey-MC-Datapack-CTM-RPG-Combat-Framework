execute as @e[tag=amethyst_core] at @s run particle minecraft:portal ~ ~1 ~ 1 1 1 0.2 330 force
say 666
