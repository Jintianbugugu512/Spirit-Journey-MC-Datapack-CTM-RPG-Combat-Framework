# ==========================================
# 紫晶核心 - 随机传送测试主循环
# 第一阶段：每12秒传送一次
# 第二阶段：每8秒传送一次
# ==========================================

# 计时器递减
scoreboard players remove @s[scores={timer=1..}] timer 1

# 当timer归零时，执行随机传送
execute if score @s timer matches ..0 run function boss:amethyst_core/test_teleport/random_teleport

# 重置计时器（根据阶段设置不同的等待时间）
# 第一阶段：12秒 = 240tick
execute if score @s timer matches ..0 if score @s phase matches 1 run scoreboard players set @s timer 240
# 第二阶段：8秒 = 160tick
execute if score @s timer matches ..0 if score @s phase matches 2 run scoreboard players set @s timer 160

# 延迟技能释放系统（传送后5tick释放技能）
execute if entity @s[tag=pending_skill] run scoreboard players remove @s temp1 1

# 第一阶段：5tick后召唤1个追踪潜影弹
execute if entity @s[tag=pending_skill] if score @s temp1 matches ..0 if score @s phase matches 1 run say [调试] 准备召唤单发潜影弹
execute if entity @s[tag=pending_skill] if score @s temp1 matches ..0 if score @s phase matches 1 run function boss:amethyst_core/skill/summon_single_shulker_bullet

# 第二阶段：5tick后召唤2个追踪潜影弹
execute if entity @s[tag=pending_skill] if score @s temp1 matches ..0 if score @s phase matches 2 run say [调试] 准备召唤双发潜影弹
execute if entity @s[tag=pending_skill] if score @s temp1 matches ..0 if score @s phase matches 2 run function boss:amethyst_core/skill/summon_double_shulker_bullet

# 技能释放完毕，移除标记
execute if entity @s[tag=pending_skill] if score @s temp1 matches ..0 run tag @s remove pending_skill
