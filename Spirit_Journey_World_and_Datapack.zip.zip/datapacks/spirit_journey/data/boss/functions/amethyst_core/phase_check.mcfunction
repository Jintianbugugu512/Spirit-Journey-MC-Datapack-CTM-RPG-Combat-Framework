# 紫晶核心BOSS - 阶段检查
# 根据血量百分比触发阶段转换

# 计算血量百分比（current_health * 100 / max_health）
# 当血量低于50%时进入第二阶段

# 第一阶段 → 第二阶段（血量≤50%）
execute if score @s phase matches 1 if score @s current_health <= @s max_health run function boss:amethyst_core/phase_check_helper

# 辅助函数用于血量百分比判断
