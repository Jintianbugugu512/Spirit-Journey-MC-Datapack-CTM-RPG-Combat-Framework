# ==========================================
# 紫晶核心 - 棋盘阵列管理（每tick）
# 为管理员显示格子位置粒子
# ==========================================

# 如果有管理员在场，显示格子位置粒子
execute if entity @a[tag=Mana] as @e[tag=chess_grid,tag=odd] at @s run particle dust 0.8 0.0 1.0 0.5 ~ ~0.1 ~ 0.1 0.05 0.1 0 1 force
execute if entity @a[tag=Mana] as @e[tag=chess_grid,tag=even] at @s run particle dust 0.3 0.0 0.6 0.5 ~ ~0.1 ~ 0.1 0.05 0.1 0 1 force
