# 血量百分比判断辅助函数
# 当 current_health * 2 <= max_health 时触发（即≤50%）

scoreboard players operation @s temp = @s current_health
scoreboard players operation @s temp *= #2 const
execute if score @s temp <= @s max_health run function boss:amethyst_core/transition/to_phase2
