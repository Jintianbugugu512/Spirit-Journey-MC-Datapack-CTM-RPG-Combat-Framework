# ==========================================
# 紫晶核心 - 第一阶段主循环
# 12秒一轮传送循环，包含技能释放
# ==========================================

# 计时器递减（每tick-1）
scoreboard players remove @s[scores={timer=1..}] timer 1

# === 传送系统（12秒 = 240tick 一轮）===
# 当timer归零时，执行随机传送
execute if score @s timer matches ..0 run function boss:amethyst_core/test_teleport/random_teleport
# 重置计时器为12秒
execute if score @s timer matches ..0 run scoreboard players set @s timer 240

# 传送后5tick发射潜影弹（已有逻辑）
execute if entity @s[tag=pending_skill] run scoreboard players remove @s temp1 1
execute if entity @s[tag=pending_skill] if score @s temp1 matches ..0 run function boss:amethyst_core/skill/summon_single_shulker_bullet
execute if entity @s[tag=pending_skill] if score @s temp1 matches ..0 run tag @s remove pending_skill

# === 6秒时发射单发潜影弹（240-120=120tick）===
execute if score @s timer matches 120 run function boss:amethyst_core/skill/summon_single_shulker_bullet

# === 技能释放时间点：1s, 5s, 9s（即 220, 140, 60 tick）===
execute if score @s timer matches 220 run function boss:amethyst_core/phase1/random_skill
execute if score @s timer matches 140 run function boss:amethyst_core/phase1/random_skill
execute if score @s timer matches 60 run function boss:amethyst_core/phase1/random_skill
