# 第一阶段 - 技能调度器
# 根据skill值和timer调用对应技能

# 待机状态（skill=0），等待20tick后开始第一个技能
execute if score @s skill matches 0 if score @s timer matches 0 run function boss:amethyst_core/phase1/start_skill1

# 技能1执行中
execute if score @s skill matches 1 if score @s timer matches 1.. run function boss:amethyst_core/phase1/skill_1
execute if score @s skill matches 1 if score @s timer matches 0 run function boss:amethyst_core/phase1/start_skill2

# 技能2执行中
execute if score @s skill matches 2 if score @s timer matches 1.. run function boss:amethyst_core/phase1/skill_2
execute if score @s skill matches 2 if score @s timer matches 0 run function boss:amethyst_core/phase1/start_skill3

# 技能3执行中
execute if score @s skill matches 3 if score @s timer matches 1.. run function boss:amethyst_core/phase1/skill_3
execute if score @s skill matches 3 if score @s timer matches 0 run function boss:amethyst_core/phase1/start_skill1
