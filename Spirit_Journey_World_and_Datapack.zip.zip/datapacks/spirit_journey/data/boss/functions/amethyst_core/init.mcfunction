# 紫晶核心BOSS - 初始化
# 召唤BOSS实体并设置初始状态

# 召唤BOSS实体（使用无AI的潜影贝）
summon shulker -1013 100 1013 {Tags:["amethyst_core","boss","enemy","new_boss"],Glowing:1b,NoAI:1b,CustomName:'{"text":"紫晶核心","color":"light_purple","bold":true}',CustomNameVisible:1b}

# 初始化记分板
scoreboard players set @e[tag=new_boss] phase 1
scoreboard players set @e[tag=new_boss] skill 0
scoreboard players set @e[tag=new_boss] timer 240
scoreboard players set @e[tag=new_boss] cleanup_timer 0
scoreboard players set @e[tag=new_boss] max_health 1000
scoreboard players set @e[tag=new_boss] current_health 1000

# 设置防御属性
scoreboard players set @e[tag=new_boss] physical_armor 10
scoreboard players set @e[tag=new_boss] magic_resist 0

# 设置其他属性
scoreboard players set @e[tag=new_boss] hit_cooldown 0
scoreboard players set @e[tag=new_boss] temp 0
execute as @e[tag=new_boss] run attribute @s generic.knockback_resistance base set 0.7
execute as @e[tag=new_boss] store result score @s knock_resistance run attribute @s generic.knockback_resistance get 10

# 初始化常量（用于随机数计算）
scoreboard players set #7 temp 7

# 加入红队
team join red @e[tag=new_boss]

# 给予火焰保护
effect give @e[tag=new_boss] fire_resistance infinite 4 true

# 移除初始化标签
tag @e[tag=new_boss] remove new_boss

say [系统] 紫晶核心已召唤
