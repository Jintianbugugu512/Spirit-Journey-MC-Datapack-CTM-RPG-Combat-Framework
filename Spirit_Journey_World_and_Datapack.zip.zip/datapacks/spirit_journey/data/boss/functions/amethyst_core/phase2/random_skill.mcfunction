# ==========================================
# 紫晶核心 - 第二阶段随机技能选择
# 从7个技能中随机选择一个释放
# 每个技能概率相同（14.29%）
# ==========================================

# 生成1-7的随机数
scoreboard players set @s temp 0
summon marker ~ ~ ~ {Tags:["random_temp"]}
execute store result score @s temp run data get entity @e[tag=random_temp,limit=1] UUID[0] 1
scoreboard players operation @s temp %= #7 temp
scoreboard players add @s temp 1
kill @e[tag=random_temp]

# 根据随机数调用对应技能
execute if score @s temp matches 1 run function boss:amethyst_core/skill/random_chess_explosion_5
execute if score @s temp matches 2 run function boss:amethyst_core/skill/random_chess_falling_5
execute if score @s temp matches 3 run function boss:amethyst_core/skill/random_col_explosion
execute if score @s temp matches 4 run function boss:amethyst_core/skill/random_col_falling
execute if score @s temp matches 5 run function boss:amethyst_core/skill/random_row_explosion
execute if score @s temp matches 6 run function boss:amethyst_core/skill/random_row_falling
execute if score @s temp matches 7 run function boss:amethyst_core/skill/odd_and_even

# 如果触发 odd_and_even，给timer增加120tick（停止6秒的递减）
# 这样在接下来的120tick内，timer不会触发新的技能释放时间点
execute if score @s temp matches 7 run scoreboard players add @s timer 120
execute if score @s temp matches 7 run say [紫晶核心] 奇偶组合攻击！技能释放暂停6秒
