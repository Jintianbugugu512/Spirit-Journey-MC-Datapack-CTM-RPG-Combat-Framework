# ==========================================
# 紫晶核心 - 棋盘阵列召唤
# 在指定区域召唤5×5棋盘阵列的marker实体
# 用于技能：棋盘攻击模式
# ==========================================

# 第1列 X=-1003
summon marker -1003 100 1003 {Tags:["chess_grid","odd","Col1","Row1"]}
summon marker -1003 100 1008 {Tags:["chess_grid","even","Col1","Row2"]}
summon marker -1003 100 1013 {Tags:["chess_grid","odd","Col1","Row3"]}
summon marker -1003 100 1018 {Tags:["chess_grid","even","Col1","Row4"]}
summon marker -1003 100 1023 {Tags:["chess_grid","odd","Col1","Row5"]}

# 第2列 X=-1008
summon marker -1008 100 1003 {Tags:["chess_grid","even","Col2","Row1"]}
summon marker -1008 100 1008 {Tags:["chess_grid","odd","Col2","Row2"]}
summon marker -1008 100 1013 {Tags:["chess_grid","even","Col2","Row3"]}
summon marker -1008 100 1018 {Tags:["chess_grid","odd","Col2","Row4"]}
summon marker -1008 100 1023 {Tags:["chess_grid","even","Col2","Row5"]}

# 第3列 X=-1013
summon marker -1013 100 1003 {Tags:["chess_grid","odd","Col3","Row1"]}
summon marker -1013 100 1008 {Tags:["chess_grid","even","Col3","Row2"]}
summon marker -1013 100 1013 {Tags:["chess_grid","odd","Col3","Row3"]}
summon marker -1013 100 1018 {Tags:["chess_grid","even","Col3","Row4"]}
summon marker -1013 100 1023 {Tags:["chess_grid","odd","Col3","Row5"]}

# 第4列 X=-1018
summon marker -1018 100 1003 {Tags:["chess_grid","even","Col4","Row1"]}
summon marker -1018 100 1008 {Tags:["chess_grid","odd","Col4","Row2"]}
summon marker -1018 100 1013 {Tags:["chess_grid","even","Col4","Row3"]}
summon marker -1018 100 1018 {Tags:["chess_grid","odd","Col4","Row4"]}
summon marker -1018 100 1023 {Tags:["chess_grid","even","Col4","Row5"]}

# 第5列 X=-1023
summon marker -1023 100 1003 {Tags:["chess_grid","odd","Col5","Row1"]}
summon marker -1023 100 1008 {Tags:["chess_grid","even","Col5","Row2"]}
summon marker -1023 100 1013 {Tags:["chess_grid","odd","Col5","Row3"]}
summon marker -1023 100 1018 {Tags:["chess_grid","even","Col5","Row4"]}
summon marker -1023 100 1023 {Tags:["chess_grid","odd","Col5","Row5"]}

# 设置列号（col）记分板
scoreboard players set @e[tag=Col1] col 1
scoreboard players set @e[tag=Col2] col 2
scoreboard players set @e[tag=Col3] col 3
scoreboard players set @e[tag=Col4] col 4
scoreboard players set @e[tag=Col5] col 5

# 设置行号（row）记分板
scoreboard players set @e[tag=Row1] row 1
scoreboard players set @e[tag=Row2] row 2
scoreboard players set @e[tag=Row3] row 3
scoreboard players set @e[tag=Row4] row 4
scoreboard players set @e[tag=Row5] row 5

# 移除临时定位标签
tag @e[tag=Col1] remove Col1
tag @e[tag=Col2] remove Col2
tag @e[tag=Col3] remove Col3
tag @e[tag=Col4] remove Col4
tag @e[tag=Col5] remove Col5
tag @e[tag=Row1] remove Row1
tag @e[tag=Row2] remove Row2
tag @e[tag=Row3] remove Row3
tag @e[tag=Row4] remove Row4
tag @e[tag=Row5] remove Row5

say [紫晶核心] 棋盘阵列已生成（5×5，共25个格子）
