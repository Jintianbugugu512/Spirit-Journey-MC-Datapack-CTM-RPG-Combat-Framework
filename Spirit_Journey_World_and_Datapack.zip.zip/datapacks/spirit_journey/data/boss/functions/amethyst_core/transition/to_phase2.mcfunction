# 紫晶核心BOSS - 转换到第二阶段

# 切换阶段
scoreboard players set @s phase 2
scoreboard players set @s skill 0
scoreboard players set @s timer 40

# 转阶段提示
say [紫晶核心] 进入第二阶段！能量暴走！
particle minecraft:dragon_breath ~ ~1 ~ 2 2 2 0.1 100 force
playsound minecraft:entity.ender_dragon.growl hostile @a ~ ~ ~ 2 1
