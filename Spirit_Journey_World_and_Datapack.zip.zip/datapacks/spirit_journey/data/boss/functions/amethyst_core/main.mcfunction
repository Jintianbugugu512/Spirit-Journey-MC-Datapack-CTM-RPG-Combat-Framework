# 紫晶核心BOSS - 主循环
# 每tick调用，控制BOSS行为

# 更新BOSS血条
function boss:amethyst_core/update_bossbar

# 阶段检查（用于阶段转换）
function boss:amethyst_core/phase_check

# === 战场清理系统 ===
# 每10秒清理战场区域内残留的block_display（防止子弹脱离载具后残留）
scoreboard players add @s cleanup_timer 1
execute if score @s cleanup_timer matches 200.. run function boss:amethyst_core/cleanup_display

# === 第一阶段行为 ===
execute if score @s phase matches 1 run function boss:amethyst_core/phase1/phase1_main

# === 第二阶段行为 ===
execute if score @s phase matches 2 run function boss:amethyst_core/phase2/phase2_main
