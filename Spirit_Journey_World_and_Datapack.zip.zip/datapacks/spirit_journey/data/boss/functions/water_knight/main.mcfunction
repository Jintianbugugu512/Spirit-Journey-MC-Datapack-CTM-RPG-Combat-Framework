# 水滴骑士BOSS - 主循环
# 每tick调用，控制BOSS行为

# 更新BOSS血条
function boss:water_knight/update_bossbar

# 棋盘marker粒子显示（Mana在线时）
function boss:water_knight/chess_grid_particle

# 冲刺状态检测 - 左平台
execute if entity @s[tag=dashing_forward,tag=dashing_left_platform] run function boss:water_knight/skill/left_platform/dash_tick
execute if entity @s[tag=dashing_back,tag=dashing_left_platform] run function boss:water_knight/skill/left_platform/dash_back_tick

# 冲刺状态检测 - 中间平台
execute if entity @s[tag=dashing_forward,tag=dashing_middle_platform] run function boss:water_knight/skill/middle_platform/dash_tick
execute if entity @s[tag=dashing_back,tag=dashing_middle_platform] run function boss:water_knight/skill/middle_platform/dash_back_tick

# 冲刺状态检测 - 右平台
execute if entity @s[tag=dashing_forward,tag=dashing_right_platform] run function boss:water_knight/skill/right_platform/dash_tick
execute if entity @s[tag=dashing_back,tag=dashing_right_platform] run function boss:water_knight/skill/right_platform/dash_back_tick

# 阶段检查（用于阶段转换）
function boss:water_knight/phase_check

# === 第一阶段行为 ===
execute if score @s phase matches 1 run function boss:water_knight/phase1/phase1_main

# === 第二阶段行为 ===
execute if score @s phase matches 2 run function boss:water_knight/phase2/phase2_main

# 确保骑士始终骑在马上
execute unless entity @s[type=skeleton,nbt={RootVehicle:{Entity:{Tags:["water_horse"]}}}] run ride @s mount @e[tag=water_horse,limit=1,sort=nearest]
