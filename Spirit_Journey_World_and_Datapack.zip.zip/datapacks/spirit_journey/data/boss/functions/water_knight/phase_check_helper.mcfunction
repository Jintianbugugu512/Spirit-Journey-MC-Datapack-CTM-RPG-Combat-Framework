# 水滴骑士BOSS - 阶段检查辅助函数
# 计算血量百分比，判断是否进入第二阶段

# 计算：current_health * 100 / max_health
scoreboard players operation @s temp = @s current_health
scoreboard players set #100 temp 100
scoreboard players operation @s temp *= #100 temp
scoreboard players operation @s temp /= @s max_health

# 如果血量百分比 ≤ 50%，进入第二阶段
execute if score @s temp matches ..50 run scoreboard players set @s phase 2
execute if score @s temp matches ..50 run say [水滴骑士] 进入第二阶段！（血量≤50%）
execute if score @s temp matches ..50 run playsound entity.ender_dragon.growl master @a ~ ~ ~ 2 1
