# ==========================================
# 水滴骑士 - 棋盘marker粒子显示
# 当Mana管理员在线时，显示细微紫色粒子
# ==========================================

# 检测Mana是否在线，如果在线则在每个marker位置显示粒子
execute if entity @a[name="Mana"] at @e[tag=water_chess_grid] run particle dust 0.7 0.5 1.0 0.5 ~ ~0.1 ~ 0.05 0.05 0.05 0 1 force
