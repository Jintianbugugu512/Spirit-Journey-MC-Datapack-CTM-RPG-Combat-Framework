# 水滴骑士BOSS - 阶段检查
# 根据血量百分比触发阶段转换

# 第一阶段 → 第二阶段（血量≤50%）
execute if score @s phase matches 1 if score @s current_health <= @s max_health run function boss:water_knight/phase_check_helper
