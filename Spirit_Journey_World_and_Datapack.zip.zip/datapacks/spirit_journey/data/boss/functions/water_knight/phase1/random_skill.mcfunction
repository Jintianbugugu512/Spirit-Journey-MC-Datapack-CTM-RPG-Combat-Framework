# ==========================================
# 水滴骑士 - 第一阶段随机技能选择
# 从5个技能中随机选择一个释放
# ==========================================

# 生成1-5的随机数
scoreboard players set @s temp 0
summon marker ~ ~ ~ {Tags:["random_temp"]}
execute store result score @s temp run data get entity @e[tag=random_temp,limit=1] UUID[0] 1
scoreboard players operation @s temp %= #5 temp
scoreboard players add @s temp 1
kill @e[tag=random_temp]

# 根据随机数调用对应技能
execute if score @s temp matches 1 run function boss:water_knight/skill/water_wave
execute if score @s temp matches 2 run function boss:water_knight/skill/water_prison
execute if score @s temp matches 3 run function boss:water_knight/skill/water_bullet
execute if score @s temp matches 4 run function boss:water_knight/skill/water_slash
execute if score @s temp matches 5 run function boss:water_knight/skill/water_shield
