# 水滴骑士BOSS - 更新血条显示
# 创建或更新BOSS血条

# 检查血条是否存在，不存在则创建
execute unless entity @s[tag=bossbar_created] run bossbar add water_knight {"text":"水滴骑士","color":"blue","bold":true}
execute unless entity @s[tag=bossbar_created] run bossbar set water_knight color blue
execute unless entity @s[tag=bossbar_created] run bossbar set water_knight style notched_10
execute unless entity @s[tag=bossbar_created] run bossbar set water_knight max 2000
execute unless entity @s[tag=bossbar_created] run tag @s add bossbar_created

# 更新血条值
execute store result bossbar water_knight value run scoreboard players get @s current_health

# 设置血条可见性（范围内玩家可见）
execute if entity @a[distance=..50] run bossbar set water_knight players @a[distance=..50]
execute unless entity @a[distance=..50] run bossbar set water_knight players

# BOSS死亡时移除血条
execute unless entity @s run bossbar remove water_knight
