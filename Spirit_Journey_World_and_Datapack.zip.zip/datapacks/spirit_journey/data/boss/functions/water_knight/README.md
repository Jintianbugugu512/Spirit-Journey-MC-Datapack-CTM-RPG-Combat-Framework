# 水滴骑士 BOSS - 开发文档

## 📋 基本信息

- **BOSS名称**: 水滴骑士 (Water Knight)
- **召唤位置**: -824 100 1002
- **实体类型**: 骷髅骑士 (Skeleton) 骑乘 水滴马 (Horse)
- **血量**: 2000 HP
- **防御**: 物理防御 20 / 魔法抗性 10
- **特殊属性**: 水滴马无敌 (Invulnerable)

---

## 🎮 召唤方式

```mcfunction
/function boss:water_knight/init
```

---

## 📂 文件结构

```
boss/water_knight/
├── init.mcfunction                    # 初始化：召唤BOSS和马
├── main.mcfunction                    # 主循环：每tick调用
├── update_bossbar.mcfunction          # 血条更新
├── phase_check.mcfunction             # 阶段检查
├── phase_check_helper.mcfunction      # 阶段检查辅助
├── phase1/
│   ├── phase1_main.mcfunction         # 第一阶段主循环（10秒一轮）
│   └── random_skill.mcfunction        # 第一阶段随机技能选择
├── phase2/
│   ├── phase2_main.mcfunction         # 第二阶段主循环（8秒一轮）
│   └── random_skill.mcfunction        # 第二阶段随机技能选择
└── skill/
    ├── water_wave.mcfunction          # 技能1：水波冲击
    ├── water_prison.mcfunction        # 技能2：水牢困锁
    ├── water_bullet.mcfunction        # 技能3：水弹射击
    ├── water_slash.mcfunction         # 技能4：水刃斩击
    ├── water_shield.mcfunction        # 技能5：水之护盾
    ├── water_wave_enhanced.mcfunction # 技能1强化版
    ├── water_prison_enhanced.mcfunction # 技能2强化版
    ├── water_bullet_enhanced.mcfunction # 技能3强化版
    ├── water_slash_enhanced.mcfunction  # 技能4强化版
    └── water_ultimate.mcfunction      # 终极技能：水之终结
```

---

## ⚙️ 系统机制

### 阶段系统
- **第一阶段**: 血量 > 50%
  - 10秒一轮循环
  - 技能释放时间点：1s, 4s, 7s (180, 120, 60 tick)
  - 5个基础技能随机选择

- **第二阶段**: 血量 ≤ 50%
  - 8秒一轮循环（更快）
  - 技能释放时间点：1s, 3s, 5s, 7s (140, 100, 60, 20 tick)
  - 5个强化技能随机选择

### 技能列表

#### 第一阶段技能
1. **水波冲击** - 发射水波攻击
2. **水牢困锁** - 困住范围内玩家
3. **水弹射击** - 发射水弹
4. **水刃斩击** - 向前方释放水刃
5. **水之护盾** - 生成护盾减伤

#### 第二阶段技能（强化版）
1. **水波冲击·强** - 更大范围水波
2. **水牢困锁·强** - 更大范围水牢
3. **水弹射击·强** - 多发水弹
4. **水刃斩击·强** - 更强的水刃
5. **水之终结** - 终极技能

---

## 🔌 集成位置

### 主循环调用
**文件**: `z_loop/functions/entity_manager.mcfunction`

```mcfunction
# 水滴骑士BOSS行为循环 - 优化：仅在BOSS区域有玩家时执行
execute if entity @a[x=-824,y=100,z=1002,distance=..50] as @e[tag=water_knight] at @s run function boss:water_knight/main
```

---

## 🎯 当前状态

### ✅ 已完成
- BOSS基础框架
- 阶段系统
- 血条系统
- 技能框架（10个技能，暂时用say语句占位）
- 主循环集成
- 骑乘系统（骑士骑马）
- 马的无敌设置

### ⏳ 待实现
- 技能的实际效果（目前都是say语句）
- 技能伤害计算
- 技能视觉效果优化
- AI移动逻辑（可选）

---

## 📝 标签系统

- `water_knight` - 骷髅骑士BOSS
- `water_horse` - 水滴马
- `boss` - BOSS通用标签
- `enemy` - 敌人标签
- `boss_mount` - BOSS坐骑标签
- `invulnerable` - 无敌标签

---

## 🔧 记分板

- `phase` - 阶段（1或2）
- `skill` - 技能计数
- `timer` - 技能释放计时器
- `max_health` - 最大生命值 (2000)
- `current_health` - 当前生命值
- `physical_armor` - 物理防御 (20)
- `magic_resist` - 魔法抗性 (10)
- `hit_cooldown` - 命中冷却
- `temp` - 临时计算用

---

## 🎨 特色设计

1. **骑乘系统**: 骷髅骑士骑在无敌的马上
2. **双阶段**: 血量50%触发第二阶段，技能加强且释放更频繁
3. **水属性主题**: 所有技能围绕水元素设计
4. **区域优化**: 只在玩家接近时才执行BOSS逻辑

---

**创建日期**: 2026-07-11  
**版本**: 1.0  
**Minecraft版本**: 1.20.4
