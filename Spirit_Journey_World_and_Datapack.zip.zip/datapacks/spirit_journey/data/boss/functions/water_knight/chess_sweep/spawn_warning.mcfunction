# ==========================================
# 水滴骑士 - 棋盘横扫攻击预警API
# 使用宏参数id来锁定Pos{id}的marker
# 参数：id - 位置编号（1-7）
# ==========================================

# 在Pos{id} marker位置召唤方形攻击预警
$execute at @e[tag=Pos$(id),limit=1] positioned ~ ~-0.1 ~-3 run function enemy_skill:warning/square_summon {scale_x:5.0,scale_z:16.0,et:60}

# 调试信息
$say [水滴骑士-棋盘横扫] 已在Pos$(id)位置召唤方形攻击预警
