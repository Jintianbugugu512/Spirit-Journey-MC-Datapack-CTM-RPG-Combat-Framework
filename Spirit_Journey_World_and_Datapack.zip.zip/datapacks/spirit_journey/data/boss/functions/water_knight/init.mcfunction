# 水滴骑士BOSS - 初始化
# 召唤BOSS实体并设置初始状态

# 召唤水滴马（无敌、无AI）
summon horse -824 100 1002 {Tags:["water_horse","boss_mount","invulnerable"],Invulnerable:1b,NoAI:1b,CustomName:'{"text":"水滴马","color":"aqua","bold":true}',CustomNameVisible:1b,Tame:1b,Attributes:[{Name:"generic.max_health",Base:1023},{Name:"generic.movement_speed",Base:0}]}

# 召唤骷髅骑士（骑在马上）
summon skeleton -824 100 1002 {Tags:["water_knight","boss","enemy","new_boss"],Passengers:[],CustomName:'{"text":"水滴骑士","color":"blue","bold":true}',CustomNameVisible:1b,ArmorItems:[{id:"leather_boots",Count:1,tag:{display:{color:3847130}}},{id:"leather_leggings",Count:1,tag:{display:{color:3847130}}},{id:"leather_chestplate",Count:1,tag:{display:{color:3847130}}},{id:"player_head",Count:1}],HandItems:[{id:"diamond_sword",Count:1},{}]}

# 让骷髅骑上马
ride @e[tag=water_knight,tag=new_boss,limit=1] mount @e[tag=water_horse,limit=1]

# 初始化记分板
scoreboard players set @e[tag=new_boss] phase 1
scoreboard players set @e[tag=new_boss] skill 0
scoreboard players set @e[tag=new_boss] timer 240
scoreboard players set @e[tag=new_boss] max_health 2000
scoreboard players set @e[tag=new_boss] current_health 2000

# 设置防御属性
scoreboard players set @e[tag=new_boss] physical_armor 20
scoreboard players set @e[tag=new_boss] magic_resist 10

# 设置其他属性
scoreboard players set @e[tag=new_boss] hit_cooldown 0
scoreboard players set @e[tag=new_boss] temp 0
execute as @e[tag=new_boss] run attribute @s generic.knockback_resistance base set 0.8

# 初始化常量（用于随机数计算）
scoreboard players set #5 temp 5

# 加入红队
team join red @e[tag=new_boss]

# 给予效果
effect give @e[tag=new_boss] fire_resistance infinite 4 true
effect give @e[tag=new_boss] water_breathing infinite 4 true

# 移除初始化标签
tag @e[tag=new_boss] remove new_boss

say [系统] 水滴骑士已召唤于 -824 100 1002
