# ==========================================
# 水滴骑士 - 棋盘阵列召唤
# 在中间平台召唤1×7棋盘阵列的marker实体
# 起点：-823 100 1006，X轴正方向，每次+5，共7个
# ==========================================

# 召唤7个marker（X轴从-823开始，每次+5）
summon marker -823 100 1006 {Tags:["water_chess_grid","odd","Pos1"]}
summon marker -818 100 1006 {Tags:["water_chess_grid","even","Pos2"]}
summon marker -813 100 1006 {Tags:["water_chess_grid","odd","Pos3"]}
summon marker -808 100 1006 {Tags:["water_chess_grid","even","Pos4"]}
summon marker -803 100 1006 {Tags:["water_chess_grid","odd","Pos5"]}
summon marker -798 100 1006 {Tags:["water_chess_grid","even","Pos6"]}
summon marker -793 100 1006 {Tags:["water_chess_grid","odd","Pos7"]}

# 设置位置序号（position）记分板
scoreboard players set @e[tag=Pos1] position 1
scoreboard players set @e[tag=Pos2] position 2
scoreboard players set @e[tag=Pos3] position 3
scoreboard players set @e[tag=Pos4] position 4
scoreboard players set @e[tag=Pos5] position 5
scoreboard players set @e[tag=Pos6] position 6
scoreboard players set @e[tag=Pos7] position 7

say [水滴骑士] 棋盘阵列已生成（1×7，共7个格子）
