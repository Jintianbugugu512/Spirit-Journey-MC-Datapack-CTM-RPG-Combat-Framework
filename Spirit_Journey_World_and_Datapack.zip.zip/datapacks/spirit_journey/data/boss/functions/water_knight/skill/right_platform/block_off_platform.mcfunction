# ==========================================
# 右平台封锁技能 - Block Off Platform
# 位置：-808 100 1010
# ==========================================

# 召唤方形攻击预警（35格×5格，停留50tick）
execute positioned -811 99.9 1010 run function enemy_skill:warning/square_summon {scale_x:35.0,scale_z:5.0,et:50}

# 50tick后放置滴水石锥
schedule function boss:water_knight/skill/right_platform/block_off_place_spikes 50t

# 调试信息
say [右平台封锁] 已召唤攻击预警，50tick后放置滴水石锥
