# ==========================================
# 水滴骑士 - 冲刺攻击判定（正向和反向通用）（右平台）
# 检测4个marker周围1格范围内的玩家并造成伤害
# ==========================================

# 检测左1 marker周围的玩家
execute as @e[tag=dash_spike_left1] at @s if entity @a[distance=..1] run say [冲刺攻击-右平台] 命中玩家！位置：左1
execute as @e[tag=dash_spike_left1] at @s if entity @a[distance=..1] run damage @a[distance=..1,limit=1] 10

# 检测左2 marker周围的玩家
execute as @e[tag=dash_spike_left2] at @s if entity @a[distance=..1] run say [冲刺攻击-右平台] 命中玩家！位置：左2
execute as @e[tag=dash_spike_left2] at @s if entity @a[distance=..1] run damage @a[distance=..1,limit=1] 10

# 检测右1 marker周围的玩家
execute as @e[tag=dash_spike_right1] at @s if entity @a[distance=..1] run say [冲刺攻击-右平台] 命中玩家！位置：右1
execute as @e[tag=dash_spike_right1] at @s if entity @a[distance=..1] run damage @a[distance=..1,limit=1] 10

# 检测右2 marker周围的玩家
execute as @e[tag=dash_spike_right2] at @s if entity @a[distance=..1] run say [冲刺攻击-右平台] 命中玩家！位置：右2
execute as @e[tag=dash_spike_right2] at @s if entity @a[distance=..1] run damage @a[distance=..1,limit=1] 10
