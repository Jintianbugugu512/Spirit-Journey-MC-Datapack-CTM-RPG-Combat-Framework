# ==========================================
# 水滴骑士 - 冲刺技能（右平台）
# 从 -824 100 1010 冲刺到 -792 100 1010
# ==========================================

# 设置冲刺参数（2秒 = 40tick）
scoreboard players set @s dash_timer 40
tag @s add dashing_forward
tag @s add dashing_right_platform

# 给马也添加标签（用于识别）
execute at @s run tag @e[tag=water_horse,limit=1,sort=nearest] add dashing_horse

# 传送到右平台起点并设置朝向为西（270度）
tp @s -824 100 1010 270 0
execute at @s run tp @e[tag=water_horse,limit=1,sort=nearest] ~ ~ ~ 270 0

# 召唤4个marker（在马的左右两侧，Z轴偏移，X轴后退2格）
execute at @e[tag=dashing_horse,limit=1] run summon marker ~-2 ~ ~1 {Tags:["dash_spike","dash_spike_left1"]}
execute at @e[tag=dashing_horse,limit=1] run summon marker ~-2 ~ ~2 {Tags:["dash_spike","dash_spike_left2"]}
execute at @e[tag=dashing_horse,limit=1] run summon marker ~-2 ~ ~-1 {Tags:["dash_spike","dash_spike_right1"]}
execute at @e[tag=dashing_horse,limit=1] run summon marker ~-2 ~ ~-2 {Tags:["dash_spike","dash_spike_right2"]}

# 提示信息
say [水滴骑士-右平台] 开始冲刺！
playsound entity.horse.gallop master @a ~ ~ ~ 2 1.2

# 粒子效果（起始爆发）
particle splash ~ ~1 ~ 1 1 1 0.3 50 force
