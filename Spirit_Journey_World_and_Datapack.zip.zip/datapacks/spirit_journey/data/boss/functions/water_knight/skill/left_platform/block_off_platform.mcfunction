# ==========================================
# 左平台封锁技能 - Block Off Platform
# 位置：-808 100 1002
# ==========================================

# 召唤方形攻击预警（35格×5格，停留50tick）
execute positioned -811 99.9 1002 run function enemy_skill:warning/square_summon {scale_x:35.0,scale_z:5.0,et:50}

# 50tick后放置滴水石锥
schedule function boss:water_knight/skill/left_platform/block_off_place_spikes 50t

# 调试信息
say [左平台封锁] 已召唤攻击预警，50tick后放置滴水石锥
