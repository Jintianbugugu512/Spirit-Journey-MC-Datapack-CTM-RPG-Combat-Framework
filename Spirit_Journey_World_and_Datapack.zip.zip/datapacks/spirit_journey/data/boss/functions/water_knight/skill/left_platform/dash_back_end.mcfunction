# ==========================================
# 水滴骑士 - 反向冲刺结束
# 冲刺完成后的处理
# ==========================================

# 移除冲刺标签
tag @s remove dashing_back
tag @s remove dashing_left_platform
execute at @s run tag @e[tag=dashing_horse,limit=1] remove dashing_horse

# 清除所有滴水石锥marker
kill @e[tag=dash_spike]

# 结束时的横扫攻击 - 周围3格范围
particle sweep_attack ~ ~1 ~ 3 0.5 3 0 30 force
execute as @a[distance=..3] run damage @s 8

# 结束音效和粒子效果
playsound entity.generic.splash master @a ~ ~ ~ 2 0.8
playsound entity.player.attack.sweep master @a ~ ~ ~ 2 1
particle splash ~ ~1 ~ 2 1 2 0.5 100 force
particle explosion ~ ~1 ~ 1 1 1 0 5 force

# 提示信息
say [水滴骑士] 反向冲刺结束！

# 微调到精确位置并恢复原始高度（-824 100 1002）- 传送马
execute at @s run tp @e[tag=water_horse,limit=1,sort=nearest] -824 100 1002 90 0
