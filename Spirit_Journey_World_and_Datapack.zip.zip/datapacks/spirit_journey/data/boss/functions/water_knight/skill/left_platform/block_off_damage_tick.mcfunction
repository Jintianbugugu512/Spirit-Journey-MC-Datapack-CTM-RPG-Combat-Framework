# ==========================================
# 左平台封锁 - 滴水石锥伤害检测（每tick）
# 检测玩家是否在滴水石锥上并造成伤害
# ==========================================

# 检测玩家脚下一格是否是滴水石锥
execute as @a at @s if block ~ ~-1 ~ pointed_dripstone run damage @s 4

# 检测玩家当前位置是否是滴水石锥
execute as @a at @s if block ~ ~ ~ pointed_dripstone run damage @s 4

# 继续循环检测（每1tick执行一次）
schedule function boss:water_knight/skill/left_platform/block_off_damage_tick 1t
