# ==========================================
# 水滴骑士 - 冲刺攻击判定（正向和反向通用）（中间平台）
# 检测12个marker周围1格范围内的玩家并造成伤害
# ==========================================

# 检测左侧6个 marker周围的玩家
execute as @e[tag=dash_spike_left1] at @s if entity @a[distance=..1] run say [冲刺攻击-中间平台] 命中玩家！位置：左1
execute as @e[tag=dash_spike_left1] at @s if entity @a[distance=..1] run damage @a[distance=..1,limit=1] 10

execute as @e[tag=dash_spike_left2] at @s if entity @a[distance=..1] run say [冲刺攻击-中间平台] 命中玩家！位置：左2
execute as @e[tag=dash_spike_left2] at @s if entity @a[distance=..1] run damage @a[distance=..1,limit=1] 10

execute as @e[tag=dash_spike_left3] at @s if entity @a[distance=..1] run say [冲刺攻击-中间平台] 命中玩家！位置：左3
execute as @e[tag=dash_spike_left3] at @s if entity @a[distance=..1] run damage @a[distance=..1,limit=1] 10

execute as @e[tag=dash_spike_left4] at @s if entity @a[distance=..1] run say [冲刺攻击-中间平台] 命中玩家！位置：左4
execute as @e[tag=dash_spike_left4] at @s if entity @a[distance=..1] run damage @a[distance=..1,limit=1] 10

execute as @e[tag=dash_spike_left5] at @s if entity @a[distance=..1] run say [冲刺攻击-中间平台] 命中玩家！位置：左5
execute as @e[tag=dash_spike_left5] at @s if entity @a[distance=..1] run damage @a[distance=..1,limit=1] 10

execute as @e[tag=dash_spike_left6] at @s if entity @a[distance=..1] run say [冲刺攻击-中间平台] 命中玩家！位置：左6
execute as @e[tag=dash_spike_left6] at @s if entity @a[distance=..1] run damage @a[distance=..1,limit=1] 10

# 检测右侧6个 marker周围的玩家
execute as @e[tag=dash_spike_right1] at @s if entity @a[distance=..1] run say [冲刺攻击-中间平台] 命中玩家！位置：右1
execute as @e[tag=dash_spike_right1] at @s if entity @a[distance=..1] run damage @a[distance=..1,limit=1] 10

execute as @e[tag=dash_spike_right2] at @s if entity @a[distance=..1] run say [冲刺攻击-中间平台] 命中玩家！位置：右2
execute as @e[tag=dash_spike_right2] at @s if entity @a[distance=..1] run damage @a[distance=..1,limit=1] 10

execute as @e[tag=dash_spike_right3] at @s if entity @a[distance=..1] run say [冲刺攻击-中间平台] 命中玩家！位置：右3
execute as @e[tag=dash_spike_right3] at @s if entity @a[distance=..1] run damage @a[distance=..1,limit=1] 10

execute as @e[tag=dash_spike_right4] at @s if entity @a[distance=..1] run say [冲刺攻击-中间平台] 命中玩家！位置：右4
execute as @e[tag=dash_spike_right4] at @s if entity @a[distance=..1] run damage @a[distance=..1,limit=1] 10

execute as @e[tag=dash_spike_right5] at @s if entity @a[distance=..1] run say [冲刺攻击-中间平台] 命中玩家！位置：右5
execute as @e[tag=dash_spike_right5] at @s if entity @a[distance=..1] run damage @a[distance=..1,limit=1] 10

execute as @e[tag=dash_spike_right6] at @s if entity @a[distance=..1] run say [冲刺攻击-中间平台] 命中玩家！位置：右6
execute as @e[tag=dash_spike_right6] at @s if entity @a[distance=..1] run damage @a[distance=..1,limit=1] 10
