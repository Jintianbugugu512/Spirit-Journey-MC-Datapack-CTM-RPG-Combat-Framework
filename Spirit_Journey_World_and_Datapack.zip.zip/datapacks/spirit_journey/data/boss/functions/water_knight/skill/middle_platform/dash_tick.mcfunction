# ==========================================
# 水滴骑士 - 冲刺执行（每tick调用）（中间平台）
# 每tick向东移动0.8格（速度减半，时间加倍）
# ==========================================

# 递减计时器
scoreboard players remove @s dash_timer 1

# 向东移动0.8格并保持朝向为西（270度）
execute as @e[tag=dashing_horse,limit=1] at @s run tp @s ~0.8 ~ ~ 270 0

# 让12个marker固定在马的左右两侧
execute as @e[tag=dash_spike_left1] at @e[tag=dashing_horse,limit=1] run tp @s ~-2 ~-0.2 ~1
execute as @e[tag=dash_spike_left2] at @e[tag=dashing_horse,limit=1] run tp @s ~-2 ~-0.2 ~2
execute as @e[tag=dash_spike_left3] at @e[tag=dashing_horse,limit=1] run tp @s ~-2 ~-0.2 ~3
execute as @e[tag=dash_spike_left4] at @e[tag=dashing_horse,limit=1] run tp @s ~-2 ~-0.2 ~4
execute as @e[tag=dash_spike_left5] at @e[tag=dashing_horse,limit=1] run tp @s ~-2 ~-0.2 ~5
execute as @e[tag=dash_spike_left6] at @e[tag=dashing_horse,limit=1] run tp @s ~-2 ~-0.2 ~6
execute as @e[tag=dash_spike_right1] at @e[tag=dashing_horse,limit=1] run tp @s ~-2 ~-0.2 ~-1
execute as @e[tag=dash_spike_right2] at @e[tag=dashing_horse,limit=1] run tp @s ~-2 ~-0.2 ~-2
execute as @e[tag=dash_spike_right3] at @e[tag=dashing_horse,limit=1] run tp @s ~-2 ~-0.2 ~-3
execute as @e[tag=dash_spike_right4] at @e[tag=dashing_horse,limit=1] run tp @s ~-2 ~-0.2 ~-4
execute as @e[tag=dash_spike_right5] at @e[tag=dashing_horse,limit=1] run tp @s ~-2 ~-0.2 ~-5
execute as @e[tag=dash_spike_right6] at @e[tag=dashing_horse,limit=1] run tp @s ~-2 ~-0.2 ~-6

# 在每个marker位置生成聚集的粒子效果（水花 + 白色灰尘）
execute at @e[tag=dash_spike] run particle splash ~ ~0.3 ~ 0.15 0.2 0.15 0.2 30 force
execute at @e[tag=dash_spike] run particle dust 0.8 0.9 1.0 1.5 ~ ~0.3 ~ 0.2 0.2 0.2 0 25 force

# 冲刺过程中的粒子效果
particle splash ~ ~0.5 ~ 0.5 0.3 0.5 0.2 10 force
particle cloud ~-1 ~0.5 ~ 0.3 0.3 0.3 0 3 force

# 冲刺音效（轻量级，每8tick播放一次）
execute if score @s dash_timer matches 32 run playsound entity.player.swim master @a ~ ~ ~ 1 1.2
execute if score @s dash_timer matches 24 run playsound entity.player.swim master @a ~ ~ ~ 1 1.2
execute if score @s dash_timer matches 16 run playsound entity.player.swim master @a ~ ~ ~ 1 1.2
execute if score @s dash_timer matches 8 run playsound entity.player.swim master @a ~ ~ ~ 1 1.2

# 碰撞检测：每tick检测马周围5个位置的玩家并造成伤害
function boss:water_knight/skill/middle_platform/dash_attack

# 冲刺结束
execute if score @s dash_timer matches ..0 run function boss:water_knight/skill/middle_platform/dash_end
