# ==========================================
# 水滴骑士 - 反向冲刺技能
# 从 -792 100 1002 冲刺回 -824 100 1002
# ==========================================

# 设置冲刺参数（2秒 = 40tick，与正向冲刺相同）
scoreboard players set @s dash_timer 40
tag @s add dashing_back
tag @s add dashing_left_platform

# 给马也添加标签（用于识别）
execute at @s run tag @e[tag=water_horse,limit=1,sort=nearest] add dashing_horse

# 设置朝向为东（90度）并降低0.5格
execute at @s run tp @e[tag=water_horse,limit=1,sort=nearest] ~ ~-0.5 ~ 90 0
tp @s ~ ~-0.5 ~ 90 0

# 召唤4个marker（在马的左右两侧，Z轴偏移，X轴后退2格）
execute at @e[tag=dashing_horse,limit=1] run summon marker ~3 ~ ~1 {Tags:["dash_spike","dash_spike_left1"]}
execute at @e[tag=dashing_horse,limit=1] run summon marker ~3 ~ ~2 {Tags:["dash_spike","dash_spike_left2"]}
execute at @e[tag=dashing_horse,limit=1] run summon marker ~3 ~ ~-1 {Tags:["dash_spike","dash_spike_right1"]}
execute at @e[tag=dashing_horse,limit=1] run summon marker ~3 ~ ~-2 {Tags:["dash_spike","dash_spike_right2"]}

# 提示信息
say [水滴骑士] 反向冲刺！
playsound entity.horse.gallop master @a ~ ~ ~ 2 1.2

# 粒子效果（起始爆发）
particle splash ~ ~1 ~ 1 1 1 0.3 50 force
