# ==========================================
# 左平台封锁 - 清除滴水石锥
# 区域：对角线1 -825 100 1004, 对角线2 -791 100 1000
# ==========================================

# 停止伤害检测循环
schedule clear boss:water_knight/skill/left_platform/block_off_damage_tick

# 消失时的粒子效果 - 石块消散（覆盖整个区域，无扩散）
execute positioned -808 100.5 1002 run particle poof ~ ~ ~ 8 0.5 2 0 240 force
execute positioned -808 100.5 1002 run particle dust 0.7 0.7 0.7 0.8 ~ ~-0.2 ~ 8 0.3 2 0 160 force

# 清除滴水石锥
fill -825 100 1004 -791 100 1000 air

# 调试信息
say [左平台封锁] 已清除滴水石锥
