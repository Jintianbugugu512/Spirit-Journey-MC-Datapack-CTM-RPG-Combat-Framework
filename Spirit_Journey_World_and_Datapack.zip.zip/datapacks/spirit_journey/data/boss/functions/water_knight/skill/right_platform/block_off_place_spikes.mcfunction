# ==========================================
# 右平台封锁 - 放置滴水石锥
# 区域：对角线1 -791 100 1008, 对角线2 -825 100 1012
# ==========================================

# 填充滴水石锥（尖端朝上）
fill -791 100 1008 -825 100 1012 pointed_dripstone[vertical_direction=up]

# 出现时的粒子效果 - 地刺突出效果（覆盖整个区域，无扩散）
execute positioned -808 100.5 1010 run particle block stone ~ ~ ~ 8 0.5 2 0 400 force
execute positioned -808 100.5 1010 run particle dust 0.6 0.6 0.6 1.0 ~ ~ ~ 8 0.5 2 0 300 force
execute positioned -808 100.5 1010 run particle poof ~ ~-0.2 ~ 8 0.3 2 0 160 force

# 100tick后清除滴水石锥
schedule function boss:water_knight/skill/right_platform/block_off_clear_spikes 100t

# 调试信息
say [右平台封锁] 已放置滴水石锥，100tick后清除
