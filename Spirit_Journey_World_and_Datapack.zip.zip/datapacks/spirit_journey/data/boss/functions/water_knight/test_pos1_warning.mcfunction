# ==========================================
# 水滴骑士 - Pos1位置方形攻击预警（测试MVP）
# 以Pos1 marker为中心召唤红色方形预警
# 长度5格，宽度10格
# ==========================================

# 在Pos1 marker位置召唤方形攻击预警（向右偏移4.5格）
execute at @e[tag=Pos1,limit=1] positioned ~ ~-0.1 ~-3 run function enemy_skill:warning/square_summon {scale_x:5.0,scale_z:16.0,et:60}

# 调试信息
say [水滴骑士] 已在Pos1位置召唤方形攻击预警（宽10×长5）
