# ==========================================
# 测试 motion_bullet - 检查子弹实体
# ==========================================

say [测试] 开始检测周围的子弹实体

# 检测spectral_arrow
execute as @a at @s if entity @e[tag=enemy_bullet,distance=..10] run say [测试] 找到enemy_bullet（光灵箭）
execute as @a at @s run tellraw @s [{"text":"[测试] 周围enemy_bullet数量: ","color":"yellow"},{"selector":"@e[tag=enemy_bullet,distance=..10]"}]

# 检测display
execute as @a at @s if entity @e[tag=block_bullet,distance=..10] run say [测试] 找到block_bullet（display）
execute as @a at @s run tellraw @s [{"text":"[测试] 周围block_bullet数量: ","color":"yellow"},{"selector":"@e[tag=block_bullet,distance=..10]"}]

# 显示具体信息
execute as @e[tag=enemy_bullet,limit=5] run say [子弹信息] 我是enemy_bullet
execute as @e[tag=block_bullet,limit=5] run say [Display信息] 我是block_bullet
