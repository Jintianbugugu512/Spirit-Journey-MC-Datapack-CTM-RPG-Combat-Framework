# ==========================================
# 测试 motion_bullet 单个子弹发射
# ==========================================

say [测试] 开始发射单个书本子弹

# 测试1：直接从玩家位置发射（添加tx,ty,tz参数）
execute at @p positioned ~ ~1.5 ~ run function enemy_skill:bullet/motion_bullet/summon {type:"item_display",name:"minecraft:book",mx:-1.5,my:0.0,mz:0.0,t:100,scale:1.2,dr:2,damage:8,tx:0,ty:0,tz:0}

say [测试] 已发射测试子弹（向西，mx:-1.5）
