# ==========================================
# 铁面教官 - 技能1：铁拳重击
# 向地面猛砸，造成小范围AOE伤害
# 发动前会提问，答对可以获得buff
# ==========================================

say [铁面教官] 使用技能：铁拳重击！接受我的考验吧！
playsound entity.iron_golem.attack master @a ~ ~ ~ 2 0.8
particle block iron_block ~ ~1 ~ 1 0.5 1 0 20 force

# 启动答题系统
function boss:iron_instructor/quiz/start_quiz
