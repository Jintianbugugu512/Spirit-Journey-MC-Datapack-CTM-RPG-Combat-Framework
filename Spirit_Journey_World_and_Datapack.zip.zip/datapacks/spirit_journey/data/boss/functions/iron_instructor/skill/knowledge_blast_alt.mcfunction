# ==========================================
# 铁面教官 - 技能：知识冲击·互补
# 发射互补角度的扇形书本弹幕（6本书夹在原5本书之间）
# ==========================================

say [铁面教官] 使用技能：知识冲击·互补！
playsound entity.iron_golem.attack master @a ~ ~ ~ 2 1.2
playsound entity.evoker.prepare_summon master @a ~ ~ ~ 1.5 1.4
particle enchant ~ ~1.5 ~ 0.5 0.5 0.5 1 30 force

# 发射位置：BOSS前方，高度1.5格
# 使用绝对坐标动量，面向西方（x负方向）
# 速度降低为原来的1/4，6本书填补缝隙

# 最北外侧（比原最北偏更北）
execute at @s positioned ~ ~ ~ run function enemy_skill:bullet/motion_bullet/summon {type:"item_display",name:"minecraft:book",mx:-0.3,my:0.0,mz:-0.25,t:200,scale:1.2,dr:1,damage:8,tx:0,ty:0,tz:0}

# 缝隙1（在原书3和书2之间）
execute at @s positioned ~ ~ ~ run function enemy_skill:bullet/motion_bullet/summon {type:"item_display",name:"minecraft:book",mx:-0.3375,my:0.0,mz:-0.1375,t:200,scale:1.2,dr:1,damage:8,tx:0,ty:0,tz:0}

# 缝隙2（在原书2和书1之间）
execute at @s positioned ~ ~ ~ run function enemy_skill:bullet/motion_bullet/summon {type:"item_display",name:"minecraft:book",mx:-0.3625,my:0.0,mz:-0.05,t:200,scale:1.2,dr:1,damage:8,tx:0,ty:0,tz:0}

# 缝隙3（在原书1和书4之间）
execute at @s positioned ~ ~ ~ run function enemy_skill:bullet/motion_bullet/summon {type:"item_display",name:"minecraft:book",mx:-0.3625,my:0.0,mz:0.05,t:200,scale:1.2,dr:1,damage:8,tx:0,ty:0,tz:0}

# 缝隙4（在原书4和书5之间）
execute at @s positioned ~ ~ ~ run function enemy_skill:bullet/motion_bullet/summon {type:"item_display",name:"minecraft:book",mx:-0.3375,my:0.0,mz:0.1375,t:200,scale:1.2,dr:1,damage:8,tx:0,ty:0,tz:0}

# 最南外侧（比原最南偏更南）
execute at @s positioned ~ ~ ~ run function enemy_skill:bullet/motion_bullet/summon {type:"item_display",name:"minecraft:book",mx:-0.3,my:0.0,mz:0.25,t:200,scale:1.2,dr:1,damage:8,tx:0,ty:0,tz:0}
