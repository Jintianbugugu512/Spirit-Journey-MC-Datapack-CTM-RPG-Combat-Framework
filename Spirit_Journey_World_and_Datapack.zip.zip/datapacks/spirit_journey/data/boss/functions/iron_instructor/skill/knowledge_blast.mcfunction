# ==========================================
# 铁面教官 - 技能：知识冲击
# 发射扇形书本弹幕攻击玩家
# ==========================================

say [铁面教官] 使用技能：知识冲击！
playsound entity.iron_golem.attack master @a ~ ~ ~ 2 1
playsound entity.evoker.prepare_summon master @a ~ ~ ~ 1.5 1.2
particle enchant ~ ~1.5 ~ 0.5 0.5 0.5 1 30 force

# 发射位置：BOSS前方1格，高度1.5格
# 使用绝对坐标动量，面向西方（x负方向）
# 速度降低为原来的1/4

# 中间1本（直线向西）
execute at @s positioned ~ ~ ~ run function enemy_skill:bullet/motion_bullet/summon {type:"item_display",name:"minecraft:book",mx:-0.375,my:0.0,mz:0.0,t:200,scale:1.2,dr:1,damage:8,tx:0,ty:0,tz:0}

# 向上偏移（向北偏）
execute at @s positioned ~ ~ ~ run function enemy_skill:bullet/motion_bullet/summon {type:"item_display",name:"minecraft:book",mx:-0.35,my:0.0,mz:-0.1,t:200,scale:1.2,dr:1,damage:8,tx:0,ty:0,tz:0}

# 向上偏移更多
execute at @s positioned ~ ~ ~ run function enemy_skill:bullet/motion_bullet/summon {type:"item_display",name:"minecraft:book",mx:-0.325,my:0.0,mz:-0.175,t:200,scale:1.2,dr:1,damage:8,tx:0,ty:0,tz:0}

# 向下偏移（向南偏）
execute at @s positioned ~ ~ ~ run function enemy_skill:bullet/motion_bullet/summon {type:"item_display",name:"minecraft:book",mx:-0.35,my:0.0,mz:0.1,t:200,scale:1.2,dr:1,damage:8,tx:0,ty:0,tz:0}

# 向下偏移更多
execute at @s positioned ~ ~ ~ run function enemy_skill:bullet/motion_bullet/summon {type:"item_display",name:"minecraft:book",mx:-0.325,my:0.0,mz:0.175,t:200,scale:1.2,dr:1,damage:8,tx:0,ty:0,tz:0}
