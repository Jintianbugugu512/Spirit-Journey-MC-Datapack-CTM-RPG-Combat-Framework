# 测试宏函数调用
tellraw @a {"text":"[测试] 开始测试宏函数","color":"gold"}

# 手动设置storage数据
data modify storage temp radius set value 2
data modify storage temp damage set value 10

tellraw @a [{"text":"[测试] storage设置完成 - radius: ","color":"yellow"},{"nbt":"radius","storage":"temp"},{"text":" damage: ","color":"yellow"},{"nbt":"damage","storage":"temp"}]

# 调用damage_apply
tellraw @a {"text":"[测试] 准备调用damage_apply...","color":"yellow"}
execute at @p run function enemy_skill:bullet/motion_bullet/damage_apply with storage temp

tellraw @a {"text":"[测试] 测试完成","color":"green"}
