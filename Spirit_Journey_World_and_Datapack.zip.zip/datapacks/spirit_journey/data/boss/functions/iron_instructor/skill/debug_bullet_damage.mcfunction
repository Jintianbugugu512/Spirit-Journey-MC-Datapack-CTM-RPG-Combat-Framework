# ==========================================
# 调试 - 显示子弹伤害信息
# ==========================================

tellraw @a {"text":"========== 子弹伤害调试信息 ==========","color":"gold"}

# 检查光灵箭（enemy_bullet）
execute as @e[tag=enemy_bullet,limit=5] run tellraw @a [{"text":"光灵箭 damage: ","color":"yellow"},{"score":{"name":"@s","objective":"damage"},"color":"white"},{"text":" | radius: ","color":"yellow"},{"score":{"name":"@s","objective":"radius"},"color":"white"}]

# 检查display（block_bullet）
execute as @e[tag=block_bullet,limit=5] run tellraw @a [{"text":"Display存在","color":"green"}]

# 测试存储数据
execute as @e[tag=enemy_bullet,limit=1] on passengers run tellraw @a [{"text":"Display骑在光灵箭上","color":"green"}]

tellraw @a {"text":"=====================================","color":"gold"}
