# 铁面教官BOSS - 更新血条显示
# 创建或更新BOSS血条

# 检查血条是否存在，不存在则创建
execute unless entity @s[tag=bossbar_created] run bossbar add iron_instructor {"text":"铁面教官","color":"gray","bold":true}
execute unless entity @s[tag=bossbar_created] run bossbar set iron_instructor color white
execute unless entity @s[tag=bossbar_created] run bossbar set iron_instructor style notched_10
execute unless entity @s[tag=bossbar_created] run bossbar set iron_instructor max 1500
execute unless entity @s[tag=bossbar_created] run tag @s add bossbar_created

# 更新血条值
execute store result bossbar iron_instructor value run scoreboard players get @s current_health

# 设置血条可见性（范围内玩家可见）
execute if entity @a[distance=..50] run bossbar set iron_instructor players @a[distance=..50]
execute unless entity @a[distance=..50] run bossbar set iron_instructor players

# BOSS死亡时移除血条
execute unless entity @s run bossbar remove iron_instructor
