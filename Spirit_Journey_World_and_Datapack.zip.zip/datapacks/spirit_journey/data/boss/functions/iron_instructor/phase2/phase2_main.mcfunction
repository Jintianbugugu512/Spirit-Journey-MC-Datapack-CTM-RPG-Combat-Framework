# ==========================================
# 铁面教官 - 第二阶段主循环
# 8秒一轮循环（更快），技能释放更频繁
# ==========================================

# 计时器递减（每tick-1）
scoreboard players remove @s[scores={timer=1..}] timer 1

# === 循环系统（8秒 = 160tick 一轮）===
# 当timer归零时，重置计时器
execute if score @s timer matches ..0 run scoreboard players set @s timer 160

# === 技能释放时间点：1s, 3s, 5s, 7s（即 140, 100, 60, 20 tick）===
execute if score @s timer matches 140 run function boss:iron_instructor/phase2/random_skill
execute if score @s timer matches 100 run function boss:iron_instructor/phase2/random_skill
execute if score @s timer matches 60 run function boss:iron_instructor/phase2/random_skill
execute if score @s timer matches 20 run function boss:iron_instructor/phase2/random_skill
