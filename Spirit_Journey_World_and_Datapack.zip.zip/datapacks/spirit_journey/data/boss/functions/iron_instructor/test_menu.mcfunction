# ==========================================
# 铁面教官 - 手动测试技能
# 用于测试单个技能效果
# ==========================================

# 显示可用技能列表
tellraw @a {"text":"=================== 铁面教官技能测试 ===================","color":"gold","bold":true}
tellraw @a {"text":"请点击下方技能名称来测试：","color":"yellow"}
tellraw @a {"text":" ","color":"white"}

# 可用技能
tellraw @a {"text":"【铁面教官技能】","color":"green","bold":true}
tellraw @a [{"text":"[1] ","color":"red","bold":true},{"text":"铁拳重击 (含答题)","color":"white","clickEvent":{"action":"run_command","value":"/function boss:iron_instructor/skill/iron_slam"},"hoverEvent":{"action":"show_text","contents":"点击测试"}}]
tellraw @a [{"text":"[2] ","color":"aqua","bold":true},{"text":"知识冲击 (扇形书本弹幕)","color":"white","clickEvent":{"action":"run_command","value":"/execute as @e[tag=iron_instructor,limit=1] at @s run function boss:iron_instructor/skill/knowledge_blast"},"hoverEvent":{"action":"show_text","contents":"点击测试 - 需要先召唤BOSS"}}]
tellraw @a [{"text":"[3] ","color":"light_purple","bold":true},{"text":"知识冲击·互补 (互补弹幕)","color":"white","clickEvent":{"action":"run_command","value":"/execute as @e[tag=iron_instructor,limit=1] at @s run function boss:iron_instructor/skill/knowledge_blast_alt"},"hoverEvent":{"action":"show_text","contents":"点击测试 - 夹在原弹幕之间"}}]

tellraw @a {"text":" ","color":"white"}

# 答题系统测试
tellraw @a {"text":"【答题系统】","color":"light_purple","bold":true}
tellraw @a [{"text":"[测试] ","color":"green","bold":true},{"text":"放置测试羊毛","color":"white","clickEvent":{"action":"run_command","value":"/function boss:iron_instructor/quiz/place_test_wool"},"hoverEvent":{"action":"show_text","contents":"在前方放置A/B/C羊毛"}}]
tellraw @a [{"text":"[测试] ","color":"green","bold":true},{"text":"启动答题系统","color":"white","clickEvent":{"action":"run_command","value":"/function boss:iron_instructor/quiz/test_quiz"},"hoverEvent":{"action":"show_text","contents":"独立测试答题"}}]

tellraw @a {"text":" ","color":"white"}

# 调试工具
tellraw @a {"text":"【调试工具】","color":"red","bold":true}
tellraw @a [{"text":"[调试] ","color":"red","bold":true},{"text":"检测子弹实体","color":"white","clickEvent":{"action":"run_command","value":"/function boss:iron_instructor/skill/test_detect_bullet"},"hoverEvent":{"action":"show_text","contents":"检测周围子弹"}}]
tellraw @a [{"text":"[调试] ","color":"red","bold":true},{"text":"子弹伤害信息","color":"white","clickEvent":{"action":"run_command","value":"/function boss:iron_instructor/skill/debug_bullet_damage"},"hoverEvent":{"action":"show_text","contents":"显示子弹伤害数据"}}]

tellraw @a {"text":"=======================================================","color":"gold","bold":true}
