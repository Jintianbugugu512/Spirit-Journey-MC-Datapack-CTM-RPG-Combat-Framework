# ==========================================
# 铁面教官 - 第一阶段主循环
# 10秒一轮循环，包含技能释放
# ==========================================

# 计时器递减（每tick-1）
scoreboard players remove @s[scores={timer=1..}] timer 1

# === 循环系统（10秒 = 200tick 一轮）===
# 当timer归零时，重置计时器
execute if score @s timer matches ..0 run scoreboard players set @s timer 200

# === 技能释放时间点：1s, 4s, 7s（即 180, 120, 60 tick）===
execute if score @s timer matches 180 run function boss:iron_instructor/phase1/random_skill
execute if score @s timer matches 120 run function boss:iron_instructor/phase1/random_skill
execute if score @s timer matches 60 run function boss:iron_instructor/phase1/random_skill
