# ==========================================
# 铁面教官 - 第一阶段随机技能选择
# 从2个技能中随机选择一个释放
# ==========================================

# 生成1-2的随机数
scoreboard players set @s temp 0
summon marker ~ ~ ~ {Tags:["random_temp"]}
execute store result score @s temp run data get entity @e[tag=random_temp,limit=1] UUID[0] 1
scoreboard players set #2 temp 2
scoreboard players operation @s temp %= #2 temp
scoreboard players add @s temp 1
kill @e[tag=random_temp]

# 根据随机数调用对应技能
execute if score @s temp matches 1 run function boss:iron_instructor/skill/iron_slam
execute if score @s temp matches 2 run function boss:iron_instructor/skill/knowledge_blast
