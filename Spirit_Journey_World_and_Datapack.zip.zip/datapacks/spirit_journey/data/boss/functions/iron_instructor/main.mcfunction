# 铁面教官BOSS - 主循环
# 每tick调用，控制BOSS行为

# 更新BOSS血条
function boss:iron_instructor/update_bossbar

# 阶段检查（用于阶段转换）
function boss:iron_instructor/phase_check

# 铁面教官答题系统
execute if score #quiz_active temp matches 1 run function boss:iron_instructor/quiz/detect_answer
execute if score #quiz_active temp matches 1 run function boss:iron_instructor/quiz/update_timer

# === 技能释放已暂停，使用测试函数手动调用 ===
# execute if score @s phase matches 1 run function boss:iron_instructor/phase1/phase1_main
# execute if score @s phase matches 2 run function boss:iron_instructor/phase2/phase2_main
