# 铁面教官 BOSS - 开发文档

## 📋 基本信息

- **BOSS名称**: 铁面教官 (Iron Instructor)
- **召唤方式**: `/function boss:iron_instructor/init`
- **召唤位置**: -651 100 1020（面朝x轴负方向）
- **实体类型**: 铁傀儡 (Iron Golem)
- **血量**: 1500 HP
- **防御**: 物理防御 30 / 魔法抗性 5
- **特殊属性**: 完全抗击退
- **特殊机制**: 答题系统 - 战斗中会提问，答对获得"知识的力量"buff

---

## 🎮 召唤方式

```mcfunction
/function boss:iron_instructor/init
```

---

## 📚 答题系统说明

### 答题机制
- BOSS释放技能时会提出问题（从50道题库中随机抽取）
- 玩家有**10秒**作答时间
- 通过站在脚下的**羊毛方块**上来选择答案：
  - **红色羊毛** = A选项
  - **蓝色羊毛** = B选项
  - **黄色羊毛** = C选项

### 奖惩机制
- **答对**: 获得"知识的力量"buff（暂时用say语句）
- **答错/超时**: 无奖励（暂时用say语句）

### 题库内容
包含50道题目，涵盖：
- 成语典故（如"卧薪尝胆"、"破釜沉舟"等）
- 文学常识（四大名著作者及人物）
- 古诗词（常见诗句接龙）
- 历史人物（四大发明、圣贤称号等）
- 文言文出处（《论语》《孟子》等）

所有题目均为**绝对正确**的标准答案，无争议性。

### 测试答题系统

**单独测试答题功能**（不需要召唤BOSS）：
```mcfunction
# 1. 放置测试羊毛
/function boss:iron_instructor/quiz/place_test_wool

# 2. 启动答题测试
/function boss:iron_instructor/quiz/test_quiz
```

---

## 📂 文件结构

```
boss/iron_instructor/
├── init.mcfunction                    # 初始化：召唤BOSS
├── main.mcfunction                    # 主循环：每tick调用
├── update_bossbar.mcfunction          # 血条更新
├── phase_check.mcfunction             # 阶段检查
├── phase_check_helper.mcfunction      # 阶段检查辅助
├── phase1/
│   ├── phase1_main.mcfunction         # 第一阶段主循环（10秒一轮）
│   └── random_skill.mcfunction        # 第一阶段随机技能选择
├── phase2/
│   ├── phase2_main.mcfunction         # 第二阶段主循环（8秒一轮）
│   └── random_skill.mcfunction        # 第二阶段随机技能选择
├── skill/
│   ├── iron_slam.mcfunction           # 技能1：铁拳重击（含答题）
│   ├── iron_charge.mcfunction         # 技能2：铁甲冲锋
│   ├── iron_sweep.mcfunction          # 技能3：横扫千军
│   ├── iron_throw.mcfunction          # 技能4：巨石投掷
│   ├── iron_roar.mcfunction           # 技能5：铁面怒吼
│   ├── iron_slam_enhanced.mcfunction  # 技能1强化版
│   ├── iron_charge_enhanced.mcfunction # 技能2强化版
│   ├── iron_sweep_enhanced.mcfunction  # 技能3强化版
│   ├── iron_throw_enhanced.mcfunction  # 技能4强化版
│   └── iron_ultimate.mcfunction       # 终极技能：铁之审判
└── quiz/
    ├── init_questions.mcfunction      # 初始化题库（50道题）
    ├── start_quiz.mcfunction          # 启动答题
    ├── random_question.mcfunction     # 随机抽题
    ├── display_question.mcfunction    # 显示题目
    ├── display_question_macro.mcfunction # 显示题目宏
    ├── detect_answer.mcfunction       # 检测玩家答题（每tick）
    ├── check_answer.mcfunction        # 检查答案（10秒后）
    ├── judge_player.mcfunction        # 判断单个玩家答案
    ├── reward_correct.mcfunction      # 答对奖励
    ├── punish_wrong.mcfunction        # 答错惩罚
    ├── test_quiz.mcfunction           # 测试答题系统
    └── place_test_wool.mcfunction     # 放置测试羊毛
```

---

## ⚙️ 系统机制

### 阶段系统
- **第一阶段**: 血量 > 50%
  - 10秒一轮循环
  - 技能释放时间点：1s, 4s, 7s (180, 120, 60 tick)
  - 5个基础技能随机选择

- **第二阶段**: 血量 ≤ 50%
  - 8秒一轮循环（更快）
  - 技能释放时间点：1s, 3s, 5s, 7s (140, 100, 60, 20 tick)
  - 5个强化技能随机选择

### 技能列表

#### 第一阶段技能
1. **铁拳重击** - 向地面猛砸，造成小范围AOE伤害
2. **铁甲冲锋** - 向前冲锋，撞击路径上的玩家
3. **横扫千军** - 挥舞双臂，360度横扫攻击
4. **巨石投掷** - 投掷铁块攻击远处玩家
5. **铁面怒吼** - 发出怒吼，震慑周围玩家

#### 第二阶段技能（强化版）
1. **铁拳重击·强** - 更大范围的地面猛砸
2. **铁甲冲锋·强** - 更快更远的冲锋
3. **横扫千军·强** - 更大范围的横扫攻击
4. **巨石投掷·强** - 投掷多个铁块
5. **铁之审判** - 终极大招，全场范围攻击

---

## 🔌 集成位置

### 主循环调用
**文件**: `z_loop/functions/entity_manager.mcfunction`

```mcfunction
# 铁面教官BOSS行为循环 - 优化：仅在BOSS区域有玩家时执行
execute if entity @a[distance=..50] as @e[tag=iron_instructor] at @s run function boss:iron_instructor/main
```

---

## 🎯 当前状态

### ✅ 已完成
- BOSS基础框架
- 阶段系统
- 血条系统
- 技能框架（10个技能，暂时用say语句占位）
- 铁傀儡实体配置
- 完全抗击退设置
- **答题系统完整实现**（50道题库）
- **羊毛检测答题机制**
- 主循环集成

### ⏳ 待实现
- 技能的实际伤害效果（目前都是say语句）
- "知识的力量"buff的实际效果
- 答对/答错的具体奖惩（减伤、增益等）
- 更多题目（当前50题，可扩展到200题）

---

## 📝 标签系统

- `iron_instructor` - 铁面教官BOSS
- `boss` - BOSS通用标签
- `enemy` - 敌人标签

---

## 🔧 记分板

- `phase` - 阶段（1或2）
- `skill` - 技能计数
- `timer` - 技能释放计时器
- `max_health` - 最大生命值 (1500)
- `current_health` - 当前生命值
- `physical_armor` - 物理防御 (30)
- `magic_resist` - 魔法抗性 (5)
- `hit_cooldown` - 命中冷却
- `temp` - 临时计算用
- **`quiz_answer`** - 玩家答案（1=A, 2=B, 3=C）
- **`quiz_answered`** - 玩家是否已答题（0=未答, 1=已答）

---

## 🎨 特色设计

1. **铁傀儡实体**: 使用原版铁傀儡，符合"教官"形象
2. **双阶段**: 血量50%触发第二阶段，技能加强且释放更频繁
3. **高物防低魔抗**: 物理防御30，魔法抗性5，鼓励玩家使用魔法攻击
4. **完全抗击退**: 无法被击退，体现教官的稳重

---

## 🔄 开发思路（MVP）

按照项目文档《THE_SUMMARY---LMJ.md》中的开发思维：
1. **最小MVP** - 先用say语句占位，验证框架正确
2. **迭代增强** - 逐步实现每个技能的实际效果
3. **抽象封装** - 将通用逻辑提取为API调用

当前处于第1步，框架已搭建完成，可以开始逐步实现技能效果。

---

**创建日期**: 2026-07-13  
**版本**: 1.0 MVP  
**Minecraft版本**: 1.20.4
