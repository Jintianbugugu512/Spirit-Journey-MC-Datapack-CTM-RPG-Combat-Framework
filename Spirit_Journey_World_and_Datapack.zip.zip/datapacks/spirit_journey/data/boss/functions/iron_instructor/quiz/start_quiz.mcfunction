# ==========================================
# 铁面教官 - 启动答题系统
# BOSS技能中调用此函数来启动答题
# ==========================================

# 随机抽取题目
function boss:iron_instructor/quiz/random_question

# 显示题目
function boss:iron_instructor/quiz/display_question

# 标记答题系统正在运行
scoreboard players set #quiz_active temp 1

# 调试信息
tellraw @a {"text":"[调试] 答题系统已激活，#quiz_active = 1","color":"green"}
