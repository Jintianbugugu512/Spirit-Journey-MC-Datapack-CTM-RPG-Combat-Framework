# ==========================================
# 答题系统 - 调试信息
# 显示当前玩家的答题状态
# ==========================================

tellraw @s {"text":"========== 答题系统调试信息 ==========","color":"gold"}

# 显示记分板值
execute store result score #debug_answer temp run scoreboard players get @s quiz_answer
execute store result score #debug_answered temp run scoreboard players get @s quiz_answered
tellraw @s [{"text":"quiz_answer: ","color":"yellow"},{"score":{"name":"#debug_answer","objective":"temp"},"color":"white"}]
tellraw @s [{"text":"quiz_answered: ","color":"yellow"},{"score":{"name":"#debug_answered","objective":"temp"},"color":"white"}]
tellraw @s [{"text":"#quiz_active: ","color":"yellow"},{"score":{"name":"#quiz_active","objective":"temp"},"color":"white"}]

# 检测脚下方块
execute at @s if block ~ ~-1 ~ red_wool run tellraw @s {"text":"脚下方块: 红色羊毛 ✓","color":"green"}
execute at @s if block ~ ~-1 ~ blue_wool run tellraw @s {"text":"脚下方块: 蓝色羊毛 ✓","color":"green"}
execute at @s if block ~ ~-1 ~ yellow_wool run tellraw @s {"text":"脚下方块: 黄色羊毛 ✓","color":"green"}
execute at @s unless block ~ ~-1 ~ red_wool unless block ~ ~-1 ~ blue_wool unless block ~ ~-1 ~ yellow_wool run tellraw @s {"text":"脚下方块: 不是答题羊毛 ✗","color":"red"}

# 测试记分板是否存在
execute unless score @s quiz_answer = @s quiz_answer run tellraw @s {"text":"警告: quiz_answer 记分板不存在！","color":"red","bold":true}
execute unless score @s quiz_answered = @s quiz_answered run tellraw @s {"text":"警告: quiz_answered 记分板不存在！","color":"red","bold":true}

tellraw @s {"text":"=====================================","color":"gold"}

# 尝试手动初始化
scoreboard players add @s quiz_answer 0
scoreboard players add @s quiz_answered 0
tellraw @s {"text":"已尝试初始化记分板","color":"gray"}
