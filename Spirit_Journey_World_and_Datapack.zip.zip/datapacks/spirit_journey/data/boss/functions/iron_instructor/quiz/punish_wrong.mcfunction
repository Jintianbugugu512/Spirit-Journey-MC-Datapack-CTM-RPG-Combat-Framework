# ==========================================
# 铁面教官 - 答错惩罚
# 玩家答错后的惩罚
# ==========================================

# 提示信息
tellraw @s {"text":"[答题系统] ✗ 回答错误！","color":"red","bold":true}
playsound entity.villager.no master @s ~ ~ ~ 1 1
particle angry_villager ~ ~2 ~ 0.3 0.3 0.3 0 5 force

# 暂时用say代替惩罚效果
say [铁面教官] @s 答错了！
