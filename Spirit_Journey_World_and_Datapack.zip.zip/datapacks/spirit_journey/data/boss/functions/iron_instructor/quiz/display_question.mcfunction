# ==========================================
# 铁面教官 - 显示题目
# 使用tellraw显示题目和选项
# ==========================================

# 播放提示音
playsound entity.experience_orb.pickup master @a ~ ~ ~ 2 1.5
playsound block.note_block.chime master @a ~ ~ ~ 2 2

# 显示标题
tellraw @a {"text":"===========================================","color":"gold","bold":true}
tellraw @a [{"text":"[铁面教官的提问] ","color":"red","bold":true},{"text":"请在10秒内作答！","color":"yellow"}]
tellraw @a {"text":" ","color":"white"}

# 显示题目（使用宏从storage读取）
function boss:iron_instructor/quiz/display_question_macro with storage quiz:current question

# 显示作答提示
tellraw @a {"text":" ","color":"white"}
tellraw @a {"text":">>> 请站在对应颜色的羊毛上作答 <<<","color":"aqua","bold":true}
tellraw @a {"text":"===========================================","color":"gold","bold":true}

# 初始化所有玩家的答题状态
scoreboard players set @a quiz_answer 0
scoreboard players set @a quiz_answered 0

# 创建倒计时bossbar
bossbar add quiz_timer {"text":"答题倒计时","color":"yellow","bold":true}
bossbar set quiz_timer color yellow
bossbar set quiz_timer style notched_10
bossbar set quiz_timer max 200
bossbar set quiz_timer value 200
bossbar set quiz_timer players @a
bossbar set quiz_timer visible true

# 初始化倒计时
scoreboard players set #quiz_timer temp 200

# 调试信息
tellraw @a {"text":"[调试] 已初始化所有玩家答题状态","color":"gray"}

# 10秒后检查答案
schedule function boss:iron_instructor/quiz/check_answer 200t
