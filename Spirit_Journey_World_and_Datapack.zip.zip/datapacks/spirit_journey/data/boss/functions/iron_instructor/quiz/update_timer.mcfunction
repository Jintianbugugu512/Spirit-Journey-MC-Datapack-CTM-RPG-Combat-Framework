# ==========================================
# 铁面教官 - 答题倒计时更新
# 每tick更新倒计时bossbar
# ==========================================

# 倒计时递减
scoreboard players remove #quiz_timer temp 1

# 更新bossbar值
execute store result bossbar quiz_timer value run scoreboard players get #quiz_timer temp

# 根据剩余时间改变颜色
execute if score #quiz_timer temp matches 140..200 run bossbar set quiz_timer color green
execute if score #quiz_timer temp matches 80..139 run bossbar set quiz_timer color yellow
execute if score #quiz_timer temp matches 40..79 run bossbar set quiz_timer color red
execute if score #quiz_timer temp matches 1..39 run bossbar set quiz_timer color red

# 倒计时结束时播放音效提示
execute if score #quiz_timer temp matches 60 run playsound block.note_block.pling master @a ~ ~ ~ 1 1.5
execute if score #quiz_timer temp matches 40 run playsound block.note_block.pling master @a ~ ~ ~ 1 1.2
execute if score #quiz_timer temp matches 20 run playsound block.note_block.pling master @a ~ ~ ~ 1 1
execute if score #quiz_timer temp matches 10 run playsound block.note_block.bell master @a ~ ~ ~ 1 2
execute if score #quiz_timer temp matches 5 run playsound block.note_block.bell master @a ~ ~ ~ 1 2
execute if score #quiz_timer temp matches 4 run playsound block.note_block.bell master @a ~ ~ ~ 1 2
execute if score #quiz_timer temp matches 3 run playsound block.note_block.bell master @a ~ ~ ~ 1 2
execute if score #quiz_timer temp matches 2 run playsound block.note_block.bell master @a ~ ~ ~ 1 2
execute if score #quiz_timer temp matches 1 run playsound block.note_block.bell master @a ~ ~ ~ 1 2

# 更新bossbar标题显示剩余秒数
execute if score #quiz_timer temp matches 180..200 run bossbar set quiz_timer name {"text":"答题倒计时 - 10秒","color":"green","bold":true}
execute if score #quiz_timer temp matches 160..179 run bossbar set quiz_timer name {"text":"答题倒计时 - 9秒","color":"green","bold":true}
execute if score #quiz_timer temp matches 140..159 run bossbar set quiz_timer name {"text":"答题倒计时 - 8秒","color":"green","bold":true}
execute if score #quiz_timer temp matches 120..139 run bossbar set quiz_timer name {"text":"答题倒计时 - 7秒","color":"yellow","bold":true}
execute if score #quiz_timer temp matches 100..119 run bossbar set quiz_timer name {"text":"答题倒计时 - 6秒","color":"yellow","bold":true}
execute if score #quiz_timer temp matches 80..99 run bossbar set quiz_timer name {"text":"答题倒计时 - 5秒","color":"yellow","bold":true}
execute if score #quiz_timer temp matches 60..79 run bossbar set quiz_timer name {"text":"答题倒计时 - 4秒","color":"red","bold":true}
execute if score #quiz_timer temp matches 40..59 run bossbar set quiz_timer name {"text":"答题倒计时 - 3秒","color":"red","bold":true}
execute if score #quiz_timer temp matches 20..39 run bossbar set quiz_timer name {"text":"答题倒计时 - 2秒","color":"red","bold":true}
execute if score #quiz_timer temp matches 1..19 run bossbar set quiz_timer name {"text":"答题倒计时 - 1秒","color":"red","bold":true}
execute if score #quiz_timer temp matches ..0 run bossbar set quiz_timer name {"text":"时间到！","color":"dark_red","bold":true}
