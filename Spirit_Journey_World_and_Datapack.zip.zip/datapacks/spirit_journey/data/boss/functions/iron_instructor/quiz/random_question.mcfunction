# ==========================================
# 铁面教官 - 随机抽取题目
# 从题库中随机选择一道题目（200题）
# ==========================================

# 生成随机数（0-199，对应200道题）
summon marker ~ ~ ~ {Tags:["random_quiz_temp"]}
execute store result score #quiz_random temp run data get entity @e[tag=random_quiz_temp,limit=1] UUID[0] 1
scoreboard players set #200 temp 200
scoreboard players operation #quiz_random temp %= #200 temp
kill @e[tag=random_quiz_temp]

# 根据随机数选择题目（使用二分查找优化）
# 0-99
execute if score #quiz_random temp matches 0..99 run function boss:iron_instructor/quiz/select_question_0_99
# 100-199
execute if score #quiz_random temp matches 100..199 run function boss:iron_instructor/quiz/select_question_100_199
