# ==========================================
# 铁面教官 - 检查答案
# 10秒后执行，判断答案正确性
# ==========================================

# 播放时间到的音效
playsound block.anvil.land master @a ~ ~ ~ 1 1.5

# 获取正确答案
execute store result score #correct_answer temp run data get storage quiz:current question.answer

# 判断每个玩家的答案
execute as @a run function boss:iron_instructor/quiz/judge_player

# 清空答题状态
scoreboard players set @a quiz_answer 0
scoreboard players set @a quiz_answered 0
scoreboard players set #quiz_active temp 0

# 移除倒计时bossbar
bossbar set quiz_timer visible false
bossbar remove quiz_timer
