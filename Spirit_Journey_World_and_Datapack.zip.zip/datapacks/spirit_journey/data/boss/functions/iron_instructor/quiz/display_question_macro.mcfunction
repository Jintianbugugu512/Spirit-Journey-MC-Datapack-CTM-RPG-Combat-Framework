# ==========================================
# 铁面教官 - 显示题目宏函数
# 使用宏参数显示题目内容
# ==========================================

$tellraw @a [{"text":"【题目】","color":"gold","bold":true},{"text":"$(question)","color":"white"}]
$tellraw @a [{"text":"  [A] ","color":"red","bold":true},{"text":"$(A)","color":"red"}]
$tellraw @a [{"text":"  [B] ","color":"blue","bold":true},{"text":"$(B)","color":"blue"}]
$tellraw @a [{"text":"  [C] ","color":"yellow","bold":true},{"text":"$(C)","color":"yellow"}]
