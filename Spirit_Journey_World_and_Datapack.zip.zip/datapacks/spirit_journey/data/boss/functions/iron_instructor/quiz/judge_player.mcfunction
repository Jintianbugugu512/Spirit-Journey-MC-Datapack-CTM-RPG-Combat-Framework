# ==========================================
# 铁面教官 - 判断单个玩家答案
# 对比玩家答案和正确答案
# ==========================================

# 未作答（quiz_answered=0）
execute if score @s quiz_answered matches 0 run tellraw @s {"text":"[答题系统] 你未作答！算作答错。","color":"red","bold":true}
execute if score @s quiz_answered matches 0 run playsound entity.villager.no master @s ~ ~ ~ 1 1
execute if score @s quiz_answered matches 0 run say [铁面教官] @s 答错了！

# 已作答，判断正误
execute if score @s quiz_answered matches 1 if score @s quiz_answer = #correct_answer temp run function boss:iron_instructor/quiz/reward_correct
execute if score @s quiz_answered matches 1 unless score @s quiz_answer = #correct_answer temp run function boss:iron_instructor/quiz/punish_wrong
