# ==========================================
# 铁面教官 - 测试答题系统
# 独立测试答题功能，不需要召唤BOSS
# ==========================================

# 初始化题库
function boss:iron_instructor/quiz/init_questions

# 启动答题
function boss:iron_instructor/quiz/start_quiz

say [测试] 答题系统已启动，请在10秒内站在对应颜色的羊毛上作答
