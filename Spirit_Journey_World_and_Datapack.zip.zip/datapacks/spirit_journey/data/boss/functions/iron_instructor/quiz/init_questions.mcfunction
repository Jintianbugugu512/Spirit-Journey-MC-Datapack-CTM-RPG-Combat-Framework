# ==========================================
# 铁面教官 - 题库初始化
# 存储所有题目到storage
# ==========================================

# 创建题库数组
data modify storage quiz:iron_instructor questions set value []

# === 成语典故类 ===
# 题目1
data modify storage quiz:iron_instructor questions append value {id:1,question:"成语'卧薪尝胆'说的是哪位历史人物？",A:"勾践",B:"夫差",C:"项羽",answer:1}

# 题目2
data modify storage quiz:iron_instructor questions append value {id:2,question:"'破釜沉舟'的主人公是谁？",A:"项羽",B:"刘邦",C:"韩信",answer:1}

# 题目3
data modify storage quiz:iron_instructor questions append value {id:3,question:"'纸上谈兵'说的是谁？",A:"赵括",B:"廉颇",C:"白起",answer:1}

# 题目4
data modify storage quiz:iron_instructor questions append value {id:4,question:"'三顾茅庐'中被拜访的是谁？",A:"诸葛亮",B:"司马懿",C:"庞统",answer:1}

# 题目5
data modify storage quiz:iron_instructor questions append value {id:5,question:"'完璧归赵'的主人公是？",A:"蔺相如",B:"廉颇",C:"赵奢",answer:1}

# 题目6
data modify storage quiz:iron_instructor questions append value {id:6,question:"'负荆请罪'的主人公是？",A:"廉颇",B:"蔺相如",C:"赵括",answer:1}

# 题目7
data modify storage quiz:iron_instructor questions append value {id:7,question:"'四面楚歌'说的是哪位人物？",A:"项羽",B:"刘邦",C:"韩信",answer:1}

# 题目8
data modify storage quiz:iron_instructor questions append value {id:8,question:"'指鹿为马'的主人公是？",A:"赵高",B:"秦二世",C:"李斯",answer:1}

# 题目9
data modify storage quiz:iron_instructor questions append value {id:9,question:"'背水一战'的主人公是？",A:"韩信",B:"项羽",C:"刘邦",answer:1}

# 题目10
data modify storage quiz:iron_instructor questions append value {id:10,question:"'鸡鸣狗盗'出自哪个战国四公子？",A:"孟尝君",B:"信陵君",C:"春申君",answer:1}

# === 文学常识类 ===
# 题目11
data modify storage quiz:iron_instructor questions append value {id:11,question:"《红楼梦》的作者是？",A:"曹雪芹",B:"吴承恩",C:"施耐庵",answer:1}

# 题目12
data modify storage quiz:iron_instructor questions append value {id:12,question:"《西游记》的作者是？",A:"吴承恩",B:"曹雪芹",C:"罗贯中",answer:1}

# 题目13
data modify storage quiz:iron_instructor questions append value {id:13,question:"《三国演义》的作者是？",A:"罗贯中",B:"施耐庵",C:"吴承恩",answer:1}

# 题目14
data modify storage quiz:iron_instructor questions append value {id:14,question:"《水浒传》的作者是？",A:"施耐庵",B:"罗贯中",C:"曹雪芹",answer:1}

# 题目15
data modify storage quiz:iron_instructor questions append value {id:15,question:"'宝玉'是哪部小说的主角？",A:"《红楼梦》",B:"《西游记》",C:"《水浒传》",answer:1}

# 题目16
data modify storage quiz:iron_instructor questions append value {id:16,question:"'孙悟空'出自哪部小说？",A:"《西游记》",B:"《封神演义》",C:"《三国演义》",answer:1}

# 题目17
data modify storage quiz:iron_instructor questions append value {id:17,question:"'诸葛亮'是哪部小说的人物？",A:"《三国演义》",B:"《水浒传》",C:"《西游记》",answer:1}

# 题目18
data modify storage quiz:iron_instructor questions append value {id:18,question:"'林黛玉'是哪部小说的人物？",A:"《红楼梦》",B:"《西游记》",C:"《水浒传》",answer:1}

# 题目19
data modify storage quiz:iron_instructor questions append value {id:19,question:"'武松'是哪部小说的人物？",A:"《水浒传》",B:"《三国演义》",C:"《西游记》",answer:1}

# 题目20
data modify storage quiz:iron_instructor questions append value {id:20,question:"'猪八戒'的原名是？",A:"天蓬元帅",B:"卷帘大将",C:"斗战胜佛",answer:1}

# === 古诗词类 ===
# 题目21
data modify storage quiz:iron_instructor questions append value {id:21,question:"'春眠不觉晓'的下一句是？",A:"处处闻啼鸟",B:"夜来风雨声",C:"花落知多少",answer:1}

# 题目22
data modify storage quiz:iron_instructor questions append value {id:22,question:"'床前明月光'的下一句是？",A:"疑是地上霜",B:"举头望明月",C:"低头思故乡",answer:1}

# 题目23
data modify storage quiz:iron_instructor questions append value {id:23,question:"'举头望明月'的下一句是？",A:"低头思故乡",B:"疑是地上霜",C:"床前明月光",answer:1}

# 题目24
data modify storage quiz:iron_instructor questions append value {id:24,question:"'白日依山尽'的下一句是？",A:"黄河入海流",B:"欲穷千里目",C:"更上一层楼",answer:1}

# 题目25
data modify storage quiz:iron_instructor questions append value {id:25,question:"'欲穷千里目'的下一句是？",A:"更上一层楼",B:"黄河入海流",C:"白日依山尽",answer:1}

# 题目26
data modify storage quiz:iron_instructor questions append value {id:26,question:"'锄禾日当午'的下一句是？",A:"汗滴禾下土",B:"谁知盘中餐",C:"粒粒皆辛苦",answer:1}

# 题目27
data modify storage quiz:iron_instructor questions append value {id:27,question:"'谁知盘中餐'的下一句是？",A:"粒粒皆辛苦",B:"汗滴禾下土",C:"锄禾日当午",answer:1}

# 题目28
data modify storage quiz:iron_instructor questions append value {id:28,question:"'野火烧不尽'的下一句是？",A:"春风吹又生",B:"离离原上草",C:"一岁一枯荣",answer:1}

# 题目29
data modify storage quiz:iron_instructor questions append value {id:29,question:"'窗含西岭千秋雪'的下一句是？",A:"门泊东吴万里船",B:"两个黄鹂鸣翠柳",C:"一行白鹭上青天",answer:1}

# 题目30
data modify storage quiz:iron_instructor questions append value {id:30,question:"'飞流直下三千尺'的下一句是？",A:"疑是银河落九天",B:"日照香炉生紫烟",C:"遥看瀑布挂前川",answer:1}

# === 历史人物类 ===
# 题目31
data modify storage quiz:iron_instructor questions append value {id:31,question:"发明造纸术的是？",A:"蔡伦",B:"张衡",C:"华佗",answer:1}

# 题目32
data modify storage quiz:iron_instructor questions append value {id:32,question:"发明活字印刷术的是？",A:"毕昇",B:"蔡伦",C:"张衡",answer:1}

# 题目33
data modify storage quiz:iron_instructor questions append value {id:33,question:"发明地动仪的是？",A:"张衡",B:"蔡伦",C:"祖冲之",answer:1}

# 题目34
data modify storage quiz:iron_instructor questions append value {id:34,question:"发明指南针的朝代是？",A:"宋朝",B:"唐朝",C:"汉朝",answer:1}

# 题目35
data modify storage quiz:iron_instructor questions append value {id:35,question:"'医圣'是指？",A:"张仲景",B:"华佗",C:"李时珍",answer:1}

# 题目36
data modify storage quiz:iron_instructor questions append value {id:36,question:"'书圣'是指？",A:"王羲之",B:"颜真卿",C:"柳公权",answer:1}

# 题目37
data modify storage quiz:iron_instructor questions append value {id:37,question:"'诗仙'是指？",A:"李白",B:"杜甫",C:"白居易",answer:1}

# 题目38
data modify storage quiz:iron_instructor questions append value {id:38,question:"'诗圣'是指？",A:"杜甫",B:"李白",C:"白居易",answer:1}

# 题目39
data modify storage quiz:iron_instructor questions append value {id:39,question:"统一六国的秦朝皇帝是？",A:"秦始皇",B:"秦二世",C:"秦孝公",answer:1}

# 题目40
data modify storage quiz:iron_instructor questions append value {id:40,question:"建立汉朝的是？",A:"刘邦",B:"项羽",C:"刘备",answer:1}

# === 文言文出处类 ===
# 题目41
data modify storage quiz:iron_instructor questions append value {id:41,question:"'学而时习之，不亦说乎'出自？",A:"《论语》",B:"《孟子》",C:"《大学》",answer:1}

# 题目42
data modify storage quiz:iron_instructor questions append value {id:42,question:"'温故而知新'出自？",A:"《论语》",B:"《孟子》",C:"《中庸》",answer:1}

# 题目43
data modify storage quiz:iron_instructor questions append value {id:43,question:"'三人行，必有我师焉'出自？",A:"《论语》",B:"《孟子》",C:"《大学》",answer:1}

# 题目44
data modify storage quiz:iron_instructor questions append value {id:44,question:"'天时不如地利'出自？",A:"《孟子》",B:"《论语》",C:"《荀子》",answer:1}

# 题目45
data modify storage quiz:iron_instructor questions append value {id:45,question:"'生于忧患，死于安乐'出自？",A:"《孟子》",B:"《论语》",C:"《墨子》",answer:1}

# 题目46
data modify storage quiz:iron_instructor questions append value {id:46,question:"'鱼，我所欲也'出自？",A:"《孟子》",B:"《庄子》",C:"《论语》",answer:1}

# 题目47
data modify storage quiz:iron_instructor questions append value {id:47,question:"'己所不欲，勿施于人'出自？",A:"《论语》",B:"《孟子》",C:"《大学》",answer:1}

# 题目48
data modify storage quiz:iron_instructor questions append value {id:48,question:"'学而不思则罔'的下一句是？",A:"思而不学则殆",B:"温故而知新",C:"不亦乐乎",answer:1}

# 题目49
data modify storage quiz:iron_instructor questions append value {id:49,question:"'知之者不如好之者'的下一句是？",A:"好之者不如乐之者",B:"温故而知新",C:"学而时习之",answer:1}

# 题目50
data modify storage quiz:iron_instructor questions append value {id:50,question:"'有朋自远方来'的下一句是？",A:"不亦乐乎",B:"不亦说乎",C:"必有我师焉",answer:1}

# === 更多成语典故类 ===
# 题目51
data modify storage quiz:iron_instructor questions append value {id:51,question:"'卧薪尝胆'中的'胆'指的是什么？",A:"苦胆",B:"勇气",C:"胆量",answer:1}

# 题目52
data modify storage quiz:iron_instructor questions append value {id:52,question:"'围魏救赵'的主人公是？",A:"孙膑",B:"庞涓",C:"孙武",answer:1}

# 题目53
data modify storage quiz:iron_instructor questions append value {id:53,question:"'草船借箭'的主人公是？",A:"诸葛亮",B:"周瑜",C:"曹操",answer:1}

# 题目54
data modify storage quiz:iron_instructor questions append value {id:54,question:"'毛遂自荐'的主人公是？",A:"毛遂",B:"赵括",C:"平原君",answer:1}

# 题目55
data modify storage quiz:iron_instructor questions append value {id:55,question:"'闻鸡起舞'的主人公是？",A:"祖逖",B:"刘琨",C:"岳飞",answer:1}

# 题目56
data modify storage quiz:iron_instructor questions append value {id:56,question:"'凿壁偷光'的主人公是？",A:"匡衡",B:"孙康",C:"车胤",answer:1}

# 题目57
data modify storage quiz:iron_instructor questions append value {id:57,question:"'悬梁刺股'中'刺股'的主人公是？",A:"苏秦",B:"孙敬",C:"车胤",answer:1}

# 题目58
data modify storage quiz:iron_instructor questions append value {id:58,question:"'铁杵磨针'的主人公是？",A:"李白",B:"杜甫",C:"白居易",answer:1}

# 题目59
data modify storage quiz:iron_instructor questions append value {id:59,question:"'程门立雪'讲的是谁求学？",A:"杨时",B:"游酢",C:"程颐",answer:1}

# 题目60
data modify storage quiz:iron_instructor questions append value {id:60,question:"'东施效颦'中的'西施'是哪国人？",A:"越国",B:"吴国",C:"齐国",answer:1}

# === 更多古诗词类 ===
# 题目61
data modify storage quiz:iron_instructor questions append value {id:61,question:"'人生自古谁无死'的下一句是？",A:"留取丹心照汗青",B:"精忠报国",C:"天下兴亡",answer:1}

# 题目62
data modify storage quiz:iron_instructor questions append value {id:62,question:"'泊船瓜洲'的作者是？",A:"王安石",B:"苏轼",C:"杜甫",answer:1}

# 题目63
data modify storage quiz:iron_instructor questions append value {id:63,question:"'春风又绿江南岸'的下一句是？",A:"明月何时照我还",B:"春风不度玉门关",C:"春来江水绿如蓝",answer:1}

# 题目64
data modify storage quiz:iron_instructor questions append value {id:64,question:"'独在异乡为异客'的下一句是？",A:"每逢佳节倍思亲",B:"遥知兄弟登高处",C:"遍插茱萸少一人",answer:1}

# 题目65
data modify storage quiz:iron_instructor questions append value {id:65,question:"'遥知兄弟登高处'的下一句是？",A:"遍插茱萸少一人",B:"每逢佳节倍思亲",C:"独在异乡为异客",answer:1}

# 题目66
data modify storage quiz:iron_instructor questions append value {id:66,question:"'停车坐爱枫林晚'的下一句是？",A:"霜叶红于二月花",B:"枫叶红于二月花",C:"红叶红于二月花",answer:1}

# 题目67
data modify storage quiz:iron_instructor questions append value {id:67,question:"'两岸青山相对出'的下一句是？",A:"孤帆一片日边来",B:"轻舟已过万重山",C:"千里江陵一日还",answer:1}

# 题目68
data modify storage quiz:iron_instructor questions append value {id:68,question:"'桃花潭水深千尺'的下一句是？",A:"不及汪伦送我情",B:"不及江水半江深",C:"疑是银河落九天",answer:1}

# 题目69
data modify storage quiz:iron_instructor questions append value {id:69,question:"'朝辞白帝彩云间'的下一句是？",A:"千里江陵一日还",B:"两岸猿声啼不住",C:"轻舟已过万重山",answer:1}

# 题目70
data modify storage quiz:iron_instructor questions append value {id:70,question:"'千里江陵一日还'的上一句是？",A:"朝辞白帝彩云间",B:"两岸猿声啼不住",C:"轻舟已过万重山",answer:1}

# === 历史朝代类 ===
# 题目71
data modify storage quiz:iron_instructor questions append value {id:71,question:"中国第一个统一的封建王朝是？",A:"秦朝",B:"汉朝",C:"周朝",answer:1}

# 题目72
data modify storage quiz:iron_instructor questions append value {id:72,question:"唐朝的开国皇帝是？",A:"李渊",B:"李世民",C:"李隆基",answer:1}

# 题目73
data modify storage quiz:iron_instructor questions append value {id:73,question:"宋朝的开国皇帝是？",A:"赵匡胤",B:"赵光义",C:"赵构",answer:1}

# 题目74
data modify storage quiz:iron_instructor questions append value {id:74,question:"明朝的开国皇帝是？",A:"朱元璋",B:"朱棣",C:"朱由检",answer:1}

# 题目75
data modify storage quiz:iron_instructor questions append value {id:75,question:"清朝的开国皇帝是？",A:"皇太极",B:"努尔哈赤",C:"顺治",answer:1}

# 题目76
data modify storage quiz:iron_instructor questions append value {id:76,question:"'贞观之治'是哪位皇帝的统治时期？",A:"唐太宗",B:"唐高宗",C:"唐玄宗",answer:1}

# 题目77
data modify storage quiz:iron_instructor questions append value {id:77,question:"'开元盛世'是哪位皇帝的统治时期？",A:"唐玄宗",B:"唐太宗",C:"唐高宗",answer:1}

# 题目78
data modify storage quiz:iron_instructor questions append value {id:78,question:"'康乾盛世'中的'康'指的是？",A:"康熙",B:"康有为",C:"康健",answer:1}

# 题目79
data modify storage quiz:iron_instructor questions append value {id:79,question:"中国最后一个封建王朝是？",A:"清朝",B:"明朝",C:"元朝",answer:1}

# 题目80
data modify storage quiz:iron_instructor questions append value {id:80,question:"中国最后一个皇帝是？",A:"溥仪",B:"光绪",C:"宣统",answer:1}

# === 更多文言文出处类 ===
# 题目81
data modify storage quiz:iron_instructor questions append value {id:81,question:"'人之初，性本善'出自？",A:"《三字经》",B:"《论语》",C:"《孟子》",answer:1}

# 题目82
data modify storage quiz:iron_instructor questions append value {id:82,question:"'知之为知之，不知为不知'出自？",A:"《论语》",B:"《孟子》",C:"《大学》",answer:1}

# 题目83
data modify storage quiz:iron_instructor questions append value {id:83,question:"'不以规矩，不能成方圆'出自？",A:"《孟子》",B:"《论语》",C:"《墨子》",answer:1}

# 题目84
data modify storage quiz:iron_instructor questions append value {id:84,question:"'富贵不能淫，贫贱不能移'出自？",A:"《孟子》",B:"《论语》",C:"《荀子》",answer:1}

# 题目85
data modify storage quiz:iron_instructor questions append value {id:85,question:"'君子坦荡荡，小人长戚戚'出自？",A:"《论语》",B:"《孟子》",C:"《大学》",answer:1}

# 题目86
data modify storage quiz:iron_instructor questions append value {id:86,question:"'吾日三省吾身'出自？",A:"《论语》",B:"《孟子》",C:"《中庸》",answer:1}

# 题目87
data modify storage quiz:iron_instructor questions append value {id:87,question:"'工欲善其事，必先利其器'出自？",A:"《论语》",B:"《孟子》",C:"《墨子》",answer:1}

# 题目88
data modify storage quiz:iron_instructor questions append value {id:88,question:"'学而不厌，诲人不倦'出自？",A:"《论语》",B:"《孟子》",C:"《大学》",answer:1}

# 题目89
data modify storage quiz:iron_instructor questions append value {id:89,question:"'言必信，行必果'出自？",A:"《论语》",B:"《孟子》",C:"《墨子》",answer:1}

# 题目90
data modify storage quiz:iron_instructor questions append value {id:90,question:"'岁寒，然后知松柏之后凋也'出自？",A:"《论语》",B:"《孟子》",C:"《庄子》",answer:1}

# === 文化常识类 ===
# 题目91
data modify storage quiz:iron_instructor questions append value {id:91,question:"中国的四大发明不包括？",A:"地动仪",B:"造纸术",C:"火药",answer:1}

# 题目92
data modify storage quiz:iron_instructor questions append value {id:92,question:"'文房四宝'指的是？",A:"笔墨纸砚",B:"琴棋书画",C:"诗词歌赋",answer:1}

# 题目93
data modify storage quiz:iron_instructor questions append value {id:93,question:"'五谷'中不包括？",A:"茶",B:"稻",C:"麦",answer:1}

# 题目94
data modify storage quiz:iron_instructor questions append value {id:94,question:"'岁寒三友'指的是？",A:"松竹梅",B:"梅兰竹",C:"松柏梅",answer:1}

# 题目95
data modify storage quiz:iron_instructor questions append value {id:95,question:"'花中四君子'指的是？",A:"梅兰竹菊",B:"松竹梅菊",C:"梅兰菊荷",answer:1}

# 题目96
data modify storage quiz:iron_instructor questions append value {id:96,question:"中国传统的'五行'不包括？",A:"风",B:"金",C:"木",answer:1}

# 题目97
data modify storage quiz:iron_instructor questions append value {id:97,question:"'六艺'中不包括？",A:"医",B:"礼",C:"乐",answer:1}

# 题目98
data modify storage quiz:iron_instructor questions append value {id:98,question:"'春秋五霸'中不包括？",A:"秦穆公",B:"齐桓公",C:"晋文公",answer:1}

# 题目99
data modify storage quiz:iron_instructor questions append value {id:99,question:"'战国七雄'中不包括？",A:"吴国",B:"齐国",C:"楚国",answer:1}

# 题目100
data modify storage quiz:iron_instructor questions append value {id:100,question:"中国古代'四大美女'不包括？",A:"赵飞燕",B:"西施",C:"王昭君",answer:1}

# === 更多古诗词作者类 ===
# 题目101
data modify storage quiz:iron_instructor questions append value {id:101,question:"'静夜思'的作者是？",A:"李白",B:"杜甫",C:"白居易",answer:1}

# 题目102
data modify storage quiz:iron_instructor questions append value {id:102,question:"'春晓'的作者是？",A:"孟浩然",B:"王维",C:"李白",answer:1}

# 题目103
data modify storage quiz:iron_instructor questions append value {id:103,question:"'登鹳雀楼'的作者是？",A:"王之涣",B:"王维",C:"王勃",answer:1}

# 题目104
data modify storage quiz:iron_instructor questions append value {id:104,question:"'悯农'（锄禾日当午）的作者是？",A:"李绅",B:"李白",C:"杜甫",answer:1}

# 题目105
data modify storage quiz:iron_instructor questions append value {id:105,question:"'赋得古原草送别'的作者是？",A:"白居易",B:"李白",C:"杜甫",answer:1}

# 题目106
data modify storage quiz:iron_instructor questions append value {id:106,question:"'绝句'（两个黄鹂鸣翠柳）的作者是？",A:"杜甫",B:"李白",C:"白居易",answer:1}

# 题目107
data modify storage quiz:iron_instructor questions append value {id:107,question:"'九月九日忆山东兄弟'的作者是？",A:"王维",B:"王勃",C:"王之涣",answer:1}

# 题目108
data modify storage quiz:iron_instructor questions append value {id:108,question:"'山行'（远上寒山石径斜）的作者是？",A:"杜牧",B:"杜甫",C:"白居易",answer:1}

# 题目109
data modify storage quiz:iron_instructor questions append value {id:109,question:"'望庐山瀑布'的作者是？",A:"李白",B:"杜甫",C:"白居易",answer:1}

# 题目110
data modify storage quiz:iron_instructor questions append value {id:110,question:"'赠汪伦'的作者是？",A:"李白",B:"杜甫",C:"王维",answer:1}

# === 四大名著详细知识 ===
# 题目111
data modify storage quiz:iron_instructor questions append value {id:111,question:"《西游记》中孙悟空的师父是？",A:"菩提祖师",B:"唐僧",C:"如来佛祖",answer:1}

# 题目112
data modify storage quiz:iron_instructor questions append value {id:112,question:"《西游记》中孙悟空被压在哪座山下？",A:"五行山",B:"花果山",C:"火焰山",answer:1}

# 题目113
data modify storage quiz:iron_instructor questions append value {id:113,question:"《三国演义》中'桃园三结义'不包括？",A:"诸葛亮",B:"刘备",C:"关羽",answer:1}

# 题目114
data modify storage quiz:iron_instructor questions append value {id:114,question:"《三国演义》中'三顾茅庐'请的是谁？",A:"诸葛亮",B:"庞统",C:"司马懿",answer:1}

# 题目115
data modify storage quiz:iron_instructor questions append value {id:115,question:"《水浒传》中绰号'豹子头'的是？",A:"林冲",B:"武松",C:"李逵",answer:1}

# 题目116
data modify storage quiz:iron_instructor questions append value {id:116,question:"《水浒传》中绰号'黑旋风'的是？",A:"李逵",B:"林冲",C:"鲁智深",answer:1}

# 题目117
data modify storage quiz:iron_instructor questions append value {id:117,question:"《水浒传》中'智取生辰纲'的主要策划者是？",A:"吴用",B:"晁盖",C:"宋江",answer:1}

# 题目118
data modify storage quiz:iron_instructor questions append value {id:118,question:"《红楼梦》中贾宝玉的表妹是？",A:"林黛玉",B:"薛宝钗",C:"史湘云",answer:1}

# 题目119
data modify storage quiz:iron_instructor questions append value {id:119,question:"《红楼梦》的别名是？",A:"《石头记》",B:"《金陵十二钗》",C:"《宝玉传》",answer:1}

# 题目120
data modify storage quiz:iron_instructor questions append value {id:120,question:"《西游记》共经历了多少难？",A:"八十一难",B:"七十二难",C:"九十九难",answer:1}

# === 更多历史人物类 ===
# 题目121
data modify storage quiz:iron_instructor questions append value {id:121,question:"'画圣'是指？",A:"吴道子",B:"顾恺之",C:"张择端",answer:1}

# 题目122
data modify storage quiz:iron_instructor questions append value {id:122,question:"'草圣'是指？",A:"张旭",B:"王羲之",C:"颜真卿",answer:1}

# 题目123
data modify storage quiz:iron_instructor questions append value {id:123,question:"'药王'是指？",A:"孙思邈",B:"李时珍",C:"华佗",answer:1}

# 题目124
data modify storage quiz:iron_instructor questions append value {id:124,question:"编著《本草纲目》的是？",A:"李时珍",B:"华佗",C:"张仲景",answer:1}

# 题目125
data modify storage quiz:iron_instructor questions append value {id:125,question:"发明浑天仪的是？",A:"张衡",B:"祖冲之",C:"沈括",answer:1}

# 题目126
data modify storage quiz:iron_instructor questions append value {id:126,question:"计算出圆周率的是？",A:"祖冲之",B:"张衡",C:"刘徽",answer:1}

# 题目127
data modify storage quiz:iron_instructor questions append value {id:127,question:"被称为'建安七子'之首的是？",A:"王粲",B:"曹植",C:"孔融",answer:1}

# 题目128
data modify storage quiz:iron_instructor questions append value {id:128,question:"'竹林七贤'中最著名的是？",A:"嵇康",B:"阮籍",C:"刘伶",answer:1}

# 题目129
data modify storage quiz:iron_instructor questions append value {id:129,question:"被称为'初唐四杰'之首的是？",A:"王勃",B:"杨炯",C:"卢照邻",answer:1}

# 题目130
data modify storage quiz:iron_instructor questions append value {id:130,question:"'唐宋八大家'中不包括？",A:"李白",B:"韩愈",C:"苏轼",answer:1}

# === 更多古诗词接龙 ===
# 题目131
data modify storage quiz:iron_instructor questions append value {id:131,question:"'两岸猿声啼不住'的下一句是？",A:"轻舟已过万重山",B:"千里江陵一日还",C:"孤帆一片日边来",answer:1}

# 题目132
data modify storage quiz:iron_instructor questions append value {id:132,question:"'孤帆远影碧空尽'的下一句是？",A:"唯见长江天际流",B:"烟波江上使人愁",C:"万里长江滚滚来",answer:1}

# 题目133
data modify storage quiz:iron_instructor questions append value {id:133,question:"'劝君更尽一杯酒'的下一句是？",A:"西出阳关无故人",B:"莫使金樽空对月",C:"人生得意须尽欢",answer:1}

# 题目134
data modify storage quiz:iron_instructor questions append value {id:134,question:"'葡萄美酒夜光杯'的下一句是？",A:"欲饮琵琶马上催",B:"醉卧沙场君莫笑",C:"古来征战几人回",answer:1}

# 题目135
data modify storage quiz:iron_instructor questions append value {id:135,question:"'洛阳亲友如相问'的下一句是？",A:"一片冰心在玉壶",B:"寒雨连江夜入吴",C:"平明送客楚山孤",answer:1}

# 题目136
data modify storage quiz:iron_instructor questions append value {id:136,question:"'不知细叶谁裁出'的下一句是？",A:"二月春风似剪刀",B:"吹面不寒杨柳风",C:"春风又绿江南岸",answer:1}

# 题目137
data modify storage quiz:iron_instructor questions append value {id:137,question:"'少小离家老大回'的下一句是？",A:"乡音无改鬓毛衰",B:"儿童相见不相识",C:"笑问客从何处来",answer:1}

# 题目138
data modify storage quiz:iron_instructor questions append value {id:138,question:"'儿童相见不相识'的下一句是？",A:"笑问客从何处来",B:"乡音无改鬓毛衰",C:"少小离家老大回",answer:1}

# 题目139
data modify storage quiz:iron_instructor questions append value {id:139,question:"'月落乌啼霜满天'的下一句是？",A:"江枫渔火对愁眠",B:"姑苏城外寒山寺",C:"夜半钟声到客船",answer:1}

# 题目140
data modify storage quiz:iron_instructor questions append value {id:140,question:"'姑苏城外寒山寺'的下一句是？",A:"夜半钟声到客船",B:"江枫渔火对愁眠",C:"月落乌啼霜满天",answer:1}

# === 节日风俗类 ===
# 题目141
data modify storage quiz:iron_instructor questions append value {id:141,question:"端午节是为了纪念谁？",A:"屈原",B:"伍子胥",C:"介子推",answer:1}

# 题目142
data modify storage quiz:iron_instructor questions append value {id:142,question:"中秋节吃月饼最初是为了？",A:"推翻元朝",B:"庆祝丰收",C:"祭拜月神",answer:1}

# 题目143
data modify storage quiz:iron_instructor questions append value {id:143,question:"清明节最初是为了纪念谁？",A:"介子推",B:"屈原",C:"伍子胥",answer:1}

# 题目144
data modify storage quiz:iron_instructor questions append value {id:144,question:"重阳节又叫？",A:"登高节",B:"赏菊节",C:"敬老节",answer:1}

# 题目145
data modify storage quiz:iron_instructor questions append value {id:145,question:"七夕节又叫？",A:"乞巧节",B:"情人节",C:"女儿节",answer:1}

# 题目146
data modify storage quiz:iron_instructor questions append value {id:146,question:"元宵节又叫？",A:"上元节",B:"灯节",C:"团圆节",answer:1}

# 题目147
data modify storage quiz:iron_instructor questions append value {id:147,question:"冬至又叫？",A:"一阳生",B:"小年",C:"数九",answer:1}

# 题目148
data modify storage quiz:iron_instructor questions append value {id:148,question:"腊月二十三是？",A:"小年",B:"祭灶",C:"扫尘日",answer:1}

# 题目149
data modify storage quiz:iron_instructor questions append value {id:149,question:"正月十五是？",A:"元宵节",B:"上元节",C:"灯节",answer:1}

# 题目150
data modify storage quiz:iron_instructor questions append value {id:150,question:"农历五月初五是？",A:"端午节",B:"龙舟节",C:"诗人节",answer:1}

# === 地理常识类 ===
# 题目151
data modify storage quiz:iron_instructor questions append value {id:151,question:"长江是中国第几长河？",A:"第一",B:"第二",C:"第三",answer:1}

# 题目152
data modify storage quiz:iron_instructor questions append value {id:152,question:"黄河是中国第几长河？",A:"第二",B:"第一",C:"第三",answer:1}

# 题目153
data modify storage quiz:iron_instructor questions append value {id:153,question:"中国最大的岛屿是？",A:"台湾岛",B:"海南岛",C:"崇明岛",answer:1}

# 题目154
data modify storage quiz:iron_instructor questions append value {id:154,question:"中国最大的湖泊是？",A:"青海湖",B:"鄱阳湖",C:"洞庭湖",answer:1}

# 题目155
data modify storage quiz:iron_instructor questions append value {id:155,question:"中国最长的城墙是？",A:"长城",B:"西安城墙",C:"南京城墙",answer:1}

# 题目156
data modify storage quiz:iron_instructor questions append value {id:156,question:"'五岳'之首是？",A:"泰山",B:"华山",C:"黄山",answer:1}

# 题目157
data modify storage quiz:iron_instructor questions append value {id:157,question:"'五岳'中的'西岳'是？",A:"华山",B:"泰山",C:"恒山",answer:1}

# 题目158
data modify storage quiz:iron_instructor questions append value {id:158,question:"'五岳'中的'东岳'是？",A:"泰山",B:"华山",C:"衡山",answer:1}

# 题目159
data modify storage quiz:iron_instructor questions append value {id:159,question:"'五岳'中的'南岳'是？",A:"衡山",B:"泰山",C:"华山",answer:1}

# 题目160
data modify storage quiz:iron_instructor questions append value {id:160,question:"'五岳'中的'北岳'是？",A:"恒山",B:"泰山",C:"华山",answer:1}

# === 更多成语接龙类 ===
# 题目161
data modify storage quiz:iron_instructor questions append value {id:161,question:"'画蛇添足'的主人公是？",A:"楚国人",B:"齐国人",C:"晋国人",answer:1}

# 题目162
data modify storage quiz:iron_instructor questions append value {id:162,question:"'守株待兔'的主人公是？",A:"宋国人",B:"楚国人",C:"齐国人",answer:1}

# 题目163
data modify storage quiz:iron_instructor questions append value {id:163,question:"'刻舟求剑'的主人公是？",A:"楚国人",B:"宋国人",C:"齐国人",answer:1}

# 题目164
data modify storage quiz:iron_instructor questions append value {id:164,question:"'叶公好龙'的主人公是？",A:"叶公",B:"公输班",C:"鲁班",answer:1}

# 题目165
data modify storage quiz:iron_instructor questions append value {id:165,question:"'班门弄斧'中的'班'指的是？",A:"鲁班",B:"班超",C:"班固",answer:1}

# 题目166
data modify storage quiz:iron_instructor questions append value {id:166,question:"'胸有成竹'的主人公是？",A:"文同",B:"郑板桥",C:"苏轼",answer:1}

# 题目167
data modify storage quiz:iron_instructor questions append value {id:167,question:"'高山流水'说的是谁的故事？",A:"伯牙与钟子期",B:"管仲与鲍叔牙",C:"廉颇与蔺相如",answer:1}

# 题目168
data modify storage quiz:iron_instructor questions append value {id:168,question:"'管鲍之交'说的是谁的故事？",A:"管仲与鲍叔牙",B:"伯牙与钟子期",C:"孔子与颜回",answer:1}

# 题目169
data modify storage quiz:iron_instructor questions append value {id:169,question:"'桃李满天下'最初指的是谁？",A:"狄仁杰",B:"孔子",C:"韩愈",answer:1}

# 题目170
data modify storage quiz:iron_instructor questions append value {id:170,question:"'洛阳纸贵'是因为哪篇文章？",A:"《三都赋》",B:"《洛神赋》",C:"《阿房宫赋》",answer:1}

# === 数字成语类 ===
# 题目171
data modify storage quiz:iron_instructor questions append value {id:171,question:"'一诺千金'的主人公是？",A:"季布",B:"曹操",C:"刘备",answer:1}

# 题目172
data modify storage quiz:iron_instructor questions append value {id:172,question:"'一鸣惊人'的主人公是？",A:"楚庄王",B:"齐桓公",C:"晋文公",answer:1}

# 题目173
data modify storage quiz:iron_instructor questions append value {id:173,question:"'一字千金'的主人公是？",A:"吕不韦",B:"秦始皇",C:"李斯",answer:1}

# 题目174
data modify storage quiz:iron_instructor questions append value {id:174,question:"'三顾茅庐'中刘备去了几次？",A:"三次",B:"两次",C:"四次",answer:1}

# 题目175
data modify storage quiz:iron_instructor questions append value {id:175,question:"'四面楚歌'中的楚指的是？",A:"项羽",B:"刘邦",C:"楚怀王",answer:1}

# 题目176
data modify storage quiz:iron_instructor questions append value {id:176,question:"'五十步笑百步'出自？",A:"《孟子》",B:"《论语》",C:"《庄子》",answer:1}

# 题目177
data modify storage quiz:iron_instructor questions append value {id:177,question:"'百步穿杨'的主人公是？",A:"养由基",B:"后羿",C:"纪昌",answer:1}

# 题目178
data modify storage quiz:iron_instructor questions append value {id:178,question:"'千金买骨'是为了？",A:"招贤纳士",B:"收藏文物",C:"炫耀财富",answer:1}

# 题目179
data modify storage quiz:iron_instructor questions append value {id:179,question:"'万事俱备，只欠东风'出自？",A:"《三国演义》",B:"《水浒传》",C:"《西游记》",answer:1}

# 题目180
data modify storage quiz:iron_instructor questions append value {id:180,question:"'十年树木，百年树人'最早出自？",A:"《管子》",B:"《论语》",C:"《孟子》",answer:1}

# === 动物成语类 ===
# 题目181
data modify storage quiz:iron_instructor questions append value {id:181,question:"'鹤立鸡群'形容的是？",A:"才能出众",B:"身材高大",C:"孤独无助",answer:1}

# 题目182
data modify storage quiz:iron_instructor questions append value {id:182,question:"'鱼目混珠'中的'珠'指的是？",A:"珍珠",B:"玉石",C:"宝石",answer:1}

# 题目183
data modify storage quiz:iron_instructor questions append value {id:183,question:"'狐假虎威'中狐狸借的是谁的威风？",A:"老虎",B:"狮子",C:"狼",answer:1}

# 题目184
data modify storage quiz:iron_instructor questions append value {id:184,question:"'龙飞凤舞'最初形容的是？",A:"书法笔势",B:"舞蹈动作",C:"山川景色",answer:1}

# 题目185
data modify storage quiz:iron_instructor questions append value {id:185,question:"'鸡犬不宁'形容的是？",A:"非常混乱",B:"非常安静",C:"非常热闹",answer:1}

# 题目186
data modify storage quiz:iron_instructor questions append value {id:186,question:"'对牛弹琴'讽刺的是？",A:"说话不看对象",B:"音乐水平差",C:"牛很笨",answer:1}

# 题目187
data modify storage quiz:iron_instructor questions append value {id:187,question:"'亡羊补牢'的下一句是？",A:"未为晚也",B:"为时已晚",C:"犹未晚矣",answer:1}

# 题目188
data modify storage quiz:iron_instructor questions append value {id:188,question:"'马到成功'最初用于？",A:"战争",B:"科举",C:"经商",answer:1}

# 题目189
data modify storage quiz:iron_instructor questions append value {id:189,question:"'兔死狗烹'出自？",A:"《史记》",B:"《战国策》",C:"《左传》",answer:1}

# 题目190
data modify storage quiz:iron_instructor questions append value {id:190,question:"'鹬蚌相争'的下一句是？",A:"渔翁得利",B:"两败俱伤",C:"坐山观虎斗",answer:1}

# === 最后10题综合类 ===
# 题目191
data modify storage quiz:iron_instructor questions append value {id:191,question:"中国古代'科举制度'始于哪个朝代？",A:"隋朝",B:"唐朝",C:"宋朝",answer:1}

# 题目192
data modify storage quiz:iron_instructor questions append value {id:192,question:"'丝绸之路'最早开辟于哪个朝代？",A:"汉朝",B:"唐朝",C:"秦朝",answer:1}

# 题目193
data modify storage quiz:iron_instructor questions append value {id:193,question:"中国第一部纪传体通史是？",A:"《史记》",B:"《汉书》",C:"《资治通鉴》",answer:1}

# 题目194
data modify storage quiz:iron_instructor questions append value {id:194,question:"中国第一部诗歌总集是？",A:"《诗经》",B:"《楚辞》",C:"《唐诗三百首》",answer:1}

# 题目195
data modify storage quiz:iron_instructor questions append value {id:195,question:"'春秋'是哪个国家的编年史？",A:"鲁国",B:"齐国",C:"晋国",answer:1}

# 题目196
data modify storage quiz:iron_instructor questions append value {id:196,question:"被称为'万园之园'的是？",A:"圆明园",B:"颐和园",C:"承德避暑山庄",answer:1}

# 题目197
data modify storage quiz:iron_instructor questions append value {id:197,question:"中国现存最早的编年体史书是？",A:"《春秋》",B:"《左传》",C:"《史记》",answer:1}

# 题目198
data modify storage quiz:iron_instructor questions append value {id:198,question:"'楷书四大家'不包括？",A:"王羲之",B:"欧阳询",C:"颜真卿",answer:1}

# 题目199
data modify storage quiz:iron_instructor questions append value {id:199,question:"被誉为'天下第一行书'的是？",A:"《兰亭序》",B:"《祭侄文稿》",C:"《黄州寒食帖》",answer:1}

# 题目200
data modify storage quiz:iron_instructor questions append value {id:200,question:"中国古代'六部'不包括？",A:"农部",B:"吏部",C:"户部",answer:1}

say [题库] 已加载200道题目（完整版）
