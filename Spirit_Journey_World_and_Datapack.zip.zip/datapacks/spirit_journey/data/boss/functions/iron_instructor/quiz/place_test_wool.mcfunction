# ==========================================
# 铁面教官 - 放置测试羊毛
# 在玩家周围放置红、蓝、黄羊毛用于测试
# ==========================================

# 在玩家前方放置三块羊毛
execute as @p at @s run setblock ~-1 ~ ~2 red_wool
execute as @p at @s run setblock ~ ~ ~2 blue_wool
execute as @p at @s run setblock ~1 ~ ~2 yellow_wool

tellraw @a {"text":"[测试] 已在你前方放置测试羊毛：红(A) 蓝(B) 黄(C)","color":"green"}
