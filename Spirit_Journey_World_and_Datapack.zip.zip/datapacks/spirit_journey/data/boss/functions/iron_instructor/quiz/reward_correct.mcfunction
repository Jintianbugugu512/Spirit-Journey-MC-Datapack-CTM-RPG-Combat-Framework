# ==========================================
# 铁面教官 - 答对奖励
# 玩家答对后的奖励
# ==========================================

# 提示信息
tellraw @s {"text":"[答题系统] ✓ 回答正确！获得【知识的力量】buff！","color":"green","bold":true}
playsound entity.player.levelup master @s ~ ~ ~ 1 2
particle happy_villager ~ ~1 ~ 0.5 0.5 0.5 0.1 20 force

# 给予"知识的力量"buff（10秒 = 200 tick）
scoreboard players set @s knowledge_power 200
title @s actionbar {"text":"✦ 知识的力量 ✦ 攻击力+50","color":"gold","bold":true}

# 暂时用say代替buff效果
say [知识的力量] @s 获得了知识的力量buff！攻击力+50 持续10秒
