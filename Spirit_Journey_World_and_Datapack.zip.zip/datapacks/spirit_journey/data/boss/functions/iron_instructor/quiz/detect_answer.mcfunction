# ==========================================
# 铁面教官 - 答题检测（每tick执行）
# 检测玩家脚下的羊毛方块，允许随时切换选项
# ==========================================

# 检测红色羊毛（A选项）
execute as @a at @s if block ~ ~-1 ~ red_wool unless score @s quiz_answer matches 1 run scoreboard players set @s quiz_answer 1
execute as @a at @s if block ~ ~-1 ~ red_wool unless score @s quiz_answered matches 1 run scoreboard players set @s quiz_answered 1
execute as @a at @s if block ~ ~-1 ~ red_wool unless score @s quiz_answered matches 1 run tellraw @s {"text":"[答题系统] 你选择了 A","color":"green"}
execute as @a at @s if block ~ ~-1 ~ red_wool unless score @s quiz_answered matches 1 run playsound block.note_block.pling master @s ~ ~ ~ 1 2

# 检测蓝色羊毛（B选项）
execute as @a at @s if block ~ ~-1 ~ blue_wool unless score @s quiz_answer matches 2 run scoreboard players set @s quiz_answer 2
execute as @a at @s if block ~ ~-1 ~ blue_wool unless score @s quiz_answered matches 1 run scoreboard players set @s quiz_answered 1
execute as @a at @s if block ~ ~-1 ~ blue_wool unless score @s quiz_answered matches 1 run tellraw @s {"text":"[答题系统] 你选择了 B","color":"green"}
execute as @a at @s if block ~ ~-1 ~ blue_wool unless score @s quiz_answered matches 1 run playsound block.note_block.pling master @s ~ ~ ~ 1 2

# 检测黄色羊毛（C选项）
execute as @a at @s if block ~ ~-1 ~ yellow_wool unless score @s quiz_answer matches 3 run scoreboard players set @s quiz_answer 3
execute as @a at @s if block ~ ~-1 ~ yellow_wool unless score @s quiz_answered matches 1 run scoreboard players set @s quiz_answered 1
execute as @a at @s if block ~ ~-1 ~ yellow_wool unless score @s quiz_answered matches 1 run tellraw @s {"text":"[答题系统] 你选择了 C","color":"green"}
execute as @a at @s if block ~ ~-1 ~ yellow_wool unless score @s quiz_answered matches 1 run playsound block.note_block.pling master @s ~ ~ ~ 1 2

# 如果切换选项，提示已更改
execute as @a at @s if block ~ ~-1 ~ red_wool if score @s quiz_answer matches 2..3 if score @s quiz_answered matches 1 run tellraw @s {"text":"[答题系统] 已切换到 A","color":"yellow"}
execute as @a at @s if block ~ ~-1 ~ red_wool if score @s quiz_answer matches 2..3 if score @s quiz_answered matches 1 run playsound block.note_block.hat master @s ~ ~ ~ 1 1.5

execute as @a at @s if block ~ ~-1 ~ blue_wool if score @s quiz_answer matches 1 if score @s quiz_answered matches 1 run tellraw @s {"text":"[答题系统] 已切换到 B","color":"yellow"}
execute as @a at @s if block ~ ~-1 ~ blue_wool if score @s quiz_answer matches 3 if score @s quiz_answered matches 1 run tellraw @s {"text":"[答题系统] 已切换到 B","color":"yellow"}
execute as @a at @s if block ~ ~-1 ~ blue_wool unless score @s quiz_answer matches 2 if score @s quiz_answered matches 1 run playsound block.note_block.hat master @s ~ ~ ~ 1 1.5

execute as @a at @s if block ~ ~-1 ~ yellow_wool if score @s quiz_answer matches 1..2 if score @s quiz_answered matches 1 run tellraw @s {"text":"[答题系统] 已切换到 C","color":"yellow"}
execute as @a at @s if block ~ ~-1 ~ yellow_wool if score @s quiz_answer matches 1..2 if score @s quiz_answered matches 1 run playsound block.note_block.hat master @s ~ ~ ~ 1 1.5

# 更新选项值（允许切换）
execute as @a at @s if block ~ ~-1 ~ red_wool run scoreboard players set @s quiz_answer 1
execute as @a at @s if block ~ ~-1 ~ blue_wool run scoreboard players set @s quiz_answer 2
execute as @a at @s if block ~ ~-1 ~ yellow_wool run scoreboard players set @s quiz_answer 3

# 离开羊毛区域清空状态（可选，如果不想要这个功能可以删除）
# execute as @a at @s unless block ~ ~-1 ~ red_wool unless block ~ ~-1 ~ blue_wool unless block ~ ~-1 ~ yellow_wool if score @s quiz_answered matches 1 run scoreboard players set @s quiz_answered 0
# execute as @a at @s unless block ~ ~-1 ~ red_wool unless block ~ ~-1 ~ blue_wool unless block ~ ~-1 ~ yellow_wool if score @s quiz_answered matches 0 run scoreboard players set @s quiz_answer 0
