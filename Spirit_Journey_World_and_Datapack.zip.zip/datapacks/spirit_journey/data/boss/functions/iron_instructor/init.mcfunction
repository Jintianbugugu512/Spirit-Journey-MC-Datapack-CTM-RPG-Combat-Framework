# 铁面教官BOSS - 初始化
# 召唤BOSS实体并设置初始状态

# 召唤铁傀儡作为BOSS实体（坐标：-651 100 1020，面朝x轴负方向，无AI）
summon iron_golem -651 100 1020 {Tags:["iron_instructor","boss","enemy","new_boss"],CustomName:'{"text":"铁面教官","color":"gray","bold":true}',CustomNameVisible:1b,Rotation:[90f,0f],NoAI:1b}

# 初始化记分板
scoreboard players set @e[tag=new_boss] phase 1
scoreboard players set @e[tag=new_boss] skill 0
scoreboard players set @e[tag=new_boss] timer 200
scoreboard players set @e[tag=new_boss] max_health 1500
scoreboard players set @e[tag=new_boss] current_health 1500

# 设置防御属性
scoreboard players set @e[tag=new_boss] physical_armor 30
scoreboard players set @e[tag=new_boss] magic_resist 5

# 设置其他属性
scoreboard players set @e[tag=new_boss] hit_cooldown 0
scoreboard players set @e[tag=new_boss] temp 0
execute as @e[tag=new_boss] run attribute @s generic.knockback_resistance base set 1.0

# 初始化常量（用于随机数计算）
scoreboard players set #5 temp 5

# 加入红队
team join red @e[tag=new_boss]

# 给予效果
effect give @e[tag=new_boss] fire_resistance infinite 4 true
effect give @e[tag=new_boss] regeneration infinite 0 true

# 移除初始化标签
tag @e[tag=new_boss] remove new_boss

# 初始化答题系统
function boss:iron_instructor/quiz/init_questions
scoreboard players set #quiz_active temp 0

say [系统] 铁面教官已召唤于 -651 100 1020
