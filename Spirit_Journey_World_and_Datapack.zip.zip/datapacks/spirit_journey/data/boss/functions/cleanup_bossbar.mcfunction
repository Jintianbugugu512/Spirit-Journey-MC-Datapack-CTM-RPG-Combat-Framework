# ==========================================
# Boss血条清理系统
# 全局执行，不依赖Boss实体加载状态
# 当玩家远离Boss战斗区域时，自动清空血条
# ==========================================

# 紫晶核心 - 如果战斗区域50格内没有玩家，清空血条
execute unless entity @a[x=-1013,y=100,z=1013,distance=..50] run bossbar set amethyst_core players

# 水滴骑士 - 如果战斗区域50格内没有玩家，清空血条
execute unless entity @a[x=-824,y=100,z=1002,distance=..50] run bossbar set water_knight players

# 铁面教官 - 如果战斗区域50格内没有玩家，清空血条
execute unless entity @a[x=-651,y=100,z=1020,distance=..50] run bossbar set iron_instructor players
