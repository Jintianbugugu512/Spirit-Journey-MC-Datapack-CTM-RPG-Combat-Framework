# ==========================================
# 召唤精英 - 钢铁战士（高物抗）
# ==========================================

summon minecraft:zombie ~ ~1 ~ {\
CustomName:"[\"§7§l[精英] §8钢铁战士\"]",\
CustomNameVisible:1b,\
Health:1023.5f,\
Tags:["enemy","elite","iron_warrior","summon"],\
Attributes:[\
{Base:1023.5,Name:"generic.max_health"},\
{Base:-3d,Name:"generic.attack_damage"},\
{Base:-99d,Name:"generic.armor"},\
{Base:-99d,Name:"generic.armor_toughness"},\
{Base:0.2d,Name:"generic.movement_speed"}\
],\
ArmorItems:[\
{id:"minecraft:netherite_boots",Count:1b},\
{id:"minecraft:netherite_leggings",Count:1b},\
{id:"minecraft:netherite_chestplate",Count:1b},\
{id:"minecraft:netherite_helmet",Count:1b}\
],\
HandItems:[\
{id:"minecraft:netherite_sword",Count:1b,tag:{Enchantments:[{id:"sharpness",lvl:2}]}},\
{id:"minecraft:shield",Count:1b,tag:{BlockEntityTag:{Base:7}}}\
],\
CanBreakDoors:true,\
IsBaby:0b\
}

# 设置属性
scoreboard players set @e[tag=summon] max_health 300
scoreboard players set @e[tag=summon] current_health 300
scoreboard players set @e[tag=summon] physical_armor 40
scoreboard players set @e[tag=summon] magic_resist 5

# 初始化血量和护甲类型
scoreboard players operation @e[tag=summon,limit=1] last_health = @e[tag=summon,limit=1] max_health
execute as @e[tag=summon,limit=1] run function combat:healthbar/calculate_armor_type
scoreboard players set @e[tag=summon] hit_cooldown 0

# 击退抗性（90%）
execute as @e[tag=summon] run attribute @s generic.knockback_resistance base set 0.9
execute store result score @s knock_resistance run attribute @s generic.knockback_resistance get 10

# 加入红队
team join red @e[tag=summon]

# 给予效果
effect give @e[tag=summon] minecraft:resistance 1 4 true
effect give @e[tag=summon] fire_resistance infinite 4 true
effect give @e[tag=summon] slowness infinite 0 true

# 特殊标记（可选，用于后续添加特殊行为）
tag @e[tag=summon] add heavy_armor

# 清除临时标签
tag @e[tag=summon] remove summon
