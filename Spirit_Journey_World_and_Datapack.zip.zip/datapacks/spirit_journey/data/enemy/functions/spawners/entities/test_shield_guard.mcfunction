# 召唤测试盾卫

summon minecraft:husk ~ ~1 ~ {CustomName:"[\"§6测试盾卫\"]",ArmorItems:[{},{},{id:"minecraft:golden_chestplate",Count:1b,Damage:0s,tag:{AttributeModifiers:[{AttributeName:"generic.attack_damage",Name:"noName",Amount:0d,Operation:0,UUID:[I;7661,6511,5512,8218],Slot:mainhand}]}},{}],CustomNameVisible:1b,Health:1023.5f,Tags:["enemy","Desert_guard","summon"],Attributes:[{Base:1024,Name:"generic.max_health"},{Base:1d,Name:"generic.attack_damage"},{Base:-99d,Name:"generic.armor"},{Base:-99d,Name:"generic.armor_toughness"}],CanBreakDoors:false,HandItems:[{id:"minecraft:shield",Count:1b,Damage:0s,tag:{AttributeModifiers:[{AttributeName:"generic.attack_damage",Name:"noName",Amount:0d,Operation:0,UUID:[I;7661,6511,5512,8218],Slot:mainhand}]}},{id:"minecraft:shield",Count:1b,Damage:0s,tag:{AttributeModifiers:[{AttributeName:"generic.attack_damage",Name:"noName",Amount:0d,Operation:0,UUID:[I;7661,6511,5512,8218],Slot:mainhand}]}}]}

# 设置属性
scoreboard players set @e[tag=summon] max_health 200
scoreboard players set @e[tag=summon] current_health 200
scoreboard players set @e[tag=summon] physical_armor 10
scoreboard players set @e[tag=summon] magic_resist 0

scoreboard players operation @e[tag=summon,limit=1] last_health = @e[tag=summon,limit=1] max_health
execute as @e[tag=summon,limit=1] run function combat:healthbar/calculate_armor_type
scoreboard players set @e[tag=summon] hit_cooldown 0

execute as @e[tag=summon] run attribute @s generic.knockback_resistance base set 0.7
execute store result score @s knock_resistance run attribute @s generic.knockback_resistance get 10

team join red @e[tag=summon]

effect give @e[tag=summon] minecraft:resistance 1 4 true
effect give @e[tag=summon] fire_resistance infinite 4 true

tag @e remove summon
