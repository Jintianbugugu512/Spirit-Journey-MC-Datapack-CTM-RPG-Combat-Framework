# ==========================================
# 召唤精英 - 紫晶守卫（高魔抗）
# ==========================================

summon minecraft:wither_skeleton ~ ~1 ~ {\
CustomName:"[\"§5§l[精英] §d紫晶守卫\"]",\
CustomNameVisible:1b,\
Health:1023.5f,\
Tags:["enemy","elite","crystal_guard","summon"],\
Attributes:[\
{Base:1023.5,Name:"generic.max_health"},\
{Base:-3d,Name:"generic.attack_damage"},\
{Base:-99d,Name:"generic.armor"},\
{Base:-99d,Name:"generic.armor_toughness"},\
{Base:0.28d,Name:"generic.movement_speed"}\
],\
ArmorItems:[\
{},\
{},\
{id:"minecraft:diamond_chestplate",Count:1b,tag:{Enchantments:[{id:"protection",lvl:1}]}},\
{}\
],\
HandItems:[\
{id:"minecraft:amethyst_shard",Count:1b},\
{id:"minecraft:amethyst_shard",Count:1b}\
],\
CanBreakDoors:false\
}

# 设置属性
scoreboard players set @e[tag=summon] max_health 250
scoreboard players set @e[tag=summon] current_health 250
scoreboard players set @e[tag=summon] physical_armor 10
scoreboard players set @e[tag=summon] magic_resist 30

# 初始化血量和护甲类型
scoreboard players operation @e[tag=summon,limit=1] last_health = @e[tag=summon,limit=1] max_health
execute as @e[tag=summon,limit=1] run function combat:healthbar/calculate_armor_type
scoreboard players set @e[tag=summon] hit_cooldown 0

# 击退抗性（60%）
execute as @e[tag=summon] run attribute @s generic.knockback_resistance base set 0.6
execute store result score @s knock_resistance run attribute @s generic.knockback_resistance get 10

# 加入红队
team join red @e[tag=summon]

# 给予效果
effect give @e[tag=summon] minecraft:resistance 1 4 true
effect give @e[tag=summon] fire_resistance infinite 4 true
effect give @e[tag=summon] speed infinite 0 true

# 特殊粒子效果标记（可选，用于后续添加粒子效果）
tag @e[tag=summon] add purple_aura

# 清除临时标签
tag @e[tag=summon] remove summon
