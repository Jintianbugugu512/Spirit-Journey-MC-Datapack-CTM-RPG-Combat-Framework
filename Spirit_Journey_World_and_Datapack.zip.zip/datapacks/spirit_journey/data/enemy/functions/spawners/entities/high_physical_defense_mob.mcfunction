# 召唤高物防小怪

summon minecraft:zombie ~ ~1 ~ {CustomName:"[\"§7高物防小怪\"]",ArmorItems:[{},{},{id:"minecraft:iron_chestplate",Count:1b,Damage:0s,tag:{AttributeModifiers:[{AttributeName:"generic.attack_damage",Name:"noName",Amount:0d,Operation:0,UUID:[I;7661,6511,5512,8218],Slot:mainhand}]}},{}],CustomNameVisible:1b,Health:1023.5f,Tags:["enemy","high_defense_mob","summon"],Attributes:[{Base:1023.5,Name:"generic.max_health"},{Base:-3d,Name:"generic.attack_damage"},{Base:-99d,Name:"generic.armor"},{Base:-99d,Name:"generic.armor_toughness"}],CanBreakDoors:false,HandItems:[{id:"minecraft:iron_sword",Count:1b,Damage:0s,tag:{AttributeModifiers:[{AttributeName:"generic.attack_damage",Name:"noName",Amount:0d,Operation:0,UUID:[I;7661,6511,5512,8218],Slot:mainhand}]}},{}]}

# 设置属性
scoreboard players set @e[tag=summon] max_health 100
scoreboard players set @e[tag=summon] current_health 100
scoreboard players set @e[tag=summon] physical_armor 20
scoreboard players set @e[tag=summon] magic_resist 5

scoreboard players operation @e[tag=summon,limit=1] last_health = @e[tag=summon,limit=1] max_health
execute as @e[tag=summon,limit=1] run function combat:healthbar/calculate_armor_type
scoreboard players set @e[tag=summon] hit_cooldown 0

execute as @e[tag=summon] run attribute @s generic.knockback_resistance base set 0.8
execute store result score @s knock_resistance run attribute @s generic.knockback_resistance get 10
team join red @e[tag=summon]

effect give @e[tag=summon] minecraft:resistance 1 4 true
effect give @e[tag=summon] fire_resistance infinite 4 true

tag @e remove summon
