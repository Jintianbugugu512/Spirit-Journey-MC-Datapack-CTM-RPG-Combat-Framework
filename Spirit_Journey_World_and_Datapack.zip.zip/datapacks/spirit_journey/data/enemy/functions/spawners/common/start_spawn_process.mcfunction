# ==========================================
# 刷怪笼系统 - 开始召唤流程 (宏函数) ⭐v2.0
# ==========================================
# 功能: 当刷怪间隔达到目标时，初始化召唤流程
# 类型: 宏函数 (需要传递参数)
# 调用: 由 spawner_tick.mcfunction 调用（当 spawn_Interval >= interval 时）
#
# 参数:
#   - summon_entity: 实体生成函数路径
#   - range_x: X轴随机范围
#   - range_y: Y轴随机范围
#   - range_z: Z轴随机范围
#
# 工作流程:
#   1. 将参数存储到 storage enemy:spawner（供后续函数使用）
#   2. 重置重试计数器（spawn_retry_count = 0）
#   3. 调用 generate_random_position 生成随机位置并开始召唤
#   4. 重置刷怪间隔计数器（spawn_Interval = 0）
#
# ==========================================


# 将参数存储到 storage enemy:spawner
$data modify storage enemy:spawner summon_entity set value "$(summon_entity)"
$data modify storage enemy:spawner range_x set value "$(range_x)"
$data modify storage enemy:spawner range_y set value "$(range_y)"
$data modify storage enemy:spawner range_z set value "$(range_z)"

# 重置重试计数器
scoreboard players set @s spawn_retry_count 0

# 生成随机位置并开始召唤
function enemy:spawners/common/generate_random_position with storage enemy:spawner

# 重置刷怪间隔
scoreboard players set @s spawn_Interval 0
