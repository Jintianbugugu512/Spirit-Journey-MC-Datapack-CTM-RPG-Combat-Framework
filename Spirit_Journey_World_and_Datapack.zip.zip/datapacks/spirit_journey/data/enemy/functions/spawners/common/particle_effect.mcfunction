# ==========================================
# 刷怪笼系统 - 动态粒子效果 (宏函数) ⭐v2.0
# ==========================================
# 功能: 根据刷怪进度百分比显示粒子效果（蓝色魂火→红色火焰）
# 类型: 宏函数 (需要传递参数)
# 调用: 由 spawner_tick.mcfunction 调用
#
# 参数:
#   - interval: 刷怪间隔 (用于计算百分比)
#
# 计分板依赖:
#   - @s spawn_Interval: 当前刷怪间隔计数器
#   - @s spawn_progress: 刷怪进度百分比 (0-100，本函数计算)
#   - #100 spawn_progress: 常量100 (用于百分比计算)
#   - #interval spawn_progress: 临时存储interval值
#
# 核心算法:
#   spawn_progress = (spawn_Interval / interval) * 100
#   使用整数运算避免浮点数:
#     1. spawn_progress = spawn_Interval
#     2. spawn_progress *= 100
#     3. spawn_progress /= interval
#
# 粒子阶段:
#   进度       粒子效果        数量  说明
#   ----------------------------------------
#   0-9%      无粒子           0    刚重置
#   10-16%    蓝色魂火         1    开始充能
#   17-33%    蓝色魂火         2    早期充能
#   34-49%    蓝色魂火         3    接近一半
#   50-66%    蓝色魂火         4    过半进度
#   67-96%    蓝色魂火         5    即将完成
#   97-100%   红色火焰         5    即将刷怪！
#
# v2.0 优势:
#   - 完全自适应任意interval值 (100、300、1000都能正确显示)
#   - 直观的视觉反馈，玩家可通过粒子判断刷怪进度
#   - 使用整数运算，性能友好
#
# 自定义:
#   修改百分比阈值可调整粒子节奏
#   例如: 将红色火焰提前到90%触发
#   execute if score @s spawn_progress matches 90.. run particle flame ...
# ==========================================

# 计算百分比：(spawn_Interval / interval) * 100
# 使用临时计分板避免精度损失
scoreboard players operation @s spawn_progress = @s spawn_Interval
scoreboard players set #100 spawn_progress 100
scoreboard players operation @s spawn_progress *= #100 spawn_progress
$scoreboard players set #interval spawn_progress $(interval)
scoreboard players operation @s spawn_progress /= #interval spawn_progress

# 不同阶段有不同的粒子效果
execute if score @s spawn_progress matches 10..16 run particle soul_fire_flame ~ ~ ~ 0.1 0.1 0.1 0.01 1
execute if score @s spawn_progress matches 17..33 run particle soul_fire_flame ~ ~ ~ 0.15 0.15 0.15 0.01 2
execute if score @s spawn_progress matches 34..49 run particle soul_fire_flame ~ ~ ~ 0.2 0.2 0.2 0.02 3
execute if score @s spawn_progress matches 50..66 run particle soul_fire_flame ~ ~ ~ 0.25 0.25 0.25 0.02 4
execute if score @s spawn_progress matches 67..96 run particle soul_fire_flame ~ ~ ~ 0.3 0.3 0.3 0.03 5
execute if score @s spawn_progress matches 97.. run particle flame ~ ~ ~ 0.2 0.2 0.2 0.02 5
