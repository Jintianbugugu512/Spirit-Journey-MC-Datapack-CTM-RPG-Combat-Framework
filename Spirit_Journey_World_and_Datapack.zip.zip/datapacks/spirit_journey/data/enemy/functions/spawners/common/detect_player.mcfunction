# ==========================================
# 刷怪笼系统 - 检测周围玩家数量
# ==========================================
# 功能: 统计刷怪笼周围15格内的玩家数量
# 类型: 工具函数
# 调用: 由 spawner_tick.mcfunction 调用
#
# 输出:
#   - @s player_Numbers: 周围玩家数量 (0, 1, 2, 3+)
#
# 工作原理:
#   使用 execute store result 统计满足条件的玩家实体数量
#   distance=..15 表示以刷怪笼为中心，半径15格的球形范围
#
# 用途:
#   该数据用于 update_interval.mcfunction 动态调整刷怪速率
#   玩家越多，刷怪越快
#
# 自定义:
#   修改 distance=..15 中的数值可调整检测范围
#   例如 distance=..20 表示检测20格范围
# ==========================================

execute store result score @s player_Numbers if entity @a[distance=..15]
