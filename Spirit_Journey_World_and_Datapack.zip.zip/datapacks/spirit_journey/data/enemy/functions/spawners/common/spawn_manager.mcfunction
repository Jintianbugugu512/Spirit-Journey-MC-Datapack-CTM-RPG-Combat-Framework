# ==========================================
# 刷怪笼系统 - 主管理器
# ==========================================
# 功能: 注册所有刷怪笼，统一管理刷怪笼生命周期
# 执行: 每tick在主循环中调用
#
# 工作流程:
#   1. 清理逻辑 - 检测脚下是否有刷怪笼方块，没有则删除display
#   2. 刷怪笼注册 - 调用通用框架函数处理各类刷怪笼
#
# 参数说明:
#   - tag=spawner: 所有刷怪笼的通用标签（在玩家手动召唤display时需要加上）
#   - interval: 刷怪间隔，单位tick (20tick = 1秒)
#   - range_x/y/z: ±格数范围，例如range_x=3表示从-3到+3共7格范围
# 提示:
#   - 如需控制一次性刷怪数量，可在同一位置叠加多个刷怪笼display
# ==========================================

# 清理逻辑：如果脚下不是刷怪笼方块，则清除 display
execute as @e[type=item_display,tag=spawner] at @s unless block ~ ~ ~ minecraft:spawner run kill @s




# ==========================================
# 刷怪笼注册区域
# ==========================================

# 测试剑卫刷怪笼（
execute as @e[type=item_display,tag=test_sword_spawner] at @s run function enemy:spawners/common/spawner_tick {"summon_entity":"enemy:spawners/entities/test_sword_guard","interval":300,"range_x":"3","range_y":"1","range_z":"3"}

# 测试剑卫刷怪笼-快速版
execute as @e[type=item_display,tag=test_sword_spawner_kuai] at @s run function enemy:spawners/common/spawner_tick {"summon_entity":"enemy:spawners/entities/test_sword_guard","interval":100,"range_x":"3","range_y":"1","range_z":"3"}

# 测试盾卫刷怪笼
execute as @e[type=item_display,tag=test_shield_spawner] at @s run function enemy:spawners/common/spawner_tick {"summon_entity":"enemy:spawners/entities/test_shield_guard","interval":300,"range_x":"3","range_y":"1","range_z":"3"}

# 高物防小怪刷怪笼
execute as @e[type=item_display,tag=high_defense_spawner] at @s run function enemy:spawners/common/spawner_tick {"summon_entity":"enemy:spawners/entities/high_physical_defense_mob","interval":300,"range_x":"3","range_y":"1","range_z":"3"}

# 高魔抗小怪刷怪笼
execute as @e[type=item_display,tag=high_magic_resist_spawner] at @s run function enemy:spawners/common/spawner_tick {"summon_entity":"enemy:spawners/entities/high_magic_resist_mob","interval":300,"range_x":"3","range_y":"1","range_z":"3"}

# ==========================================
# 精英刷怪笼注册区域
# ==========================================

# 紫晶守卫刷怪笼（高魔抗精英，30秒间隔）
execute as @e[type=item_display,tag=elite_crystal_spawner] at @s run function enemy:spawners/common/spawner_tick {"summon_entity":"enemy:spawners/entities/elite_crystal_guard","interval":600,"range_x":"4","range_y":"1","range_z":"4"}

# 钢铁战士刷怪笼（高物抗精英，30秒间隔）
execute as @e[type=item_display,tag=elite_iron_spawner] at @s run function enemy:spawners/common/spawner_tick {"summon_entity":"enemy:spawners/entities/elite_iron_warrior","interval":600,"range_x":"4","range_y":"1","range_z":"4"}

# 在此处添加更多刷怪笼...


