# ==========================================
# 刷怪笼系统 - 动态更新刷怪间隔
# ==========================================
# 功能: 根据周围玩家人数动态调整刷怪速率
# 类型: 工具函数
# 调用: 由 spawner_tick.mcfunction 调用
# 前置: 需要先调用 detect_player 检测玩家数量
#
# 计分板依赖:
#   - @s player_Numbers: 周围玩家数量 (由 detect_player 提供)
#   - @s spawn_Interval: 当前刷怪间隔计数器 (本函数修改)
#
# 逻辑规则:
#   1. 30格外无玩家 → spawn_Interval设为290 (快速准备模式)
#   2. 1个玩家 → 每tick +1 (慢速刷怪)
#   3. 2个玩家 → 每tick +2 (中速刷怪)
#   4. 3+个玩家 → 每tick +3 (快速刷怪)
#
# 设计理念:
#   - 玩家越多，刷怪越快，增加挑战性
#   - 玩家远离时快速准备，避免玩家回来时空等
#   - 290是接近刷怪阈值的值(通常interval=300)，确保玩家回来时立即刷怪
#
# 自定义:
#   - 修改 distance=..30 可调整快速准备触发距离
#   - 修改 290 可调整快速准备的间隔值
#   - 修改 +1/+2/+3 可调整不同玩家数量的刷怪速率
#
# 示例:
#   假设 interval=300
#   - 1个玩家: 需要300tick (15秒) 才能刷怪
#   - 2个玩家: 需要150tick (7.5秒) 才能刷怪
#   - 3个玩家: 需要100tick (5秒) 才能刷怪
# ==========================================

# 玩家在15格内时，根据玩家人数决定刷怪速率
execute if entity @s[scores={player_Numbers=1}] run scoreboard players add @s spawn_Interval 1
execute if entity @s[scores={player_Numbers=2}] run scoreboard players add @s spawn_Interval 2
execute if entity @s[scores={player_Numbers=3..}] run scoreboard players add @s spawn_Interval 3

# 玩家不在刷怪笼周围时，停止计时（不增长也不重置）
# 这样玩家离开时刷怪笼会暂停，回来时从暂停处继续
