# ==========================================
# 刷怪笼系统 - 准备坐标数据
# ==========================================
# 功能: 将计分板偏移值转换为 storage 数据（用于宏展开）
# 类型: 工具函数
# 调用: 由 generate_random_position.mcfunction 调用
#
# 输入 (计分板):
#   - @s spawn_offset_x: X轴随机偏移
#   - @s spawn_offset_y: Y轴随机偏移
#   - @s spawn_offset_z: Z轴随机偏移
#
# 输出 (storage enemy:spawner):
#   - offset_x: X轴偏移 (用于宏展开)
#   - offset_y: Y轴偏移 (用于宏展开)
#   - offset_z: Z轴偏移 (用于宏展开)
#
# 工作原理:
#   由于宏函数无法直接读取计分板，需要先将计分板值转存到storage
#   使用 execute store result storage ... int 1 run scoreboard players get
#   这样 do_check_spawn 就能通过宏参数 $(offset_x) 等使用这些值
#
# 为什么需要这一步:
#   计分板 → storage → 宏参数展开
#   这是Minecraft宏函数的技术限制，必须经过storage中转
#
# 调用链:
#   generate_random_position → 本函数 → do_check_spawn
# ==========================================

# 将计分板偏移值存入 storage，用于宏展开
execute store result storage enemy:spawner offset_x int 1 run scoreboard players get @s spawn_offset_x
execute store result storage enemy:spawner offset_y int 1 run scoreboard players get @s spawn_offset_y
execute store result storage enemy:spawner offset_z int 1 run scoreboard players get @s spawn_offset_z

# 调用实际检测函数
function enemy:spawners/common/do_check_spawn with storage enemy:spawner
