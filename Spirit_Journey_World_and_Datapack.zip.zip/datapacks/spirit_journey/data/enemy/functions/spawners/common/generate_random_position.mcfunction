# ==========================================
# 刷怪笼系统 - 随机位置生成器 (宏函数)
# ==========================================
# 功能: 生成刷怪笼周围的随机坐标偏移
# 类型: 宏函数 (需要传递参数)
# 调用: 由 start_spawn_process.mcfunction 或 do_check_spawn.mcfunction (重试时) 调用
#
# 参数 (来自 storage enemy:spawner):
#   - range_x: X轴随机范围 (±格数)
#   - range_y: Y轴随机范围 (±格数)
#   - range_z: Z轴随机范围 (±格数)
#
# 输出 (计分板):
#   - @s spawn_offset_x: X轴随机偏移 (-range_x 到 +range_x)
#   - @s spawn_offset_y: Y轴随机偏移 (-range_y 到 +range_y)
#   - @s spawn_offset_z: Z轴随机偏移 (-range_z 到 +range_z)
#
# 工作原理:
#   使用 random value 命令生成随机整数
#   例如 range_x="3" 会生成 -3、-2、-1、0、1、2、3 中的一个值
#
# 示例:
#   range_x="5", range_y="2", range_z="5"
#   可能生成: offset_x=-3, offset_y=1, offset_z=4
#   表示在刷怪笼西3格、上1格、南4格的位置
#
# 调用链:
#   本函数 → check_spawn_position → do_check_spawn → (成功/重试)
#
# 调试:
#   say generate_random_position - 调试语句，可根据需要注释/取消注释
# ==========================================

# 生成随机偏移量并存入计分板
$execute store result score @s spawn_offset_x run random value -$(range_x)..$(range_x)
$execute store result score @s spawn_offset_y run random value -$(range_y)..$(range_y)
$execute store result score @s spawn_offset_z run random value -$(range_z)..$(range_z)
#say generate_random_position

# 调用检测函数
function enemy:spawners/common/check_spawn_position with storage enemy:spawner
