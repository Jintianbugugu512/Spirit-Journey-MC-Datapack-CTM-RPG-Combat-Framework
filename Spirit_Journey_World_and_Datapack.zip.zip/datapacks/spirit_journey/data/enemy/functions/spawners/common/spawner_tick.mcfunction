# ==========================================
# 刷怪笼系统 - 通用逻辑框架 (宏函数)
# ==========================================
# 功能: 所有刷怪笼的核心逻辑，处理检测→更新→粒子→召唤流程
# 类型: 宏函数 (需要传递参数)
# 调用: 由 spawn_manager.mcfunction 调用
#
# 参数:
#   - summon_entity: 实体生成函数路径 (如 "enemy:spawners/entities/test_sword_guard")
#   - interval: 刷怪间隔，单位tick (如 300 表示15秒)
#   - range_x: X轴随机召唤范围，±格数 (如 "3" 表示-3到+3)
#   - range_y: Y轴随机召唤范围，±格数 (如 "1" 表示-1到+1)
#   - range_z: Z轴随机召唤范围，±格数 (如 "3" 表示-3到+3)
#
# 计分板变量:
#   - spawn_Interval_Max: 最大刷怪间隔 (存储interval值，预留用于扩展)
#   - spawn_Interval: 当前刷怪间隔计数器 (每tick增加，达到interval时触发召唤)
#   - player_Numbers: 周围玩家数量 (由detect_player检测)
#   - spawn_progress: 刷怪进度百分比 (0-100，用于粒子效果)
#
# 工作流程:
#   1. 存储interval到计分板 (用于粒子效果百分比计算)
#   2. 检测玩家数量 (detect_player)
#   3. 根据玩家数量更新间隔 (update_interval)
#   4. 显示动态粒子效果 (particle_effect，基于百分比)
#   5. 达到间隔时开始召唤流程 (start_spawn_process)
#
# ==========================================

# 存储刷怪间隔到计分板（用于粒子效果百分比计算）
$scoreboard players set @s spawn_Interval_Max $(interval)

# 使用通用框架函数
function enemy:spawners/common/detect_player
function enemy:spawners/common/update_interval

# 粒子效果（蓝色火焰 → 红色火焰，基于百分比）
$function enemy:spawners/common/particle_effect {interval:$(interval)}

# 达到刷怪间隔时开始召唤流程
$execute if entity @s[scores={spawn_Interval=$(interval)..}] run function enemy:spawners/common/start_spawn_process {summon_entity:"$(summon_entity)",range_x:"$(range_x)",range_y:"$(range_y)",range_z:"$(range_z)"}

# 未来扩展逻辑位置预留
