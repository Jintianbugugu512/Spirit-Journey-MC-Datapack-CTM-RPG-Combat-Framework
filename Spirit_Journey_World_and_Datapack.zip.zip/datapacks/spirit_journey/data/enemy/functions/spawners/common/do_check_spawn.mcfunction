# ==========================================
# 刷怪笼系统 - 检测位置有效性并召唤 (宏函数)
# ==========================================
# 功能: 检测目标位置是否有效（空气/水），有效则召唤，无效则重试
# 类型: 宏函数 (需要传递参数)
# 调用: 由 check_spawn_position.mcfunction 调用
#
# 参数 (来自 storage enemy:spawner):
#   - offset_x: X轴偏移
#   - offset_y: Y轴偏移
#   - offset_z: Z轴偏移
#   - summon_entity: 要召唤的实体函数
#   - range_x, range_y, range_z: 随机范围（用于重试时传递）
#
# 计分板依赖:
#   - @s spawn_retry_count: 重试次数计数器（本函数修改）
#
# 工作流程:
#   1. 使用宏参数展开检测目标位置方块类型
#      - 如果是空气 → 标记为有效位置
#      - 如果是水 → 标记为有效位置
#   2. 如果位置有效:
#      - 在目标位置调用实体召唤函数
#      - 清除标签，流程结束
#   3. 如果位置无效:
#      - 重试计数器 +1
#      - 如果重试次数 ≤ 20 → 重新调用 generate_random_position
#      - 如果重试次数 > 20 → 放弃召唤，流程结束
#
# 安全机制:
#   最多重试20次，避免在全是固体方块的区域无限循环
#   例如：刷怪笼被完全封闭在石头里，会尝试20次后放弃
#
# 有效位置判断:
#   - 空气方块: 正常召唤位置
#   - 水方块: 允许水生怪物或陆地怪物在水中刷新
#   - 其他方块: 无效，会重试
#
# ==========================================

#say docheckspawn
#$say ~$(offset_x) ~$(offset_y) ~$(offset_z) ----$(summon_entity)

# 计算目标位置并检测方块
$execute positioned ~$(offset_x) ~$(offset_y) ~$(offset_z) if block ~ ~ ~ air run tag @s add valid_spawn_position
$execute positioned ~$(offset_x) ~$(offset_y) ~$(offset_z) if block ~ ~ ~ water run tag @s add valid_spawn_position

# 如果位置有效，召唤实体
$execute if entity @s[tag=valid_spawn_position] positioned ~$(offset_x) ~$(offset_y) ~$(offset_z) run function $(summon_entity)

# 如果位置无效，重新生成（最多尝试20次）
execute if entity @s[tag=!valid_spawn_position] run scoreboard players add @s spawn_retry_count 1
execute if entity @s[tag=!valid_spawn_position,scores={spawn_retry_count=..20}] run say 没有生成成功,再尝试一次!
execute if entity @s[tag=!valid_spawn_position,scores={spawn_retry_count=..20}] run function enemy:spawners/common/generate_random_position with storage enemy:spawner

# 清理标签
tag @s remove valid_spawn_position
