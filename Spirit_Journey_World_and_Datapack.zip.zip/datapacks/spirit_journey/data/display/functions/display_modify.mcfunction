

#修改各轴的大小
data merge entity @s {transformation:{scale:[10f,0.1f,10f]},start_interpolation:0}
#修改位移,仅仅修改显示,
data merge entity @s {transformation:{translation:[2.0f,2.0f,2.0f]},start_interpolation:0}
#修改旋转(四元数形式)
#data merge entity @s {transformation:{left_rotation:[0.0f,0.8f,0.6f,0.0f],right_rotation:[0.0f,0.8f,0.6f,0.0f]},start_interpolation:0}
#修改旋转(角形式)
#data merge entity @s {transformation:{left_rotation:{angle:1.57,axis:[0.0f,1.0f,0.0f]}},start_interpolation:0}
data merge entity @s {interpolation_duration:15}




#整合
#data merge entity @s {transformation:{scale:[10f,0.1f,10f],translation:[2.0f,2.0f,2.0f],},start_interpolation:0,transformation:{left_rotation:{angle:1.57,axis:[0.0f,1.0f,0.0f]}},start_interpolation:0,interpolation_duration:15}













#这个旋转角度适配竖直旋转.
#data merge entity @s {transformation:{left_rotation:{angle:1.57,axis:[0.0f,1.0f,0.0f]}},start_interpolation:0}