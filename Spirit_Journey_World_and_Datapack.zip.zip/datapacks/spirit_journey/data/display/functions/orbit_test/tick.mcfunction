# ==========================================
# 环绕运行tick函数
# 在高频命令方块中调用：/function display:orbit_test/tick
# ==========================================

# 水平环绕（3个钻石）
execute as @e[type=donkey,limit=1] at @s run function display:other/horizontal_orbit {"tag":"h_orbit_1","r":2,"rotate":"1.0f","speed":15}
execute as @e[type=donkey,limit=1] at @s run function display:other/horizontal_orbit {"tag":"h_orbit_2","r":2,"rotate":"120.0f","speed":15}
execute as @e[type=donkey,limit=1] at @s run function display:other/horizontal_orbit {"tag":"h_orbit_3","r":2,"rotate":"240.0f","speed":15}

# 竖直环绕（3个绿宝石）
execute as @e[type=donkey,limit=1] at @s run function display:other/vertical_orbit {"tag":"v_orbit_1","r":2.5,"h":0,"speed":12}
execute as @e[type=donkey,limit=1] at @s run function display:other/vertical_orbit {"tag":"v_orbit_2","r":2.5,"h":0.5,"speed":12}
execute as @e[type=donkey,limit=1] at @s run function display:other/vertical_orbit {"tag":"v_orbit_3","r":2.5,"h":1,"speed":12}
