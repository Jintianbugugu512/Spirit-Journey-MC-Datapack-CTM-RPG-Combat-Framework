# ==========================================
# 清除所有环绕display
# 使用方法：/function display:orbit_test/clear
# ==========================================

# 清除水平环绕
kill @e[tag=h_orbit_1]
kill @e[tag=h_orbit_1_pivot]
kill @e[tag=h_orbit_2]
kill @e[tag=h_orbit_2_pivot]
kill @e[tag=h_orbit_3]
kill @e[tag=h_orbit_3_pivot]

# 清除竖直环绕
kill @e[tag=v_orbit_1]
kill @e[tag=v_orbit_1_pivot]
kill @e[tag=v_orbit_2]
kill @e[tag=v_orbit_2_pivot]
kill @e[tag=v_orbit_3]
kill @e[tag=v_orbit_3_pivot]

tellraw @a [{"text":"[Display] ","color":"yellow"},{"text":"已清除所有环绕display","color":"red"}]
