# ==========================================
# 召唤3个竖直环绕的绿宝石
# 使用方法：/function display:orbit_test/summon_vertical
# ==========================================

execute as @e[type=donkey,limit=1] at @s run summon item_display ~ ~1 ~ {item:{id:"emerald",Count:1b},Tags:["v_orbit_1"],transformation:{scale:[0.5f,0.5f,0.5f]}}
execute as @e[type=donkey,limit=1] at @s run summon item_display ~ ~1 ~ {item:{id:"emerald",Count:1b},Tags:["v_orbit_2"],transformation:{scale:[0.5f,0.5f,0.5f]}}
execute as @e[type=donkey,limit=1] at @s run summon item_display ~ ~1 ~ {item:{id:"emerald",Count:1b},Tags:["v_orbit_3"],transformation:{scale:[0.5f,0.5f,0.5f]}}

tellraw @a [{"text":"[Display] ","color":"yellow"},{"text":"已召唤3个竖直环绕绿宝石","color":"green"}]
