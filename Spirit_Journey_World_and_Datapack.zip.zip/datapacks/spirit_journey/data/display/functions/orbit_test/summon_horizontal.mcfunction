# ==========================================
# 召唤3个水平环绕的钻石
# 使用方法：/function display:orbit_test/summon_horizontal
# ==========================================

execute as @e[type=donkey,limit=1] at @s run summon item_display ~ ~1 ~ {item:{id:"diamond",Count:1b},Tags:["h_orbit_1"],transformation:{scale:[0.5f,0.5f,0.5f]}}
execute as @e[type=donkey,limit=1] at @s run summon item_display ~ ~1 ~ {item:{id:"diamond",Count:1b},Tags:["h_orbit_2"],transformation:{scale:[0.5f,0.5f,0.5f]}}
execute as @e[type=donkey,limit=1] at @s run summon item_display ~ ~1 ~ {item:{id:"diamond",Count:1b},Tags:["h_orbit_3"],transformation:{scale:[0.5f,0.5f,0.5f]}}

tellraw @a [{"text":"[Display] ","color":"yellow"},{"text":"已召唤3个水平环绕钻石","color":"green"}]
