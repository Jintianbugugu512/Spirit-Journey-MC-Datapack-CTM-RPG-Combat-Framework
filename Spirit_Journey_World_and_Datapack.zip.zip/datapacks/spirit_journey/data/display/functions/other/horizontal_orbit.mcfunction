#高频:execute as @e[tag=apple] at @s run function display:other/horizontal_orbit {"tag":"apple","r":1,"rotate":"10.0f","speed":5}
#注意用函数清除时 本体和pivot都要清除.
#bug:Rotation的x不可为0,请用1.0

$execute unless entity @e[tag=$(tag)_pivot] run summon block_display ^ ^ ^ {Tags:["$(tag)_pivot"],Rotation:[$(rotate),0.0f]}
$execute as @e[tag=$(tag)_pivot,y_rotation=0.01..180] at @s run tp @s ~ ~ ~ ~ ~$(speed)
$execute as @e[tag=$(tag)_pivot,y_rotation=-180..0] at @s run tp @s ~ ~ ~ ~ ~-$(speed)
$execute as @e[tag=$(tag)_pivot,x_rotation=90] run function display:other/vertical_orbit_90
$execute as @e[tag=$(tag)_pivot,x_rotation=-90] run function display:other/vertical_orbit_90
$execute as @e[tag=$(tag)_pivot] at @s run teleport @e[tag=$(tag)] ^ ^ ^$(r) facing ~ ~ ~

