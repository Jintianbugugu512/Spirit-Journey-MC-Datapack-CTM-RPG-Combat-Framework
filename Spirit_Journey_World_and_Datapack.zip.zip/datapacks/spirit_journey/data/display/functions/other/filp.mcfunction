
$data merge entity @s[x_rotation=90] {Rotation:[$(filp)f,90f]}

$data merge entity @s[x_rotation=-90] {Rotation:[$(filp)f,-90f]}

