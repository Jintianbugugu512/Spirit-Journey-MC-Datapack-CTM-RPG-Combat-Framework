#高频:execute as @e[tag=apple] at @s run function display:other/vertical_orbit {"tag":"apple","r":3,"h":0,"speed":5}
#注意用函数清除时 本体和pivot都要清除.

$execute unless entity @e[tag=$(tag)_pivot] at @s run summon block_display ~ ~ ~ {Tags:["$(tag)_pivot"]}
$execute as @e[tag=$(tag)_pivot] at @s run tp @s ~ ~ ~ ~$(speed) ~
$execute as @e[tag=$(tag)_pivot] at @s run teleport @e[tag=$(tag)] ^ ^$(h) ^$(r) facing ~ ~ ~






