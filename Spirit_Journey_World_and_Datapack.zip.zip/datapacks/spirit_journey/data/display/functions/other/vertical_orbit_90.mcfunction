
execute store result score @s[x_rotation=90] temp run data get entity @s Rotation[0]
execute store result score @s[x_rotation=-90] temp run data get entity @s Rotation[0]
execute store result score @s temp run data get entity @s Rotation[0]
scoreboard players set @s temp1 180
scoreboard players operation @s temp += @s temp1
execute as @s[x_rotation=90] run execute store result storage rotate:filp filp int 1 run scoreboard players get @s temp
execute as @s[x_rotation=-90] run execute store result storage rotate:filp filp int 1 run scoreboard players get @s temp
function display:other/filp with storage rotate:filp



