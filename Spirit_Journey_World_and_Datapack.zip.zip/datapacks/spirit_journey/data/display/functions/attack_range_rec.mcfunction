#参数:Pos:target x,y,z ,s_x,s_y,s_z, r,time
#execute summon item_display run function display:attack_range_rec {"s_x":"4.0","s_y":"4.0","s_z":"0.1","time":"50","tag":"xxx"}
#execute summon item_display run function display:attack_range
$scoreboard players set @s countDown $(time)
$data merge entity @s {item:{id:"shulker_shell",Count:1b},Tags:["attack_range","$(tag)"]}
$data merge entity @s {transformation:{scale:[$(s_x),$(s_y),$(s_z)],start_interpolation:0,interpolation_duration:10},Rotation:[0.0f,90.0f]}
data modify entity @s Rotation[0] set from entity @e[limit=1,sort=nearest,type=!item_display] Rotation[0]

