#函数调用
#/function display:item_summon {"type":carrot,"id_tag":1}
#用id_tag来表明这是什么物品
#1:金西瓜 2:金萝卜 3:聚合钢

$summon minecraft:item_display ~ ~0.1 ~ {item:{id:"$(type)",Count:1b,tag:{RepairCost:66}},Rotation:[0.0f,0.0f],Tags:["item_on_world","$(id_tag)"],item_display:none}




