particle enchant ~ ~0.8 ~ 0.4 0.7 0.4 0.05 5 normal
execute unless entity @a[distance=..2] run scoreboard players set @s interval_pick_up 0
execute if entity @a[distance=..2,gamemode=adventure] run function display:item_give


