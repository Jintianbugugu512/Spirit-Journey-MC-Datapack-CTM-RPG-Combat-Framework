#之后会根据物品不同的tag来表明为不同的物品.
scoreboard players add @s interval_pick_up 1
execute if entity @s[scores={interval_pick_up=12..}] as @a[distance=..2,limit=1] run give @s emerald
execute if entity @s[scores={interval_pick_up=12..}] as @a[distance=..2,limit=1] run particle totem_of_undying ~ ~1 ~ 4 2 4 0.1 300
execute if entity @s[scores={interval_pick_up=12..}] as @a[distance=..2,limit=1] run playsound entity.player.levelup player 1 0.8 1 ~1
execute if entity @s[scores={interval_pick_up=12..}] run kill @s