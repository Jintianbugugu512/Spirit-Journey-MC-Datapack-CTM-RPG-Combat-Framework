#参数:Pos:target x,y,z ,s_x,s_y,s_z, r,time
#execute summon item_display run function display:attack_range_cir {"s_x":"4.0","s_y":"0.1","s_z":"4.0","time":"50","tag":"xxx"}
#execute summon item_display run function display:attack_range
$scoreboard players set @s countDown $(time)
$data merge entity @s {item:{id:"slime_ball",Count:1b},Tags:["attack_range","$(tag)"]}
$data merge entity @s {transformation:{scale:[$(s_x),$(s_y),$(s_z)],start_interpolation:0,interpolation_duration:10},Rotation:[0.0f,90.0f]}

